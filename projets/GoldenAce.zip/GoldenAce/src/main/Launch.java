package main;
public class Launch {
    public static void main(String[] args){
        Start intro = new Start();
        Start.afficher_Menu();
        intro.choix_selectionner();
    }
    
}