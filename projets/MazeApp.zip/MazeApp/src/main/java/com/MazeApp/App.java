package com.MazeApp;

import java.io.File;

import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.views.TypeView;

import javafx.application.Application;
import javafx.stage.Stage;



/**
 * JavaFX App
 */
public class App extends Application {
    private Stage stage;
    private SceneManager sceneManager;
    public final static String PATH = System.getProperty("user.dir") + File.separatorChar + "src" + File.separatorChar + "main" + File.separatorChar + "resources" + File.separatorChar; 

    @Override
    public void start(Stage stage) {
        this.stage = stage;
        this.sceneManager = new SceneManager(stage);
        sceneManager.switchView(TypeView.MAIN);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}