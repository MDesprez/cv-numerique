package com.MazeApp.game;

import com.MazeApp.game.model.*;
import com.MazeApp.game.model.mazes.AbstractMaze;
import com.MazeApp.javafx.controllers.GameController;
import com.MazeApp.javafx.observateurs.GameManagerObserver;

import java.util.ArrayList;
import java.util.List;

/**
 * Contrôleur principal de la logique du jeu (Game Engine).
 * <p>
 * Cette classe fait le lien entre le modèle de données (Joueur, Labyrinthe, Segment)
 * et les contrôleurs de l'interface graphique. Elle implémente le pattern <b>Observer</b>
 * pour notifier les vues à chaque changement d'état (déplacement du joueur, fin de partie).
 */
public class GameManager {

    /** Le joueur actuellement connecté ou en train de jouer. */
    private Player currentPlayer;

    /** Le segment (niveau) en cours, si le jeu est en mode Progression. Null en mode Libre. */
    private Segment currentSegment;

    /** L'instance du labyrinthe actif dans lequel le joueur évolue. */
    private AbstractMaze currentMaze;

    /** Liste des observateurs (Vues/Contrôleurs) à notifier lors des mises à jour. */
    private List<GameManagerObserver> observers = new ArrayList<>();

    /**
     * Lance la boucle de jeu et connecte le contrôleur graphique.
     * <p>
     * Cette méthode enregistre le {@link GameController} comme observateur s'il ne l'est pas déjà,
     * et déclenche une première mise à jour pour afficher l'état initial.
     *
     * @param gameController Le contrôleur de la vue de jeu.
     */
    public void launchGame(GameController gameController) {
        if (!this.observers.contains(gameController)) {
            this.add(gameController);
        }

        gameController.update(this);
    }

    /**
     * Prépare une nouvelle partie basée sur un segment du mode Progression.
     * <p>
     * Charge le labyrinthe correspondant à la difficulté choisie, réinitialise la position
     * du joueur et les statistiques (temps, mouvements).
     *
     * @param player    Le joueur qui lance la partie.
     * @param segment   Le segment (niveau) sélectionné.
     * @param challenge La difficulté choisie (Easy, Medium, Hard).
     */
    public void prepareLevel(Player player, Segment segment, Challenge challenge) {
        this.currentPlayer = player;
        this.currentSegment = segment;
        this.currentMaze = segment.getMaze(challenge);

        if (this.currentMaze != null) {
            this.currentMaze.resetPlayer();
            this.currentMaze.resetStats();
        }
    }

    /**
     * Traite une demande de déplacement du joueur.
     * <p>
     * Délègue la logique de mouvement au labyrinthe actuel. Si le labyrinthe existe,
     * les observateurs sont notifiés pour rafraîchir l'affichage après le mouvement.
     *
     * @param direction La direction souhaitée (HAUT, BAS, GAUCHE, DROITE).
     */
    public void movePlayer(Direction direction) {
        if (currentMaze == null) return;

        currentMaze.movePlayer(direction);

        this.notifyObservers();
    }

    /**
     * Gère la fin de la partie (Victoire).
     * <p>
     * Si le joueur est en mode Progression (Player et Segment non nuls),
     * cette méthode enregistre la réussite du niveau, calcule le score et met à jour le profil du joueur.
     */
    public void endGame() {
        if (currentMaze == null) return;

        if (currentPlayer != null && currentSegment != null) {
            currentPlayer.confirmSegment(currentSegment);
        }
    }

    /**
     * Ajoute un nouvel observateur à la liste.
     * @param obs L'observateur à ajouter.
     */
    public void add(GameManagerObserver obs) { observers.add(obs); }

    /**
     * Retire un observateur de la liste.
     * @param obs L'observateur à retirer.
     */
    public void remove(GameManagerObserver obs) { observers.remove(obs); }

    /**
     * Vide la liste de tous les observateurs.
     */
    public void removeAllObservaters() { observers.clear(); }

    /**
     * Notifie tous les observateurs enregistrés qu'un changement a eu lieu dans le jeu.
     * Appelle la méthode {@code update(this)} sur chaque observateur.
     */
    protected void notifyObservers() {
        for (GameManagerObserver obs : observers) {
            obs.update(this);
        }
    }

    /**
     * Définit le joueur actuel.
     * @param currentPlayer Le joueur.
     */
    public void setCurrentPlayer(Player currentPlayer) { this.currentPlayer = currentPlayer; }

    /**
     * @return Le joueur actuel.
     */
    public Player getCurrentPlayer() { return currentPlayer; }

    /**
     * Définit manuellement le labyrinthe actif (utile pour le mode Libre).
     * @param maze Le labyrinthe à jouer.
     */
    public void setMaze(AbstractMaze maze) { this.currentMaze = maze; }

    /**
     * @return Le labyrinthe actif.
     */
    public AbstractMaze getMaze() { return currentMaze; }

    /**
     * @return Le segment actuel (peut être null en mode Libre).
     */
    public Segment getCurrentSegment() { return currentSegment; }

    /**
     * @return La liste des observateurs abonnés.
     */
    public List<GameManagerObserver> getObservers() { return observers; }
}