package com.MazeApp.game;

import com.MazeApp.game.model.Player;
import com.MazeApp.game.model.Save;
// L'import de SaveManager ici est redondant mais présent dans ton code source original.
import com.MazeApp.game.SaveManager;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Gestionnaire de la persistance des données du jeu.
 * <p>
 * Cette classe est responsable de toutes les opérations d'entrée/sortie (I/O) liées aux sauvegardes :
 * <ul>
 * <li>Sérialisation des objets {@link Save} dans des fichiers.</li>
 * <li>Désérialisation pour le chargement.</li>
 * <li>Gestion de l'arborescence des dossiers par joueur.</li>
 * <li>Suppression et listage des fichiers existants.</li>
 * </ul>
 */
public class SaveManager {

    /** Chemin racine où sont stockées toutes les sauvegardes. */
    private final String basePath;

    /**
     * Initialise le gestionnaire de sauvegarde.
     * <p>
     * Crée le répertoire racine s'il n'existe pas encore.
     *
     * @param basePath Le chemin du dossier racine (Note : le code actuel force l'utilisation de {@code Save.PATH}).
     */
    public SaveManager(String basePath) {
        this.basePath = Save.PATH;
        File baseDir = new File(basePath);
        if (!baseDir.exists()) baseDir.mkdirs();
    }

    /**
     * Sauvegarde l'état actuel d'un joueur.
     * <p>
     * Cette méthode :
     * <ol>
     * <li>Crée un objet {@link Save} contenant les données du joueur.</li>
     * <li>Détermine un ID unique pour le fichier (auto-incrémentation).</li>
     * <li>Crée le dossier du joueur s'il n'existe pas.</li>
     * <li>Sérialise l'objet dans un fichier nommé "NomJoueur(ID)".</li>
     * </ol>
     *
     * @param player Le joueur dont la progression doit être sauvegardée.
     * @throws RuntimeException Si une erreur d'entrée/sortie survient (IOException).
     */
    public void save(Player player) {
        int nextID = getNextID(player);
        Save save = new Save(player, nextID);

        File playerDir = new File(basePath, player.getName() + player.getID());
        if (!playerDir.exists()) playerDir.mkdirs();

        File file = new File(playerDir, player.getName() + "(" + nextID + ")");
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(save);
            System.out.println("Sauvegarde enregistrée : " + file.getPath());
        } catch (IOException e) {
            throw new RuntimeException("Erreur lors de la sauvegarde", e);
        }
    }

    /**
     * Charge une sauvegarde spécifique pour un joueur donné.
     *
     * @param player   Le joueur concerné (pour localiser le dossier).
     * @param fileName Le nom du fichier de sauvegarde à charger.
     * @return L'objet {@link Save} désérialisé, ou {@code null} si le fichier n'existe pas.
     * @throws RuntimeException Si une erreur survient lors de la lecture du fichier.
     */
    public Save load(Player player, String fileName) {
        File file = new File(new File(basePath, player.getName() + player.getID()), fileName);
        if (!file.exists()) return null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (Save) ois.readObject();
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors du chargement", e);
        }
    }

    /**
     * Supprime un fichier de sauvegarde spécifique.
     *
     * @param player   Le joueur concerné.
     * @param fileName Le nom du fichier à supprimer.
     */
    public void delete(Player player, String fileName) {
        File file = new File(new File(basePath, player.getName() + player.getID()), fileName);
        if (file.exists() && !file.delete()) {
            System.out.println("Impossible de supprimer : " + fileName);
        }
    }

    /**
     * Liste tous les fichiers de sauvegarde disponibles pour un joueur connecté.
     *
     * @param player Le joueur actuel.
     * @return Une liste de chaînes contenant les noms des fichiers.
     */
    public List<String> listSaves(Player player) {
        File playerDir = new File(basePath, player.getName() + player.getID());
        List<String> saves = new ArrayList<>();
        if (playerDir.exists()) {
            for (File f : playerDir.listFiles()) {
                if (f.isFile()) saves.add(f.getName());
            }
        }
        return saves;
    }

    /**
     * @return Le chemin racine du dossier de sauvegardes.
     */
    public String getBasePath() {
        return basePath;
    }

    /**
     * Calcule le prochain ID de sauvegarde disponible pour un joueur.
     * <p>
     * Analyse les noms de fichiers existants formatés comme "Nom(X)" pour trouver le X maximum.
     *
     * @param player Le joueur.
     * @return Le prochain ID (max existant + 1).
     */
    private int getNextID(Player player) {
        File playerDir = new File(basePath, player.getName() + player.getID());
        int maxID = -1;
        if (playerDir.exists() && playerDir.isDirectory()) {
            for (File f : playerDir.listFiles()) {
                String fname = f.getName();
                int start = fname.indexOf("(");
                int end = fname.indexOf(")");
                if (start >= 0 && end > start) {
                    try {
                        int id = Integer.parseInt(fname.substring(start + 1, end));
                        if (id > maxID) maxID = id;
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
        return maxID + 1;
    }

    /**
     * Recherche les dossiers de sauvegarde correspondant à un nom d'utilisateur.
     * <p>
     * Utile pour lister les profils disponibles au chargement, même s'ils ont des ID différents.
     *
     * @param username Le nom d'utilisateur (ou le début du nom).
     * @return Une liste de noms de dossiers correspondants.
     */
    public List<String> listSavesByUsername(String username) {
        File baseDir = new File(basePath);
        List<String> folders = new ArrayList<>();
        if (baseDir.exists() && baseDir.isDirectory()) {
            for (File f : baseDir.listFiles(File::isDirectory)) {
                if (f.getName().startsWith(username)) folders.add(f.getName());
            }
        }
        return folders;
    }

    /**
     * Liste les fichiers de sauvegarde contenus dans un dossier spécifique (par son nom).
     *
     * @param folderName Le nom du dossier du joueur (ex: "Toto0").
     * @return Une liste des noms de fichiers de sauvegarde.
     */
    public List<String> listSavesByFolder(String folderName) {
        File folder = new File(basePath, folderName);
        List<String> files = new ArrayList<>();
        if (folder.exists() && folder.isDirectory()) {
            for (File f : folder.listFiles()) {
                if (f.isFile()) files.add(f.getName());
            }
        }
        return files;
    }

    /**
     * Charge une sauvegarde à partir du nom du dossier et du nom du fichier.
     * <p>
     * Cette méthode est utilisée quand l'objet {@link Player} n'est pas encore instancié
     * (ex: lors de la sélection d'un profil au lancement).
     *
     * @param folderName Le nom du dossier contenant la sauvegarde.
     * @param fileName   Le nom du fichier.
     * @return L'objet {@link Save} chargé, ou {@code null} en cas d'erreur.
     */
    public Save loadByFolder(String folderName, String fileName) {
        File file = new File(new File(basePath, folderName), fileName);
        System.out.println("chemin load by folder : " + basePath + " + " + folderName + ":" + fileName);
        if (!file.exists()) return null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (Save) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}