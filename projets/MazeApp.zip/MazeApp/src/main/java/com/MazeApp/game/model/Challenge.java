package com.MazeApp.game.model;

import java.io.Serializable;

// PROPRE
public enum Challenge{
    NONE(0.0),
    EASY(0.3),
    MEDIUM(0.4),
    HARD(0.5);

    private final double wallPercentage;

    private Challenge(double wallPercentage) {
        this.wallPercentage = wallPercentage;
    }

    public double getWallPercentage() {
        return wallPercentage;
    }
}
