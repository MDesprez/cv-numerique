package com.MazeApp.game.model;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Représente un joueur et ses données de progression.
 * <p>
 * Cette classe stocke les informations d'identification du joueur,
 * ainsi que l'état de sa progression dans le mode "Aventure/Progression"
 * (segments débloqués, scores obtenus).
 * Elle implémente {@link Serializable} pour permettre la sauvegarde dans un fichier.
 */
public class Player implements Serializable {
    private static final long serialVersionUID = 1L;

    private int ID;
    private static int counter;

    /** Nom d'utilisateur du joueur. */
    private String name;
    /** Mot de passe du joueur. */
    private String password;
    /** Identifiant unique du joueur. */
    private int id;

    /** Indice du segment le plus élevé atteint par le joueur. */
    private int maxSegmentReached;

    /** Liste de tous les segments (niveaux) disponibles pour ce joueur. */
    private List<Segment> segments;

    /** Map associant chaque segment à son meilleur score obtenu. */
    private Map<Segment, Double> segmentScores;

    /**
     * Crée un nouveau joueur.
     * <p>
     * Initialise la progression à 0 et génère la liste des segments par défaut.
     *
     * @param name     Le nom d'utilisateur.
     * @param password Le mot de passe.
     */
    public Player(String name, String password) {
        this.ID = 0;
        this.name = name;
        this.password = password;
        this.maxSegmentReached = 0;

        this.segments = new ArrayList<>();
        this.segmentScores = new HashMap<>();

        initSegments();

        this.id = 0;
    }

    /**
     * Initialise la liste des segments (niveaux) du mode progression.
     * <p>
     * Configure manuellement les défis (taille, type de labyrinthe, mode de vue)
     * pour chaque étape du jeu.
     */
    private void initSegments() {
        // Segments classiques (Labyrinthes Aléatoires)
        addSegment(new Segment(0, 15, 15));
        addSegment(new Segment(1, 20, 20));
        addSegment(new Segment(2, 20, 20, ViewMode.LOCAL)); // Avec brouillard de guerre

        // Segments avancés (Labyrinthes Parfaits)
        addSegment(new Segment(3, 5, 8, 5, 8, 12, ViewMode.NORMAL));
        addSegment(new Segment(4, 35, 35, 15, 25, 35, ViewMode.EXPLORATION));
        addSegment(new Segment(5, 20, 20, 10, 15, 20, ViewMode.BOB));
    }

    /**
     * Ajoute un segment à la liste du joueur et initialise son score à 0.
     *
     * @param s Le segment à ajouter.
     */
    private void addSegment(Segment s) {
        this.segments.add(s);
        this.segmentScores.put(s, 0.0);
    }

    /**
     * Confirme la complétion d'un segment et met à jour la progression.
     * <p>
     * Cette méthode :
     * <ul>
     * <li>Marque le segment comme valide.</li>
     * <li>Calcule le score obtenu et met à jour le meilleur score si nécessaire.</li>
     * <li>Incrémente {@code maxSegmentReached} si le joueur vient de terminer son niveau actuel.</li>
     * </ul>
     *
     * @param segment Le segment qui vient d'être terminé.
     */
    public void confirmSegment(Segment segment) {
        if (segment == null) return;

        segment.setValid(true);

        double newScore = segment.calculateScore();

        Double currentScore = segmentScores.get(segment);
        if (currentScore == null || newScore > currentScore) {
            segmentScores.put(segment, newScore);
        }

        if (segment.getNumber() == maxSegmentReached) {
            maxSegmentReached++;
        }
    }

    /**
     * Recherche le prochain ID disponible pour un nom d'utilisateur donné en scannant les fichiers de sauvegarde.
     *
     * @param username Le nom du joueur.
     * @return Le prochain ID disponible (entier).
     */
    private int whichID(String username) {
        File folder = new File(Save.getPath());
        int res = 0;

        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File f : files) {
                    String fname = f.getName();
                    if (fname.startsWith(username)) {
                        String numberPart = fname.substring(username.length());
                        try {
                            int id = Integer.parseInt(numberPart);
                            if (id >= res) {
                                res = id + 1;
                            }
                        } catch (NumberFormatException e) {
                        }
                    }
                }
            }
        }

        return res;
    }

    @Override
    public String toString() {
        return "Joueur " + name.toUpperCase() + " ID : " + id + "\n Etape max : " + maxSegmentReached;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPassword() { return password; }
    public int getID() { return id; }

    /**
     * @return L'index du dernier segment débloqué (accessible).
     */
    public int getMaxSegmentReached() { return maxSegmentReached; }
    public void setMaxSegmentReached(int max) { this.maxSegmentReached = max; }

    /**
     * @return La liste complète des segments du joueur.
     */
    public List<Segment> getSegment() { return segments; }

    /**
     * @return La map des scores par segment.
     */
    public Map<Segment, Double> getSegmentScores() { return segmentScores; }
}