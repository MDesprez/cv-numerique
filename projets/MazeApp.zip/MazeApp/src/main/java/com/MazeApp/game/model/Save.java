package com.MazeApp.game.model;
import java.io.File;
import java.io.Serializable;

import com.MazeApp.App;

public class Save implements Serializable {
    private static final long serialVersionUID = 1L;
    private final int ID;
    private final Player player;
    //public static final String PATH = System.getProperty("user.dir")+ File.separator + "target"+ File.separator + "classes"+ File.separator + "saves"+ File.separator;
    public static final String PATH = App.PATH + "saves" + File.separatorChar;

    public Save(Player player, int ID) {
        this.player = player;
        this.ID = ID;
        
    }

    public Player getPlayer() { return player; }
    public int getID() { return ID; }

    @Override
    public String toString() {
        return "Sauvegarde n°" + ID + " de " + player.getName();
    }

    public static String getPath(){ 
        return PATH; 
    }
}
