package com.MazeApp.game.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.MazeApp.game.model.mazes.*;

/**
 * Représente une étape (ou niveau) dans le mode Progression du jeu.
 * <p>
 * Un segment contient trois variantes de labyrinthes correspondant aux niveaux de difficulté
 * (Facile, Moyen, Difficile). Il gère également le calcul du score et le mode d'affichage
 * imposé pour ce niveau.
 */
public class Segment implements Serializable {
    private static final long serialVersionUID = 1L;

    private static final double MAX_SCORE_EASY = 50.0;
    private static final double MAX_SCORE_MEDIUM = 70.0;
    private static final double MAX_SCORE_HARD = 100.0;

    /** Numéro du segment (ordre dans la progression). */
    private int number;

    /** Indique si ce segment a été validé (terminé au moins une fois). */
    private boolean isValid;

    /** Le mode de vue imposé pour ce segment (ex: NORMAL, LOCAL, BOB). */
    private ViewMode viewMode;

    /** Contient les instances de labyrinthes pour chaque difficulté (Challenge). */
    private Map<Challenge, AbstractMaze> mazes;

    /**
     * Constructeur pour un segment de type "Labyrinthe Aléatoire" (MazeRandom) avec vue normale.
     *
     * @param number Le numéro du segment.
     * @param width  La largeur des labyrinthes.
     * @param height La hauteur des labyrinthes.
     */
    public Segment(int number, int width, int height) {
        this(number, ViewMode.NORMAL);

        this.mazes.put(Challenge.EASY, MazeFactory.random(width, height, Challenge.EASY.getWallPercentage()));
        this.mazes.put(Challenge.MEDIUM, MazeFactory.random(width, height, Challenge.MEDIUM.getWallPercentage()));
        this.mazes.put(Challenge.HARD, MazeFactory.random(width, height, Challenge.HARD.getWallPercentage()));
    }

    /**
     * Constructeur pour un segment de type "Labyrinthe Aléatoire" avec un mode de vue spécifique.
     *
     * @param number Le numéro du segment.
     * @param width  La largeur.
     * @param height La hauteur.
     * @param mode   Le mode de vue (ex: ViewMode.LOCAL).
     */
    public Segment(int number, int width, int height, ViewMode mode) {
        this(number, mode);

        this.mazes.put(Challenge.EASY, MazeFactory.random(width, height, Challenge.EASY.getWallPercentage()));
        this.mazes.put(Challenge.MEDIUM, MazeFactory.random(width, height, Challenge.MEDIUM.getWallPercentage()));
        this.mazes.put(Challenge.HARD, MazeFactory.random(width, height, Challenge.HARD.getWallPercentage()));
    }

    /**
     * Constructeur pour un segment de type "Labyrinthe Parfait" (MazePerfect).
     * <p>
     * Permet de définir des contraintes de distance minimale pour chaque difficulté.
     *
     * @param number    Le numéro du segment.
     * @param width     La largeur.
     * @param height    La hauteur.
     * @param minEasy   Distance minimale pour le mode Facile.
     * @param minMedium Distance minimale pour le mode Moyen.
     * @param minHard   Distance minimale pour le mode Difficile.
     * @param viewMode  Le mode de vue.
     */
    public Segment(int number, int width, int height, int minEasy, int minMedium, int minHard, ViewMode viewMode) {
        this(number, viewMode);

        this.mazes.put(Challenge.EASY, MazeFactory.perfect(width, height, minEasy));
        this.mazes.put(Challenge.MEDIUM, MazeFactory.perfect(width, height, minMedium));
        this.mazes.put(Challenge.HARD, MazeFactory.perfect(width, height, minHard));
    }

    /**
     * Constructeur privé de base pour l'initialisation commune.
     */
    private Segment(int number, ViewMode viewMode) {
        this.number = number;
        this.viewMode = viewMode;
        this.isValid = false;
        this.mazes = new HashMap<>();
    }

    /**
     * Calcule le score obtenu pour ce segment.
     * <p>
     * Le score est basé sur la difficulté la plus élevée réussie.
     * Il est pénalisé quadratiquement en fonction de l'écart entre le nombre de mouvements effectués
     * et la distance minimale théorique.
     *
     * @return Le score calculé (arrondi à l'entier le plus proche).
     */
    public double calculateScore() {
        Challenge maxValide = getMaxValide();
        if (maxValide == Challenge.NONE) return 0.0;

        AbstractMaze maze = mazes.get(maxValide);
        double scoreMax = getScoreMax(maxValide);

        int moves = maze.getMoves();
        int minDistance = maze.getMinimalDistance();

        if (minDistance <= 0) return scoreMax;

        double finalScore;

        int ecart = moves - minDistance;
        if (ecart <= 0) {
            finalScore = scoreMax;
        } else {
            double penalization = Math.pow((double) ecart / minDistance, 2);
            finalScore = Math.max(0, scoreMax * (1.0 - penalization));
        }

        return Math.round(finalScore);
    }

    /**
     * Retourne le score maximum possible pour une difficulté donnée.
     *
     * @param c La difficulté (Challenge).
     * @return Le score max associé.
     */
    private double getScoreMax(Challenge c) {
        switch (c) {
            case EASY: return MAX_SCORE_EASY;
            case MEDIUM: return MAX_SCORE_MEDIUM;
            case HARD: return MAX_SCORE_HARD;
            default: return 0.0;
        }
    }

    /**
     * Détermine la difficulté la plus élevée que le joueur a réussi à compléter dans ce segment.
     * <p>
     * L'ordre de priorité est : HARD > MEDIUM > EASY.
     *
     * @return Le Challenge réussi le plus élevé, ou {@code Challenge.NONE} si aucun n'est réussi.
     */
    public Challenge getMaxValide() {
        if (isComplete(Challenge.HARD)) return Challenge.HARD;
        if (isComplete(Challenge.MEDIUM)) return Challenge.MEDIUM;
        if (isComplete(Challenge.EASY)) return Challenge.EASY;
        return Challenge.NONE;
    }

    /**
     * Vérifie si un labyrinthe d'une difficulté spécifique est complété.
     *
     * @param c La difficulté à vérifier.
     * @return {@code true} si le labyrinthe existe et est marqué comme complet.
     */
    private boolean isComplete(Challenge c) {
        return mazes.containsKey(c) && mazes.get(c).isComplete();
    }

    public void setValid(boolean isValid) { this.isValid = isValid; }
    public boolean getIsValid() { return isValid; }
    public int getNumber() { return number; }
    public ViewMode getViewMode() { return viewMode; }

    /**
     * @return La map contenant tous les labyrinthes du segment.
     */
    public Map<Challenge, AbstractMaze> getMazes() { return mazes; }

    /**
     * Récupère le labyrinthe correspondant à une difficulté donnée.
     *
     * @param c La difficulté souhaitée.
     * @return L'instance de {@link AbstractMaze} correspondante.
     */
    public AbstractMaze getMaze(Challenge c) { return mazes.get(c); }
}