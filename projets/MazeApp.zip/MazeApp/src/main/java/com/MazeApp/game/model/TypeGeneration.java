package com.MazeApp.game.model;

public enum TypeGeneration {
    RANDOM,
    PERFECT,
    EMPTY
}
