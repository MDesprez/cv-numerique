package com.MazeApp.game.model;

public enum ViewMode {
    NORMAL,
    EXPLORATION,
    LOCAL,
    BOB;
}
