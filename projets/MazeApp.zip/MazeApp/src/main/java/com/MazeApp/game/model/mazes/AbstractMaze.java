package com.MazeApp.game.model.mazes;

import com.MazeApp.game.model.Direction;

import java.io.Serializable;
import java.util.*;

/**
 * Classe abstraite représentant la structure de base d'un labyrinthe.
 * <p>
 * Cette classe gère les propriétés communes à tous les types de labyrinthes :
 * <ul>
 * <li>Dimensions (largeur, hauteur)</li>
 * <li>Position du joueur, de l'entrée et de la sortie</li>
 * <li>Déplacement du joueur et détection des murs</li>
 * <li>Calcul de la distance minimale (résolution via BFS)</li>
 * <li>État de la partie (nombre de mouvements, complétion)</li>
 * </ul>
 * Elle implémente {@link Serializable} pour permettre la sauvegarde de l'état du labyrinthe.
 */
public abstract class AbstractMaze implements Serializable {
    /** Générateur de nombres aléatoires partagé pour la génération procédurale. */
    protected static final Random RAND = new Random();

    /** Largeur du labyrinthe (nombre de colonnes). */
    protected int width;
    /** Hauteur du labyrinthe (nombre de lignes). */
    protected int height;

    /** Coordonnée X de l'entrée. */
    protected int entryX;
    /** Coordonnée Y de l'entrée. */
    protected int entryY;

    /** Coordonnée X de la sortie. */
    protected int exitX;
    /** Coordonnée Y de la sortie. */
    protected int exitY;

    /** Coordonnée X actuelle du joueur. */
    protected int playerX;
    /** Coordonnée Y actuelle du joueur. */
    protected int playerY;

    /** Distance minimale théorique entre l'entrée et la sortie (calculée via BFS). */
    protected int minimalDistance;

    /** Indique si le niveau a été complété par le joueur. */
    protected boolean complete;

    /** Compteur du nombre de déplacements effectués par le joueur. */
    protected int moves;

    /**
     * Constructeur de base pour un labyrinthe.
     *
     * @param width  La largeur du labyrinthe (en nombre de cases).
     * @param height La hauteur du labyrinthe (en nombre de cases).
     */
    public AbstractMaze(int width, int height) {
        this.width = width;
        this.height = height;
    }

    /**
     * Génère la structure interne du labyrinthe (murs et chemins).
     * <p>
     * Cette méthode doit être implémentée par les sous-classes pour définir
     * l'algorithme de génération spécifique (ex: division récursive, aléatoire, etc.).
     */
    public abstract void generate();

    /**
     * Vérifie la présence d'un mur entre deux cases adjacentes ou à une position donnée.
     *
     * @param row  Ligne de la première case (départ).
     * @param col  Colonne de la première case (départ).
     * @param row2 Ligne de la seconde case (arrivée).
     * @param col2 Colonne de la seconde case (arrivée).
     * @return {@code true} s'il y a un obstacle/mur entre les deux positions, {@code false} sinon.
     */
    public abstract boolean isWall(int row, int col, int row2, int col2);

    /**
     * Place aléatoirement l'entrée sur l'un des bords du labyrinthe.
     * <p>
     * Réinitialise également la position du joueur à cette entrée.
     */
    protected void generateEntry() {
        int edge = RAND.nextInt(4);
        switch (edge) {
            case 0: // Haut
                entryX = RAND.nextInt(width - 2) + 1;
                entryY = 0;
                break;
            case 1: // Droite
                entryX = width - 1;
                entryY = RAND.nextInt(height - 2) + 1;
                break;
            case 2: // Bas
                entryX = RAND.nextInt(width - 2) + 1;
                entryY = height - 1;
                break;
            case 3: // Gauche
                entryX = 0;
                entryY = RAND.nextInt(height - 2) + 1;
                break;
        }
        resetPlayer();
    }

    /**
     * Place aléatoirement la sortie sur l'un des bords du labyrinthe.
     * <p>
     * Cette méthode s'assure que la sortie n'est pas placée au même endroit que l'entrée.
     */
    protected void generateExit() {
        do {
            int edge = RAND.nextInt(4);
            switch (edge) {
                case 0: // Haut
                    exitX = RAND.nextInt(width - 2) + 1;
                    exitY = 0;
                    break;
                case 1: // Droite
                    exitX = width - 1;
                    exitY = RAND.nextInt(height - 2) + 1;
                    break;
                case 2: // Bas
                    exitX = RAND.nextInt(width - 2) + 1;
                    exitY = height - 1;
                    break;
                case 3: // Gauche
                    exitX = 0;
                    exitY = RAND.nextInt(height - 2) + 1;
                    break;
            }
        } while (exitX == entryX && exitY == entryY);
    }

    /**
     * Vérifie si le labyrinthe généré est valide (résoluble).
     *
     * @return {@code true} s'il existe un chemin entre l'entrée et la sortie, {@code false} sinon.
     */
    public boolean isValid() {
        return calculateMinimalDistance() != -1;
    }

    /**
     * Calcule la distance minimale entre l'entrée et la sortie en utilisant un algorithme BFS (Breadth-First Search).
     *
     * @return La distance en nombre de pas, ou {@code -1} si aucun chemin n'existe.
     */
    public int calculateMinimalDistance() {
        Queue<int[]> queue = new LinkedList<>();
        boolean[][] visited = new boolean[height][width];
        int[][] dist = new int[height][width];

        queue.offer(new int[]{entryX, entryY});
        visited[entryY][entryX] = true;
        dist[entryY][entryX] = 0;

        int[][] dirs = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};

        while (!queue.isEmpty()) {
            int[] pos = queue.poll();
            int x = pos[0];
            int y = pos[1];

            if (x == exitX && y == exitY) {
                return dist[y][x];
            }

            for (int[] d : dirs) {
                int nx = x + d[0];
                int ny = y + d[1];

                if (nx >= 0 && nx < width && ny >= 0 && ny < height
                        && !visited[ny][nx] && !isWall(y, x, ny, nx)) {
                    visited[ny][nx] = true;
                    dist[ny][nx] = dist[y][x] + 1;
                    queue.offer(new int[]{nx, ny});
                }
            }
        }
        return -1;
    }

    /**
     * Tente de déplacer le joueur dans une direction donnée.
     * <p>
     * Le déplacement est effectué si la case cible est dans les limites du labyrinthe
     * et qu'aucun mur ne bloque le passage. Met à jour le compteur de mouvements
     * et vérifie si la sortie est atteinte.
     *
     * @param direction La direction dans laquelle le joueur souhaite aller (HAUT, BAS, GAUCHE, DROITE).
     */
    public void movePlayer(Direction direction) {
        int newX = playerX + direction.getDx();
        int newY = playerY + direction.getDy();

        boolean withinBounds = newX >= 0 && newX < width && newY >= 0 && newY < height;

        if (withinBounds && !isWall(playerY, playerX, newY, newX)) {
            playerX = newX;
            playerY = newY;
            moves++;
            if (isExitReached()) {
                complete = true;
            }
        }
    }

    /**
     * Vérifie si le joueur se trouve actuellement sur la case de sortie.
     *
     * @return {@code true} si le joueur est sur la sortie, {@code false} sinon.
     */
    public boolean isExitReached() {
        return playerX == exitX && playerY == exitY;
    }

    /**
     * Réinitialise la position du joueur à l'entrée du labyrinthe.
     */
    public void resetPlayer() {
        this.playerX = entryX;
        this.playerY = entryY;
    }

    /**
     * Réinitialise les statistiques de la partie en cours (nombre de mouvements, état de complétion).
     */
    public void resetStats() {
        this.moves = 0;
        this.complete = false;
    }


    /**
     * @return La largeur du labyrinthe.
     */
    public int getWidth() { return width; }

    /**
     * @return La hauteur du labyrinthe.
     */
    public int getHeight() { return height; }

    /**
     * @return La coordonnée X de l'entrée.
     */
    public int getEntryX() { return entryX; }

    /**
     * @return La coordonnée Y de l'entrée.
     */
    public int getEntryY() { return entryY; }

    /**
     * @return La coordonnée X de la sortie.
     */
    public int getExitX() { return exitX; }

    /**
     * @return La coordonnée Y de la sortie.
     */
    public int getExitY() { return exitY; }

    /**
     * @return La coordonnée X actuelle du joueur.
     */
    public int getPlayerX() { return playerX; }

    /**
     * @return La coordonnée Y actuelle du joueur.
     */
    public int getPlayerY() { return playerY; }

    /**
     * Définit manuellement la coordonnée X du joueur.
     * @param x La nouvelle coordonnée X.
     */
    public void setPlayerX(int x) { this.playerX = x; }

    /**
     * Définit manuellement la coordonnée Y du joueur.
     * @param y La nouvelle coordonnée Y.
     */
    public void setPlayerY(int y) { this.playerY = y; }

    /**
     * Indique si le niveau est terminé.
     * @return {@code true} si le joueur a complété le niveau.
     */
    public boolean isComplete() { return complete; }

    /**
     * @return Le nombre de mouvements effectués par le joueur depuis le début ou le dernier reset.
     */
    public int getMoves() { return moves; }

    /**
     * @return La distance minimale calculée pour résoudre ce labyrinthe.
     */
    public int getMinimalDistance() { return minimalDistance; }

    /**
     * Récupère les coordonnées de l'entrée sous forme de tableau.
     * @return Un tableau d'entiers [x, y].
     */
    public int[] getEntry() { return new int[]{entryX, entryY}; }

    /**
     * Récupère les coordonnées de la sortie sous forme de tableau.
     * @return Un tableau d'entiers [x, y].
     */
    public int[] getExit() { return new int[]{exitX, exitY}; }

    /**
     * Récupère les coordonnées actuelles du joueur sous forme de tableau.
     * @return Un tableau d'entiers [x, y].
     */
    public int[] getPlayer() { return new int[]{playerX, playerY}; }
}