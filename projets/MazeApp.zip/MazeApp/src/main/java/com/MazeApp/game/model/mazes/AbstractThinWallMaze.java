package com.MazeApp.game.model.mazes;

/**
 * Classe abstraite représentant les labyrinthes dits "parfaits" ou à "murs fins".
 * <p>
 * Contrairement aux labyrinthes par blocs (où une case entière est un mur), ici les murs
 * sont situés <b>entre</b> les cases. Le labyrinthe est défini par deux grilles de booléens :
 * une pour les murs verticaux et une pour les murs horizontaux.
 */
public abstract class AbstractThinWallMaze extends AbstractMaze {

    /** Grille des murs verticaux (entre la colonne x et x+1). */
    protected boolean[][] murVerticaux;

    /** Grille des murs horizontaux (entre la ligne y et y+1). */
    protected boolean[][] murHorizontaux;

    /**
     * Constructeur initialisant les structures de données pour les murs.
     *
     * @param width  Largeur du labyrinthe.
     * @param height Hauteur du labyrinthe.
     */
    public AbstractThinWallMaze(int width, int height) {
        super(width, height);
        this.murVerticaux = new boolean[height][width - 1];
        this.murHorizontaux = new boolean[height - 1][width];
    }

    /**
     * Initialise l'ensemble des murs du labyrinthe.
     *
     * @param full Si {@code true}, le labyrinthe commence rempli de murs (pour les algos de creusage).
     * Si {@code false}, le labyrinthe commence vide (pour les algos d'ajout de murs).
     */
    protected void initWalls(boolean full) {
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width - 1; x++) murVerticaux[y][x] = full;
        }
        for (int y = 0; y < height - 1; y++) {
            for (int x = 0; x < width; x++) murHorizontaux[y][x] = full;
        }
    }

    /**
     * Vérifie s'il y a un mur entre deux cases ou si une position est hors limites.
     * <p>
     * Cette méthode gère également les limites extérieures du labyrinthe (qui sont considérées
     * comme des murs, sauf aux coordonnées de l'entrée et de la sortie).
     *
     * @param row  Ligne de la case de départ.
     * @param col  Colonne de la case de départ.
     * @param row2 Ligne de la case d'arrivée.
     * @param col2 Colonne de la case d'arrivée.
     * @return {@code true} si le passage est bloqué, {@code false} sinon.
     */
    @Override
    public boolean isWall(int row, int col, int row2, int col2) {
        boolean horsLabyrinthe = (row < 0 || row >= height || col < 0 || col >= width ||
                row2 < 0 || row2 >= height || col2 < 0 || col2 >= width);

        if (horsLabyrinthe) {
            boolean estEntree = (row == entryY && col == entryX) || (row2 == entryY && col2 == entryX);
            boolean estSortie = (row == exitY && col == exitX) || (row2 == exitY && col2 == exitX);
            return !(estEntree || estSortie);
        }

        if (row == row2) {
            int x = Math.min(col, col2);
            return murVerticaux[row][x];
        } else {
            int y = Math.min(row, row2);
            return murHorizontaux[y][col];
        }
    }
}