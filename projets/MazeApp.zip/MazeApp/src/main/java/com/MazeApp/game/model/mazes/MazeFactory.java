package com.MazeApp.game.model.mazes;

import java.util.ArrayList;

public class MazeFactory {
    public static MazeRandom random(int width, int height, double wallPercentage) {
        return new MazeRandom(width, height, wallPercentage);
    }

    public static MazePerfect perfect(int width, int height) {
        return new MazePerfect(width, height);
    }

    public static MazePerfect perfect(int width, int height, int minDistance) {
        return new MazePerfect(width, height, minDistance);
    }

    public static MazeRecursiveDivision recursive(int width, int height) {
        return new MazeRecursiveDivision(width, height);
    }

    public static MazeRecursiveDivision recursive(int width, int height, int minDistance) {
        return new MazeRecursiveDivision(width, height, minDistance);
    }

    public static MazePerfectRecursiveKeyMiniGame keyGame(int width, int height, int minDistance, int totalKey) {
        return new MazePerfectRecursiveKeyMiniGame(width, height, minDistance, totalKey);
    }

    public static void main(String[] args) {
        int iterations = 100;

        for (int i = 0; i < 500; i++) {
            MazeFactory.random(10, 10, 0.4);
        }

        long totalTime = 0;

        System.out.println("Début des mesures...");
        for (int idx = 0; idx < iterations; idx++) {
            long start = System.nanoTime();

            MazeFactory.recursive(1000, 1000, 1000);

            long end = System.nanoTime();
            totalTime += (end - start);
        }

        double averageNs = totalTime / (double) iterations;
        double averageMs = averageNs / 1_000_000.0;

        System.out.println("--- RÉSULTATS (sur " + iterations + " itérations) ---");
        System.out.printf("Temps moyen : %.2f ns (nanosecondes)%n", averageNs);
        System.out.printf("Temps moyen : %.4f ms (millisecondes)%n", averageMs);
    }
}