package com.MazeApp.game.model.mazes;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Implémentation d'un labyrinthe parfait généré par un algorithme de parcours en profondeur (DFS) itératif.
 * <p>
 * Un labyrinthe "parfait" signifie qu'il n'y a pas de boucle et qu'il existe un chemin unique
 * entre n'importe quelle paire de cases. L'algorithme part d'une grille pleine de murs et creuse des chemins.
 */
public class MazePerfect extends AbstractThinWallMaze {

    /**
     * Construit et génère un labyrinthe parfait standard.
     *
     * @param width  Largeur du labyrinthe.
     * @param height Hauteur du labyrinthe.
     */
    public MazePerfect(int width, int height) {
        super(width, height);
        this.generate();
        generateEntry();
        generateExit();
        this.minimalDistance = calculateMinimalDistance();
    }

    /**
     * Construit et génère un labyrinthe parfait respectant une distance minimale.
     * <p>
     * Regénère les points d'entrée et de sortie tant que la distance minimale n'est pas atteinte.
     *
     * @param width       Largeur du labyrinthe.
     * @param height      Hauteur du labyrinthe.
     * @param distanceMin La distance minimale requise entre l'entrée et la sortie.
     */
    public MazePerfect(int width, int height, int distanceMin) {
        super(width, height);
        this.generate();

        do {
            generateEntry();
            generateExit();
            this.minimalDistance = calculateMinimalDistance();
        } while (this.minimalDistance < distanceMin);

        this.resetPlayer();
    }

    /**
     * Génère le labyrinthe en utilisant un DFS itératif avec backtracking (via une Pile).
     * <ul>
     * <li>Initialise tous les murs à true.</li>
     * <li>Choisit une case de départ aléatoire.</li>
     * <li>Tant que la pile n'est pas vide :</li>
     * <ul>
     * <li>Récupère les voisins non visités.</li>
     * <li>Si un voisin existe, abat le mur et empile la nouvelle position.</li>
     * <li>Sinon, dépile (backtracking).</li>
     * </ul>
     * </ul>
     */
    @Override
    public void generate() {
        initWalls(true);

        boolean[][] visite = new boolean[height][width];
        Stack<int[]> pile = new Stack<>();

        int startY = RAND.nextInt(height);
        int startX = RAND.nextInt(width);

        pile.push(new int[]{startX, startY});
        visite[startY][startX] = true;

        while (!pile.isEmpty()) {
            int[] courant = pile.peek();
            int x = courant[0];
            int y = courant[1];

            List<int[]> voisins = getVoisinsNonVisites(x, y, visite);

            if (!voisins.isEmpty()) {
                int[] choisi = voisins.get(RAND.nextInt(voisins.size()));
                int cx = choisi[0];
                int cy = choisi[1];

                enleverMur(x, y, cx, cy);

                visite[cy][cx] = true;
                pile.push(choisi);
            } else {
                pile.pop();
            }
        }
    }

    /**
     * Supprime le mur séparant deux cases adjacentes.
     */
    private void enleverMur(int x1, int y1, int x2, int y2) {
        if (x1 == x2) {
            murHorizontaux[Math.min(y1, y2)][x1] = false;
        } else {
            murVerticaux[y1][Math.min(x1, x2)] = false;
        }
    }

    /**
     * Récupère la liste des coordonnées des voisins valides et non encore visités.
     */
    private List<int[]> getVoisinsNonVisites(int x, int y, boolean[][] visite) {
        List<int[]> liste = new ArrayList<>();
        int[][] dirs = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

        for (int[] d : dirs) {
            int nx = x + d[0];
            int ny = y + d[1];
            if (nx >= 0 && nx < width && ny >= 0 && ny < height && !visite[ny][nx]) {
                liste.add(new int[]{nx, ny});
            }
        }
        return liste;
    }
}