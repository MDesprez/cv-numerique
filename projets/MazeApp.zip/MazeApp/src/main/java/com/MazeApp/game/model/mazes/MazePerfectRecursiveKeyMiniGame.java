package com.MazeApp.game.model.mazes;

import com.MazeApp.game.model.Direction;

/**
 * Variante du labyrinthe à Division Récursive intégrant un mini-jeu de collecte de clés.
 * <p>
 * Le joueur doit ramasser un nombre défini de clés disséminées aléatoirement dans le labyrinthe
 * avant de pouvoir valider la sortie.
 */
public class MazePerfectRecursiveKeyMiniGame extends MazeRecursiveDivision {

    /** Tableau stockant les positions des clés [index][x, y]. */
    private int[][] keyLocations;

    /** Nombre de clés ramassées par le joueur. */
    private int keysCollected = 0;

    /** Nombre total de clés à trouver. */
    private int totalKeys;

    /**
     * Construit un labyrinthe à clés.
     *
     * @param width       Largeur du labyrinthe.
     * @param height      Hauteur du labyrinthe.
     * @param distanceMin Distance minimale entrée-sortie.
     * @param totalKeys   Nombre de clés à générer.
     */
    public MazePerfectRecursiveKeyMiniGame(int width, int height, int distanceMin, int totalKeys) {
        super(width, height, distanceMin);
        this.totalKeys = totalKeys;
        this.keyLocations = new int[totalKeys][2];
        this.generateAllKeys(totalKeys);
    }

    /**
     * Génère les positions aléatoires des clés.
     * S'assure que les clés ne se superposent pas et ne sont pas sur l'entrée ou la sortie.
     *
     * @param totalKeys Nombre de clés à placer.
     */
    public void generateAllKeys(int totalKeys) {
        int keysPlaced = 0;

        while (keysPlaced < totalKeys) {
            int x = RAND.nextInt(width);
            int y = RAND.nextInt(height);

            if (isPositionValid(x, y, keysPlaced)) {
                this.keyLocations[keysPlaced][0] = x;
                this.keyLocations[keysPlaced][1] = y;
                keysPlaced++;
            }
        }
    }

    /**
     * Déplace le joueur et gère la logique spécifique aux clés.
     * <p>
     * Surcharge la méthode parente pour :
     * <ol>
     * <li>Vérifier si le joueur marche sur une clé (ramassage).</li>
     * <li>Empêcher la fin de partie (statut complet) si toutes les clés ne sont pas collectées,
     * même si le joueur est sur la sortie.</li>
     * </ol>
     *
     * @param direction Direction du mouvement.
     */
    @Override
    public void movePlayer(Direction direction) {
        super.movePlayer(direction);

        checkAndPickUpKey(playerX, playerY);

        if (super.isComplete() && keysCollected < totalKeys) {
            this.complete = false;
        }
    }

    /**
     * Vérifie si une clé se trouve aux coordonnées données et la ramasse.
     * La clé est alors marquée comme "invalide" (-1, -1) dans le tableau.
     */
    private void checkAndPickUpKey(int x, int y) {
        for (int i = 0; i < keyLocations.length; i++) {
            if (keyLocations[i][0] == x && keyLocations[i][1] == y) {
                keyLocations[i][0] = -1;
                keyLocations[i][1] = -1;

                keysCollected++;
                return;
            }
        }
    }

    /**
     * Vérifie si une position est valide pour placer une nouvelle clé.
     *
     * @param x               Coordonnée X candidate.
     * @param y               Coordonnée Y candidate.
     * @param currentKeyCount Nombre de clés déjà placées (pour éviter les doublons).
     * @return {@code true} si la position est libre.
     */
    private boolean isPositionValid(int x, int y, int currentKeyCount) {
        if (x == entryX && y == entryY) return false;
        if (x == exitX && y == exitY) return false;

        for (int i = 0; i < currentKeyCount; i++) {
            if (keyLocations[i][0] == x && keyLocations[i][1] == y) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return Le tableau des positions des clés (les clés ramassées sont à -1, -1).
     */
    public int[][] getKeyLocations() {
        return keyLocations;
    }
}