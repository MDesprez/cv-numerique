package com.MazeApp.game.model.mazes;

/**
 * Implémentation d'un labyrinthe "imparfait" ou "aléatoire".
 * <p>
 * Dans ce type de labyrinthe, chaque case est soit un mur plein, soit un espace vide,
 * déterminé par un pourcentage de densité. Contrairement aux labyrinthes parfaits,
 * celui-ci peut contenir des boucles ou des zones inaccessibles (bien que l'algorithme
 * garantisse que l'entrée et la sortie soient connectées).
 */
public class MazeRandom extends AbstractMaze {
    /** Pourcentage de chances qu'une case soit un mur (ex: 0.3 pour 30%). */
    private double wallPercentage;

    /** Grille représentant le labyrinthe (true = mur, false = vide). */
    private boolean[][] grid;

    /**
     * Construit un labyrinthe aléatoire.
     *
     * @param width          Largeur du labyrinthe.
     * @param height         Hauteur du labyrinthe.
     * @param wallPercentage Densité des murs (entre 0.0 et 1.0).
     */
    public MazeRandom(int width, int height, double wallPercentage) {
        super(width, height);
        this.wallPercentage = wallPercentage;
        this.generate();
        this.resetPlayer();
    }

    /**
     * Génère le labyrinthe en remplissant la grille aléatoirement.
     * <p>
     * La méthode boucle tant que le labyrinthe généré n'est pas valide (pas de chemin
     * entre l'entrée et la sortie) ou trop simple (distance trop courte).
     * Les bordures du labyrinthe sont toujours des murs.
     */
    @Override
    public void generate() {
        this.grid = new boolean[height][width];

        do {
            do {
                generateEntry();
                generateExit();

                for (int i = 0; i < height; i++) {
                    for (int j = 0; j < width; j++) {
                        if (i == 0 || i == height - 1 || j == 0 || j == width - 1) {
                            this.grid[i][j] = true;
                        } else {
                            this.grid[i][j] = RAND.nextDouble() < this.wallPercentage;
                        }
                    }
                }

                this.grid[entryY][entryX] = false;
                this.grid[exitY][exitX] = false;

            } while (!isValid());

            this.minimalDistance = calculateMinimalDistance();

        } while (this.minimalDistance < width);
    }

    /**
     * Vérifie si une case spécifique est un mur.
     *
     * @param row  (Non utilisé pour ce type)
     * @param col  (Non utilisé pour ce type)
     * @param row2 Ligne de la case cible.
     * @param col2 Colonne de la case cible.
     * @return {@code true} si la case cible est un mur.
     */
    @Override
    public boolean isWall(int row, int col, int row2, int col2) {
        return grid[row2][col2];
    }

    public double getWallPercentage() { return wallPercentage; }
    public boolean[][] getGrid() { return grid; }
}