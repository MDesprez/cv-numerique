package com.MazeApp.game.model.mazes;

/**
 * Implémentation d'un labyrinthe généré par l'algorithme de Division Récursive.
 * <p>
 * Cet algorithme commence par un espace vide et le divise récursivement en deux
 * par un mur (horizontal ou vertical) percé d'un trou, jusqu'à ce que l'espace soit trop petit.
 * Cela crée des structures rectangulaires caractéristiques.
 */
public class MazeRecursiveDivision extends AbstractThinWallMaze {

    /**
     * Construit un labyrinthe par division récursive standard.
     *
     * @param width  Largeur du labyrinthe.
     * @param height Hauteur du labyrinthe.
     */
    public MazeRecursiveDivision(int width, int height) {
        super(width, height);
        this.generate();
        generateEntry();
        generateExit();
        this.minimalDistance = calculateMinimalDistance();
    }

    /**
     * Construit un labyrinthe par division récursive avec une contrainte de distance minimale.
     *
     * @param width       Largeur du labyrinthe.
     * @param height      Hauteur du labyrinthe.
     * @param minDistance Distance minimale requise entre l'entrée et la sortie.
     */
    public MazeRecursiveDivision(int width, int height, int minDistance) {
        super(width, height);
        do {
            this.generate();
            generateEntry();
            generateExit();
            this.minimalDistance = calculateMinimalDistance();
        } while (this.minimalDistance < minDistance);
    }

    /**
     * Lance la génération du labyrinthe.
     * Commence avec un labyrinthe vide (sans murs) et appelle la fonction récursive.
     */
    @Override
    public void generate() {
        initWalls(false); // Commence vide
        diviser(0, 0, width, height);
    }

    /**
     * Méthode récursive principale qui divise une chambre en deux sous-chambres.
     *
     * @param xDepart Coordonnée X du coin haut-gauche de la zone actuelle.
     * @param yDepart Coordonnée Y du coin haut-gauche de la zone actuelle.
     * @param largeur Largeur de la zone actuelle.
     * @param hauteur Hauteur de la zone actuelle.
     */
    private void diviser(int xDepart, int yDepart, int largeur, int hauteur) {
        if (largeur < 2 || hauteur < 2) return; // Condition d'arrêt

        boolean estCoupeHorizontale = (largeur > hauteur) ? false : (hauteur > largeur ? true : RAND.nextBoolean());

        if (estCoupeHorizontale) {
            int offsetCoupeY = RAND.nextInt(hauteur - 1);
            int yMur = yDepart + offsetCoupeY;

            for (int x = xDepart; x < xDepart + largeur; x++) {
                murHorizontaux[yMur][x] = true;
            }

            int xPassage = xDepart + RAND.nextInt(largeur);
            murHorizontaux[yMur][xPassage] = false;

            diviser(xDepart, yDepart, largeur, offsetCoupeY + 1);
            diviser(xDepart, yDepart + offsetCoupeY + 1, largeur, hauteur - (offsetCoupeY + 1));

        } else {
            int offsetCoupeX = RAND.nextInt(largeur - 1);
            int xMur = xDepart + offsetCoupeX;

            for (int y = yDepart; y < yDepart + hauteur; y++) {
                murVerticaux[y][xMur] = true;
            }

            int yPassage = yDepart + RAND.nextInt(hauteur);
            murVerticaux[yPassage][xMur] = false;

            diviser(xDepart, yDepart, offsetCoupeX + 1, hauteur);
            diviser(xDepart + offsetCoupeX + 1, yDepart, largeur - (offsetCoupeX + 1), hauteur);
        }
    }
}