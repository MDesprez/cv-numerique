package com.MazeApp.javafx;

import com.MazeApp.game.SaveManager;
import com.MazeApp.game.GameManager;
import com.MazeApp.game.model.Segment;
import com.MazeApp.game.model.mazes.AbstractMaze;
import com.MazeApp.javafx.controllers.*;
import com.MazeApp.javafx.views.*;

import javafx.stage.Stage;

import java.util.HashMap;
import java.util.Map;

public class SceneManager {
    private SaveManager saveManager;
    private SaveController saveController;
    private Stage stage;
    private Stage popUpStage;
    private Map<TypeView, View> views;
    private Map<TypeView, Controller> controlleurs;
    private GameManager gameManager;

    public SceneManager(Stage stage) {
        this.stage = stage;
        this.popUpStage = null;
        this.views = new HashMap<>();
        this.controlleurs = new HashMap<>();
        this.gameManager = new GameManager();
        stage.setTitle("MazeApp");

        MainView mainView = new MainView();
        GameView gameView = new GameView();
        RandomSettingsView randomSettingsView = new RandomSettingsView();
        PostGameView postGameView = new PostGameView();
        SaveView saveView = new SaveView();
        LoginView loginView = new LoginView();
        ProgressionView progressionView = new ProgressionView();
        ChallengeView challengeView = new ChallengeView();
        TypeChoiceView typeChoiceView = new TypeChoiceView();
        PerfectSettingsView perfectSettingsView = new PerfectSettingsView();
        RecursiveSettingsView recursiveSettingsView = new RecursiveSettingsView();
        KeyGameSettingsView keyGameSettingsView = new KeyGameSettingsView();

        this.saveManager = new SaveManager(System.getProperty("user.dir") + "/src/main/resources/saves");
        this.saveController = new SaveController(saveView, this, saveManager);

        this.addView(TypeView.MAIN, mainView, new MainController(mainView, this));
        this.addView(TypeView.GAME, gameView, new GameController(gameView, this));
        this.addView(TypeView.VICTORY, postGameView, new PostGameController(postGameView, this));
        this.addView(TypeView.RANDOMSETTINGS, randomSettingsView, new RandomSettingsController(randomSettingsView, this));
        this.addView(TypeView.PERFECTSETTINGS, perfectSettingsView, new PerfectSettingsController(perfectSettingsView, this));
        this.addView(TypeView.SAVE, saveView, saveController);
        this.addView(TypeView.LOGIN, loginView, new LoginController(loginView, this, saveManager));
        this.addView(TypeView.PROGRESSION, progressionView, new ProgressionController(progressionView, this));
        this.addView(TypeView.DEFI, challengeView, new ChallengeController(challengeView, this));
        this.addView(TypeView.TYPECHOICE, typeChoiceView, new TypeChoiceController(typeChoiceView, this));
        this.addView(TypeView.RECURSIVESETTINGS, recursiveSettingsView, new RecursiveSettingsController(recursiveSettingsView, this));
        this.addView(TypeView.KEYGAME, keyGameSettingsView, new KeyGameSettingsController(keyGameSettingsView, this));
    }

    public void addView(TypeView type, View view, Controller controller) {
        this.views.put(type, view);
        this.controlleurs.put(type, controller);
    }

    public GameManager getGameManager() {
        return gameManager;
    }

    public SaveManager getSaveManager(){
        return saveManager;
    }

    public GameView getGameView() {
        return (GameView) views.get(TypeView.GAME);
    }

    public GameController getGameController() {
        return (GameController) controlleurs.get(TypeView.GAME);
    }

    public void switchView(TypeView type) {
        View view = views.get(type);
        Controller controller = controlleurs.get(type);

        if (view != null) {
            this.stage.setScene(view.getScene());
            if (controller != null) {
                controller.activate();
            }
        }
    }

    public void switchView(AbstractMaze maze) {
        this.gameManager.setMaze(maze);

        View view = views.get(TypeView.GAME);
        GameController controller = getGameController();

        if (controller != null) {
            gameManager.launchGame(controller);
        }

        if (view != null) {
            this.stage.setScene(view.getScene());
            if (controller != null) {
                controller.activate();
            }
        }
    }

    public void openPopUp(TypeView type) {
        View view = views.get(type);
        Controller controller = controlleurs.get(type);
        openPopUpGeneric(view, controller);
    }

    public void openPopUp(Segment segment) {
        View view = views.get(TypeView.DEFI);
        Controller controller = controlleurs.get(TypeView.DEFI);

        if (controller instanceof ChallengeController) {
            ((ChallengeController) controller).activate(segment);
        }
        openPopUpGeneric(view, controller);
    }

    private void openPopUpGeneric(View view, Controller controller) {
        if (popUpStage == null) {
            popUpStage = new Stage();
            popUpStage.setResizable(false);
            popUpStage.initOwner(stage);
            popUpStage.setOnCloseRequest(e -> closePopUp());
        }

        popUpStage.setScene(view.getScene());
        popUpStage.setHeight(450);
        popUpStage.setWidth(600);
        popUpStage.setAlwaysOnTop(true);

        if (controller != null) controller.activate();

        popUpStage.showAndWait();
    }

    public void closePopUp() {
        if (popUpStage != null && popUpStage.isShowing()) {
            popUpStage.close();
            popUpStage = null;
        }
    }

    public Stage getStage(){
        return stage;
    }
}