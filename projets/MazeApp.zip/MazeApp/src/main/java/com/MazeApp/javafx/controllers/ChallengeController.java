package com.MazeApp.javafx.controllers;

import com.MazeApp.game.GameManager;
import com.MazeApp.game.model.Challenge;
import com.MazeApp.game.model.Player;
import com.MazeApp.game.model.Segment;
import com.MazeApp.game.model.ViewMode;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.views.ChallengeView;
import com.MazeApp.javafx.views.TypeView;

import javafx.stage.Stage;

public class ChallengeController implements Controller {
    private ChallengeView view;
    private SceneManager sceneManager;

    public ChallengeController(ChallengeView view, SceneManager sceneManager) {
        this.view = view;
        this.sceneManager = sceneManager;
    }

    @Override
    public void activate() {}

    public void activate(Segment segment) {

        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        GameManager gm = sceneManager.getGameManager();
        Player player = gm.getCurrentPlayer();

        view.getEasyButton().setOnAction(e -> launchGame(gm, player, segment, Challenge.EASY));
        view.getMediumButton().setOnAction(e -> launchGame(gm, player, segment, Challenge.MEDIUM));
        view.getHardButton().setOnAction(e -> launchGame(gm, player, segment, Challenge.HARD));
    }

    private void launchGame(GameManager gm, Player player, Segment segment, Challenge challenge) {
        sceneManager.closePopUp();

        gm.prepareLevel(player, segment, challenge);
        sceneManager.switchView(TypeView.GAME);
        sceneManager.getGameView().setMode(segment.getViewMode());
        gm.launchGame(sceneManager.getGameController());
    }
}