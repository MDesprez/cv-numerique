package com.MazeApp.javafx.controllers;

public interface Controller {
    public void activate();
}
