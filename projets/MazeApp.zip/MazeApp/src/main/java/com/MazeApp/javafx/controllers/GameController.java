package com.MazeApp.javafx.controllers;

import java.lang.reflect.Type;

import com.MazeApp.game.GameManager;
import com.MazeApp.game.model.Direction;
import com.MazeApp.game.model.ViewMode;
import com.MazeApp.game.model.mazes.AbstractMaze;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.observateurs.GameManagerObserver;
import com.MazeApp.javafx.views.GameView;
import com.MazeApp.javafx.views.TypeView;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

public class GameController implements Controller, GameManagerObserver {

    private GameView view;
    private SceneManager sceneManager;

    private int secondsElapsed = 0;
    private Timeline timer;

    public GameController(GameView view, SceneManager sceneManager) {
        this.view = view;
        this.sceneManager = sceneManager;
    }

    @Override
    public void activate() {
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        startTimer();
        this.view.getScene().setOnKeyPressed(this::handleKeyPressed);
        this.view.getScene().getRoot().requestFocus();
    }

    private void handleKeyPressed(KeyEvent e) {
        GameManager gm = this.sceneManager.getGameManager();
        KeyCode code = e.getCode();

        switch (code) {
            case Z: case UP:
                gm.movePlayer(Direction.UP);
                break;
            case S: case DOWN:
                gm.movePlayer(Direction.DOWN);
                break;
            case Q: case LEFT:
                gm.movePlayer(Direction.LEFT);
                break;
            case D: case RIGHT:
                gm.movePlayer(Direction.RIGHT);
                break;

            case L:
                toggleViewMode(ViewMode.LOCAL);
                view.draw(gm.getMaze());
                break;
            case E:
                toggleViewMode(ViewMode.EXPLORATION);
                view.draw(gm.getMaze());
                break;
            case ESCAPE:
                gm.endGame();
                this.sceneManager.switchView(TypeView.MAIN);
                break;
            default:
                break;
        }
    }

    private void toggleViewMode(ViewMode targetMode) {
        if (view.getMode() == targetMode) {
            view.setMode(ViewMode.NORMAL);
        } else {
            view.setMode(targetMode);
        }
    }

    @Override
    public void update(GameManager gameManager) {
        AbstractMaze maze = gameManager.getMaze();
        if (maze == null) return;

        this.view.draw(maze);

        if (view.getMovesLabel() != null) {
            view.getMovesLabel().setText("Déplacements : " + maze.getMoves());
        }

        if (maze.isComplete() && timer.getStatus() == Timeline.Status.RUNNING) {
            stopTimer();
            gameManager.endGame();
            sceneManager.openPopUp(TypeView.VICTORY);
        }
    }

    private void startTimer() {
        stopTimer();
        secondsElapsed = 0;
        timer = new Timeline(new KeyFrame(Duration.seconds(1), e -> updateTimerUI()));
        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();
    }

    private void updateTimerUI() {
        secondsElapsed++;
        int minutes = secondsElapsed / 60;
        int seconds = secondsElapsed % 60;
        String formattedTime = String.format("Temps : %02d:%02d", minutes, seconds);

        if (view.getTimerLabel() != null) {
            view.getTimerLabel().setText(formattedTime);
        }
    }

    public void stopTimer() {
        if (timer != null) {
            timer.stop();
        }
    }
}