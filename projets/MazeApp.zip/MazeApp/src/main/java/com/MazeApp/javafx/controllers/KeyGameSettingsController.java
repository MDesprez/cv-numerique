package com.MazeApp.javafx.controllers;

import com.MazeApp.game.model.ViewMode;
import com.MazeApp.game.model.mazes.AbstractMaze;
import com.MazeApp.game.model.mazes.MazeFactory;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.views.KeyGameSettingsView;
import com.MazeApp.javafx.views.TypeView;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class KeyGameSettingsController implements Controller {

    private KeyGameSettingsView view;
    private SceneManager sceneManager;

    public KeyGameSettingsController(KeyGameSettingsView view, SceneManager sceneManager) {
        this.view = view;
        this.sceneManager = sceneManager;
    }

    @Override
    public void activate() {
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        this.view.getValidationBtn().setOnAction(e -> this.verifParam());
        this.view.getCancelBtn().setOnAction(e -> this.cancel());
    }

    public void verifParam() {
        try {
            int width = (int) view.getSliderWidth().getValue();
            int height = (int) view.getSliderHeight().getValue();
            int dist = (int) view.getSliderDistance().getValue();
            int nbKeys = (int) view.getSliderKeys().getValue();

            ViewMode selectedMode = view.getViewModeComboBox().getValue();

            if (width < 5 || width > 50 || height < 5 || height > 50) {
                errorParam("Erreur de taille", "La taille doit être comprise entre 5 et 50 !");
                return;
            }
            if (dist < 2 || dist > Math.max(width, height)) {
                errorParam("Erreur de distance", "La distance minimale est invalide (trop grande pour la taille choisie).");
                return;
            }

            sceneManager.closePopUp();
            sceneManager.getGameView().setMode(selectedMode);
            sceneManager.switchView(MazeFactory.keyGame(width, height, dist, nbKeys));


        } catch (Exception e) {
            e.printStackTrace();
            errorParam("Erreur critique", "Une erreur est survenue lors de la création du niveau : " + e.getMessage());
        }
    }

    public void cancel() {
        this.sceneManager.switchView(TypeView.MAIN);
    }

    private void errorParam(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}