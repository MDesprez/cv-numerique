package com.MazeApp.javafx.controllers;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.MazeApp.game.SaveManager;
import com.MazeApp.game.model.Player;
import com.MazeApp.game.model.Save;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.views.LoginView;
import com.MazeApp.javafx.views.TypeView;

import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class LoginController implements Controller {

    private final LoginView view;
    private SceneManager sceneManager;
    private SaveManager saveManager;

    public LoginController(LoginView view, SceneManager sceneManager, SaveManager saveManager) {
        this.view = view;
        this.sceneManager = sceneManager;
        this.saveManager = new SaveManager(Save.getPath());
        
    }

    @Override
    public void activate() {
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        view.getLoginAccountButton().setOnAction(e -> login());
        view.getCreateAccountButton().setOnAction(e -> register());
        view.getReturnButton().setOnAction(e -> returnMain());
    }

    private boolean checkLogin() {
        String username = view.getUsernameField().getText();
        String password = view.getPasswordField().getText();

        if (username.isEmpty() || password.isEmpty()) {
            this.view.getWarnLabel().setText("Veuillez entrer un nom / mot de passe");
            return false;
        }
        // Parcours toutes les sauvegardes existantes pour trouver le joueur
        List<String> playerFolders = saveManager.listSavesByUsername(username);
        
        for (String folder : playerFolders) {
            System.out.println(folder);
            List<String> saves = saveManager.listSavesByFolder(folder);
            for (String fileName : saves) {
                Save save = saveManager.loadByFolder(folder, fileName);
                if (save != null) {
                    Player player = save.getPlayer();
                    if (player.getName().equals(username) && player.getPassword().equals(password)) {
                        sceneManager.getGameManager().setCurrentPlayer(player);
                        System.out.println("Connexion reussie " + username + " bravo t'es le meilleur");
                        return true;
                    }
                }
            }
        }
        System.out.println("Nom d'utilisateur ou mot de passe incorrect");
        return false;
    }
 


    private boolean register() {
        String username = view.getUsernameField().getText();
        String password = view.getPasswordField().getText();

        if (username.isEmpty() || password.isEmpty()) {
            view.getWarnLabel().setVisible(true);
            view.getWarnLabel().setText("Veuillez rentrer un texte");
            return false;
        }
        Player player = new Player(username, password);
        saveManager.save(player);

        sceneManager.getGameManager().setCurrentPlayer(player);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Infobulle");
        alert.setHeaderText("Joueur " + player.getName() + " créé !");
        alert.showAndWait();

        this.sceneManager.switchView(TypeView.MAIN);
        System.out.println("COMPTE CREE : " + username);
        return true;
    }

    private void login() {
        if (checkLogin()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Infobulle");
            alert.setHeaderText(sceneManager.getGameManager().getCurrentPlayer().getName() + " connecté !");
            alert.showAndWait();
            this.sceneManager.switchView(TypeView.MAIN);
        }
    }

    private void returnMain() {
        this.sceneManager.switchView(TypeView.MAIN);
    }

    public String getUsernameField() {
        return view.getUsernameField().getText();
    }
}
