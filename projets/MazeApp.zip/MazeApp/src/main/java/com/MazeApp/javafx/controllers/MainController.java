package com.MazeApp.javafx.controllers;

import com.MazeApp.game.GameManager;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.observateurs.GameManagerObserver;
import com.MazeApp.javafx.views.MainView;
import com.MazeApp.javafx.views.TypeView;

import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class MainController implements Controller, GameManagerObserver {
    private MainView view;
    private SceneManager sceneManager;

    public MainController(MainView view, SceneManager sceneManager) {
        this.view = view;
        this.sceneManager = sceneManager;
    }

    @Override
    public void update(GameManager gameManager) {
        if (gameManager.getCurrentPlayer() != null)
            this.view.getCurrentPlayerLabel().setText(gameManager.getCurrentPlayer().getName());
    }

    public void activate() {
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        
        if(sceneManager.getGameManager().getCurrentPlayer()==null){
            this.view.getSaveButton().setDisable(true);
        }else{
            this.view.getSaveButton().setDisable(false); // necessaire pour changer l'état quand on revient connecté
        }

        this.view.getPlayButton().setOnAction((e) -> {
            // A MODIFIER
            this.sceneManager.openPopUp(TypeView.TYPECHOICE);
            //TODO : Arriver sur TypeChoiceController une fois celui ci fini
        });

        this.view.getProgressionButton().setOnAction((e) -> {
            if(sceneManager.getGameManager().getCurrentPlayer()!=null){
                this.sceneManager.switchView(TypeView.PROGRESSION);
            }else{
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Veuillez d'abord vous connecter / créer un compte");
                alert.showAndWait();
                this.sceneManager.switchView(TypeView.LOGIN);
            }
        });

        this.view.getSaveButton().setOnAction((e) -> {
            this.sceneManager.switchView(TypeView.SAVE);
        });

        this.view.getLoginButton().setOnAction((e) -> {
            this.sceneManager.switchView(TypeView.LOGIN);
        });

        this.view.getQuitButton().setOnAction((e) -> {
            System.exit(0);
        });
        
        if(sceneManager.getGameManager().getCurrentPlayer()!=null)
            view.getCurrentPlayerLabel().setText(sceneManager.getGameManager().getCurrentPlayer().getName().toUpperCase());
    }
}
