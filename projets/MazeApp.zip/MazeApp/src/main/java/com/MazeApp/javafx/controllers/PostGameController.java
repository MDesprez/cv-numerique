package com.MazeApp.javafx.controllers;

import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.views.TypeView;

import javafx.stage.Stage;

import com.MazeApp.javafx.views.PostGameView;

public class PostGameController implements Controller {
    private PostGameView view;
    private SceneManager sceneManager;

    public PostGameController(PostGameView view, SceneManager sceneManager) {
        this.view = view;
        this.sceneManager = sceneManager;
    }

    @Override
    public void activate() {
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        this.view.getMinimalDistance().setText("La distance minimale était de " + this.sceneManager.getGameManager().getMaze().getMinimalDistance() + " coups.");
        this.view.getStats().setText("Vous avez terminé en " + this.sceneManager.getGameManager().getMaze().getMoves() + " coups.");
        this.view.getReturnButton().setOnAction(e -> this.menuReturn());
    }

    public void menuReturn() {
        sceneManager.closePopUp();
        sceneManager.switchView(TypeView.MAIN);
    }
}