package com.MazeApp.javafx.controllers;
import com.MazeApp.game.GameManager;
import com.MazeApp.game.model.Player;
import com.MazeApp.game.GameManager;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.observateurs.GameManagerObserver;
import com.MazeApp.javafx.views.ProgressionView;
import com.MazeApp.javafx.views.TypeView;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class ProgressionController implements Controller, GameManagerObserver {
    private ProgressionView view;
    private SceneManager sceneManager;
    
  

    public ProgressionController(ProgressionView progressionView, SceneManager sceneManager) {
        this.view = progressionView;
        this.sceneManager = sceneManager;
    }

    @Override
    public void activate() {
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);

        this.view.draw(sceneManager.getGameManager().getCurrentPlayer());
        Player currentPlayer = sceneManager.getGameManager().getCurrentPlayer();
        this.view.draw(currentPlayer);
        whichLocked(currentPlayer);

        this.view.getLevelOneCard().setOnMouseClicked((e) -> {
            sceneManager.openPopUp(this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(0));
        });

        this.view.getLevelTwoCard().setOnMouseClicked((e) -> {
            if (!this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(0).getIsValid()) {
                errorParam("Erreur", "Vous devez valider l'étape précédente avant de pouvoir lancer celle-ci");
            }
            else sceneManager.openPopUp(this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(1));
        });

        this.view.getLevelThreeCard().setOnMouseClicked((e) -> {
            if (!this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(1).getIsValid()) {
                errorParam("Erreur", "Vous devez valider l'étape précédente avant de pouvoir lancer celle-ci");
            } else {
                sceneManager.openPopUp(this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(2));
            }
        });

        this.view.getLevelFourCard().setOnMouseClicked((e) -> {
            if (!this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(2).getIsValid()) {
                errorParam("Erreur", "Vous devez valider l'étape précédente avant de pouvoir lancer celle-ci");
            } else {
                sceneManager.openPopUp(this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(3));
            }
        });

        this.view.getLevelFiveCard().setOnMouseClicked((e) -> {
            if (!this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(3).getIsValid()) {
                errorParam("Erreur", "Vous devez valider l'étape précédente avant de pouvoir lancer celle-ci");
            } else {
                sceneManager.openPopUp(this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(4));
            }
        });

        this.view.getLevelSixCard().setOnMouseClicked((e) -> {
            if (!this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(3).getIsValid()) {
                errorParam("Erreur", "Vous devez valider l'étape précédente avant de pouvoir lancer celle-ci");
            } else {
                sceneManager.openPopUp(this.sceneManager.getGameManager().getCurrentPlayer().getSegment().get(5));
            }
        });

        this.view.getReturn().setOnAction((e) -> {
            this.sceneManager.switchView(TypeView.MAIN);    
        });


    }

        private void whichLocked(Player player) { //renvoie à la vue les niveaux pas encore débloqués
            //au cas où
        this.view.getLevelOneCard().setDisable(false);
      
        boolean lvl1Valid = player.getSegment().get(0).getIsValid();
        this.view.getLevelTwoCard().setDisable(!lvl1Valid);

        boolean lvl2Valid = player.getSegment().get(1).getIsValid();
        this.view.getLevelThreeCard().setDisable(!lvl2Valid);

        boolean lvl3Valid = player.getSegment().get(2).getIsValid();
        this.view.getLevelFourCard().setDisable(!lvl3Valid);

        boolean lvl4Valid = player.getSegment().get(3).getIsValid();
        this.view.getLevelFiveCard().setDisable(!lvl4Valid);

        boolean lvl5Valid = player.getSegment().get(4).getIsValid();
        this.view.getLevelSixCard().setDisable(!lvl5Valid);
    }



    @Override
    public void update(GameManager gameManager) {
        Player currentPlayer = gameManager.getCurrentPlayer(); // récupère le joueur actuel
        this.view.draw(currentPlayer);
        whichLocked(currentPlayer);
    }


    private void errorParam(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(titre);
        alert.setHeaderText(message);
        alert.showAndWait();
    }


}
