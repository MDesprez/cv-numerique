package com.MazeApp.javafx.controllers;

import com.MazeApp.game.model.mazes.MazeFactory;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.views.RandomSettingsView;
import com.MazeApp.javafx.views.TypeView;

import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class RandomSettingsController implements Controller {
    private RandomSettingsView view;
    private SceneManager sceneManager;

    public RandomSettingsController(RandomSettingsView view, SceneManager sceneManager) {
        this.view = view;
        this.sceneManager = sceneManager;
    }

    @Override
    public void activate() {
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);

        this.view.getValidationBtn().setOnAction(e -> this.verifParam());
        this.view.getCancelBtn().setOnAction(e -> this.cancel());
        this.view.getSliderPercentage().valueProperty().addListener((obs, old, nouveau) -> {
            this.view.getLblPercentage().setText((int)(nouveau.doubleValue() * 100) + "%");
        });
    }

    public void verifParam() {
        try {
            int width = Integer.parseInt(view.getTxtWidth().getText());
            int height = Integer.parseInt(view.getTxtHeight().getText());

            if(width < 5 || width > 50 || height < 5 || height > 50) {
                errorParam("Erreur", "la taille des deux paramètres doit être entre 5 et 50 !");
                return;
            }

            sceneManager.closePopUp();
            sceneManager.switchView(MazeFactory.random(width, height, this.view.getSliderPercentage().getValue()));
        } catch (NumberFormatException e) {
            errorParam("Erreur", "Veuillez entrer des nombres valides");
        }
    }


    public void cancel() {
        this.sceneManager.switchView(TypeView.MAIN);
    }

    private void errorParam(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(message);
        alert.showAndWait();
    }
}