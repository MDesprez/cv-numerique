package com.MazeApp.javafx.controllers;

import com.MazeApp.game.SaveManager;
import com.MazeApp.game.model.Player;
import com.MazeApp.game.model.Save;
import com.MazeApp.javafx.SceneManager;
import com.MazeApp.javafx.views.SaveView;
import com.MazeApp.javafx.views.TypeView;

import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.util.List;

public class SaveController implements Controller {

    private SaveView view;
    private SceneManager sceneManager;
    private SaveManager saveManager;

    public SaveController(SaveView view, SceneManager sceneManager, SaveManager saveManager) {
        this.view = view;
        this.sceneManager = sceneManager;
        this.saveManager = saveManager;
    }

    @Override
    public void activate() {
        updateSaveList();
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        view.getReturnButton().setOnAction(e -> sceneManager.switchView(TypeView.MAIN));
        view.getSaveButton().setOnAction(e -> {
            Player player = sceneManager.getGameManager().getCurrentPlayer();
            saveManager.save(player);
            updateSaveList();
        });
        view.getLoadButton().setOnAction(e -> loadSave());
        view.getDeleteButton().setOnAction(e -> deleteSave());
    }

    private void loadSave() {
        String fileName = view.getSaveList().getSelectionModel().getSelectedItem();
        if (fileName == null) return;

        Player player = sceneManager.getGameManager().getCurrentPlayer();
        Save save = saveManager.load(player, fileName);
        if (save != null) sceneManager.getGameManager().setCurrentPlayer(save.getPlayer());
    }

    private void deleteSave() {
        String fileName = view.getSaveList().getSelectionModel().getSelectedItem();
        if (fileName == null) return;

        Player player = sceneManager.getGameManager().getCurrentPlayer();
        saveManager.delete(player, fileName);
        updateSaveList();
    }

    private void updateSaveList() {
        view.getSaveList().getItems().clear();
        Player player = sceneManager.getGameManager().getCurrentPlayer();
        List<String> saves = saveManager.listSaves(player);
        view.getSaveList().getItems().addAll(saves);
    }
}
