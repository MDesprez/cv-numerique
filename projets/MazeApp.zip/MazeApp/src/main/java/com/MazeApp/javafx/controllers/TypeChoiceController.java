package com.MazeApp.javafx.controllers;

import com.MazeApp.game.model.mazes.MazeFactory;
import com.MazeApp.javafx.views.TypeChoiceView;
import com.MazeApp.javafx.observateurs.GameManagerObserver;
import com.MazeApp.javafx.views.TypeView;

import javafx.stage.Stage;

import com.MazeApp.game.GameManager;
import com.MazeApp.javafx.SceneManager;


public class TypeChoiceController implements Controller, GameManagerObserver {

    private TypeChoiceView view;
    private SceneManager sceneManager;

    public TypeChoiceController(TypeChoiceView typeChoiceView, SceneManager sceneManager){
        this.view = typeChoiceView;
        this.sceneManager = sceneManager;
    }

    @Override
    public void activate(){
        Stage stage = sceneManager.getStage(); 
        stage.setFullScreen(false); // pas de fullscreen, pas de resize, pas de responsive :)
        stage.setResizable(false);
        this.view.getRandomButton().setOnAction((e) -> {
            this.sceneManager.closePopUp();
            this.sceneManager.switchView(TypeView.RANDOMSETTINGS);
        });

        this.view.getPerfectButton().setOnAction((e) -> {
            this.sceneManager.closePopUp();
            this.sceneManager.switchView(TypeView.PERFECTSETTINGS);
        });

        this.view.getRecursiveButton().setOnAction((e) -> {
            this.sceneManager.closePopUp();
            this.sceneManager.switchView(TypeView.RECURSIVESETTINGS);
        });

        this.view.getKeyGameButton().setOnAction((e) -> {
            this.sceneManager.closePopUp();
            this.sceneManager.switchView(TypeView.KEYGAME);
        });

        this.view.getReturnButton().setOnAction((e) -> {
            this.sceneManager.closePopUp();
        });
    }

    @Override
    public void update(GameManager gameManager) {
        
    }
    
}
