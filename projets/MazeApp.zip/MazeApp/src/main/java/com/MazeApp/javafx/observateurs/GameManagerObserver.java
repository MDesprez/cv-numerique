package com.MazeApp.javafx.observateurs;

import com.MazeApp.game.GameManager;

public interface GameManagerObserver {
    public void update(GameManager gameManager);
}
