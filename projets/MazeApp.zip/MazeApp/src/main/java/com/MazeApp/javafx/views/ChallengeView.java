package com.MazeApp.javafx.views;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;


public class ChallengeView implements View {
    private Scene scene;
    private VBox root;
    private Button easyButton;
    private Button mediumButton;
    private Button hardButton;

    public ChallengeView() {
        this.easyButton = new Button("Facile");
        this.mediumButton = new Button("Medium");
        this.hardButton = new Button("Difficile");
        this.root = new VBox();
        this.root.getChildren().addAll(easyButton, mediumButton, hardButton);
        this.scene = new Scene(root, TypeView.DEFI.getWidth(), TypeView.DEFI.getHeight());
        scene.getStylesheets().add(getClass().getResource("/css/challenge.css").toExternalForm());
    }
    @Override
    public Scene getScene() {
        return scene;
    }

    public Button getEasyButton() {return easyButton;}
    public Button getMediumButton() {return mediumButton;}
    public Button getHardButton() {return hardButton;}
}
