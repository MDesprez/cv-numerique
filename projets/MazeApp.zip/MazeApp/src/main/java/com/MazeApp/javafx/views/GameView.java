package com.MazeApp.javafx.views;

import com.MazeApp.game.model.ViewMode;
import com.MazeApp.game.model.mazes.AbstractMaze;
import com.MazeApp.game.model.mazes.MazeRandom;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import com.MazeApp.game.model.mazes.MazePerfectRecursiveKeyMiniGame;

public class GameView implements View {

    private BorderPane root;
    private Scene scene;

    // attributs concernant la vue du mode normal
    private StackPane globalCenterPane;
    private Canvas mazeCanvas;
    private Canvas playerCanvas;

    // attributs concernant la vue du mode local
    private BorderPane bottomContainer;
    private VBox infoPanel;
    private StackPane localTopContainer;
    private Canvas canvasGlobal;
    private Canvas canvasLocal;
    private Label timerLabel;
    private Label movesLabel;
    
    // attributs concernant la vue Bob
    private boolean[][] bobDiscovered;
    private AbstractMaze bobMazeRef;

    // attributs modifiables selon les envies
    private int cellSize = 25;
    private int localCellSize = 40;
    private int localGlobalCellSize = 10;
    private static final int LOCAL_VISION_RADIUS = 2;
    private final int EXPLORATION_RADIUS = 3;
    private final int BOB_RADIUS =3;

    // mode de vue par défaut à normal
    private ViewMode mode = ViewMode.NORMAL;

    public GameView() {
        root = new BorderPane();
        double w = TypeView.GAME.getWidth();
        double h = TypeView.GAME.getHeight();
        
        mazeCanvas = new Canvas(w, h);
        playerCanvas = new Canvas(w, h);
        globalCenterPane = new StackPane(mazeCanvas, playerCanvas);
        globalCenterPane.setPadding(new Insets(10));
        globalCenterPane.setAlignment(Pos.CENTER);
        root.setCenter(globalCenterPane);

        prepareLocalLayout();

        this.scene = new Scene(root, w, h);
        this.scene.getStylesheets().add(getClass().getResource("/css/gamelocal.css").toExternalForm());
        /* forcer le CSS */
        root.getStyleClass().add("root");
        timerLabel.getStyleClass().add("info-text");
        bottomContainer.getStyleClass().add("bottom-container");
        

    }

    //  méthode draw principale de la classe. On passe par celle-ci pour dessiner les différents modes de jeu
    //  via les méthodes intermédiaires
    public void draw(AbstractMaze maze) {
        if (maze == null) return;

        if (mode == ViewMode.LOCAL) {
            setupLocalLayout();

            adaptCellSize(maze, canvasGlobal, true);
            renderMaze(canvasGlobal.getGraphicsContext2D(), maze, localGlobalCellSize, 0, 0, 0, true);

            renderLocalView(maze);
        } else if (mode == ViewMode.EXPLORATION || mode == ViewMode.NORMAL) {
            setupGlobalLayout();

            adaptCellSize(maze, mazeCanvas, false);

            double usedW = maze.getWidth() * cellSize;
            double usedH = maze.getHeight() * cellSize;
            double offX = (mazeCanvas.getWidth() - usedW) / 2.0;
            double offY = (mazeCanvas.getHeight() - usedH) / 2.0;

            int radius = (mode == ViewMode.EXPLORATION) ? EXPLORATION_RADIUS : 0;

            renderMaze(mazeCanvas.getGraphicsContext2D(), maze, cellSize, offX, offY, radius, false);
            renderPlayer(playerCanvas.getGraphicsContext2D(), maze, cellSize, offX, offY);
        } else {
            renderBob(maze);
        }
    }

    private void renderMaze(GraphicsContext gc, AbstractMaze maze, int cSize, double offX, double offY, int visionRadius, boolean isMiniMap) {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());

        gc.setFill(isMiniMap ? Color.BLACK : (visionRadius > 0 ? Color.BLACK : Color.WHITE));
        if (!isMiniMap && visionRadius == 0 && maze instanceof MazeRandom) gc.setFill(Color.BLACK);
        gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());

        if (maze instanceof MazeRandom) {
            renderBlockMaze((MazeRandom) maze, gc, cSize, offX, offY, visionRadius);
        } else {
            renderThinWallMaze(maze, gc, cSize, offX, offY, visionRadius, isMiniMap);
        }
    }

    // méthode draw concernant les labyrinthes aléatoires (murs en cellules pleines)
    private void renderBlockMaze(MazeRandom maze, GraphicsContext gc, int size, double offX, double offY, int radius) {
        int rows = maze.getHeight();
        int cols = maze.getWidth();
        boolean fog = (radius > 0);

        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                if (fog && !isVisible(maze, y, x, radius)) continue;

                double px = offX + x * size;
                double py = offY + y * size;
                boolean isWall = maze.isWall(0, 0, y, x);

                if (isWall) {
                    gc.setFill(Color.BLACK);
                    gc.fillRect(px, py, size, size);
                } else {
                    gc.setFill(Color.WHITE);
                    gc.fillRect(px, py, size, size);
                    gc.setStroke(Color.LIGHTGRAY);
                    gc.setLineWidth(0.5);
                    gc.strokeRect(px, py, size, size);
                }

                drawMarkers(gc, maze, x, y, px, py, size);
            }
        }
    }

    //  méthode draw contenant les labyrinthes parfaits (murs fins)
    private void renderThinWallMaze(AbstractMaze maze, GraphicsContext gc, int size, double offX, double offY, int radius, boolean isMiniMap) {
        int rows = maze.getHeight();
        int cols = maze.getWidth();
        boolean fog = (radius > 0);

        gc.setStroke(Color.BLACK);
        gc.setLineWidth(isMiniMap ? 1.0 : 2.0);

        if (!fog && !isMiniMap) {
            gc.setFill(Color.WHITE);
            gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        }

        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < cols; x++) {
                if (fog && !isVisible(maze, y, x, radius)) continue;

                double px = offX + x * size;
                double py = offY + y * size;

                if (fog) {
                    gc.setFill(Color.WHITE);
                    gc.fillRect(px, py, size, size);
                } else if (isMiniMap) {
                    gc.setFill(Color.WHITE);
                    gc.fillRect(px, py, size, size);
                }

                if (maze.isWall(y, x, y - 1, x)) gc.strokeLine(px, py, px + size, py);
                if (maze.isWall(y, x, y, x - 1)) gc.strokeLine(px, py, px, py + size);
                if (maze.isWall(y, x, y + 1, x)) gc.strokeLine(px, py + size, px + size, py + size);
                if (maze.isWall(y, x, y, x + 1)) gc.strokeLine(px + size, py, px + size, py + size);

                drawMarkers(gc, maze, x, y, px, py, size);
            }
        }

        drawKeys(gc, maze, size, offX, offY, radius);
    }

    //  méthode draw concernant la mini vue autour du joueur en mode local et bob
    private void renderLocalView(AbstractMaze maze) {
        GraphicsContext gc = canvasLocal.getGraphicsContext2D();
        gc.clearRect(0, 0, canvasLocal.getWidth(), canvasLocal.getHeight());

        int px = maze.getPlayerX();
        int py = maze.getPlayerY();

        for (int dy = -LOCAL_VISION_RADIUS; dy <= LOCAL_VISION_RADIUS; dy++) {
            for (int dx = -LOCAL_VISION_RADIUS; dx <= LOCAL_VISION_RADIUS; dx++) {
                int wx = px + dx;
                int wy = py + dy;

                double scrX = (dx + LOCAL_VISION_RADIUS) * localCellSize;
                double scrY = (dy + LOCAL_VISION_RADIUS) * localCellSize;

                if (!isValidCoord(maze, wy, wx)) {
                    gc.setFill(Color.DARKGRAY);
                    gc.fillRect(scrX, scrY, localCellSize, localCellSize);
                    continue;
                }

                if (maze instanceof MazeRandom) {
                    boolean wall = maze.isWall(0, 0, wy, wx);
                    gc.setFill(wall ? Color.BLACK : Color.WHITE);
                    gc.fillRect(scrX, scrY, localCellSize, localCellSize);
                    gc.setStroke(Color.LIGHTGRAY);
                    gc.strokeRect(scrX, scrY, localCellSize, localCellSize);
                } else {
                    gc.setFill(Color.WHITE);
                    gc.fillRect(scrX, scrY, localCellSize, localCellSize);
                    gc.setStroke(Color.BLACK);
                    gc.setLineWidth(3);

                    if (maze.isWall(wy, wx, wy - 1, wx)) gc.strokeLine(scrX, scrY, scrX + localCellSize, scrY); // Haut
                    if (maze.isWall(wy, wx, wy + 1, wx)) gc.strokeLine(scrX, scrY + localCellSize, scrX + localCellSize, scrY + localCellSize); // Bas
                    if (maze.isWall(wy, wx, wy, wx - 1)) gc.strokeLine(scrX, scrY, scrX, scrY + localCellSize); // Gauche
                    if (maze.isWall(wy, wx, wy, wx + 1)) gc.strokeLine(scrX + localCellSize, scrY, scrX + localCellSize, scrY + localCellSize); // Droite
                }

                if (maze instanceof MazePerfectRecursiveKeyMiniGame) {
                    MazePerfectRecursiveKeyMiniGame keyMaze = (MazePerfectRecursiveKeyMiniGame) maze;
                    int[][] keys = keyMaze.getKeyLocations();
                    for (int[] k : keys) {
                        if (k[0] == wx && k[1] == wy) {
                            gc.setFill(Color.GOLD);
                            double kSize = localCellSize * 0.6;
                            double offset = (localCellSize - kSize) / 2.0;
                            gc.fillOval(scrX + offset, scrY + offset, kSize, kSize);
                        }
                    }
                }

                drawMarkers(gc, maze, wx, wy, scrX, scrY, localCellSize);
            }
        }

        applyFog(gc);
        double center = (LOCAL_VISION_RADIUS * localCellSize) + (localCellSize / 2.0);
        double r = localCellSize * 0.35;
        gc.setFill(Color.CORNFLOWERBLUE);
        gc.fillOval(center - r, center - r, r * 2, r * 2);
    }

    // méthode draw concernant le mode Bob
    private void renderBob(AbstractMaze maze) {
        // même layout que la vue locale : global en haut, mini-vue en bas
        setupLocalLayout();

        // (ré)initialisation de la mémoire d'exploration si le labyrinthe change
        if (bobMazeRef != maze
                || bobDiscovered == null
                || bobDiscovered.length != maze.getHeight()
                || bobDiscovered[0].length != maze.getWidth()) {

            bobMazeRef = maze;
            bobDiscovered = new boolean[maze.getHeight()][maze.getWidth()];
        }

        adaptCellSize(maze, canvasGlobal, true); // calcule localGlobalCellSize

        renderMaze(
                canvasGlobal.getGraphicsContext2D(),
                maze,
                localGlobalCellSize,
                0,
                0,
                BOB_RADIUS,
                false
        );

        renderLocalView(maze);
    }

    // méthode draw concernant les markers représentant l'entrée et la sortie du labyrinthe
    private void drawMarkers(GraphicsContext gc, AbstractMaze maze, int x, int y, double px, double py, int size) {
        if (x == maze.getEntryX() && y == maze.getEntryY()) {
            gc.setFill(Color.RED);
            drawCenteredRect(gc, px, py, size, 0.6);
        } else if (x == maze.getExitX() && y == maze.getExitY()) {
            gc.setFill(Color.LIGHTGREEN);
            drawCenteredRect(gc, px, py, size, 0.6);
        }
    }

    // méthode draw des rectangles représentant entrée et sortie 
    private void drawCenteredRect(GraphicsContext gc, double px, double py, int size, double scale) {
        double s = size * scale;
        double offset = (size - s) / 2.0;
        gc.fillRect(px + offset, py + offset, s, s);
    }

    private void drawKeys(GraphicsContext gc, AbstractMaze maze, int size, double offX, double offY, int radius) {
        if (maze instanceof MazePerfectRecursiveKeyMiniGame) {
            MazePerfectRecursiveKeyMiniGame keyMaze = (MazePerfectRecursiveKeyMiniGame) maze;
            int[][] keys = keyMaze.getKeyLocations();

            gc.setFill(Color.GOLD);
            gc.setStroke(Color.DARKGOLDENROD);
            gc.setLineWidth(1);

            for (int[] k : keys) {
                int kx = k[0];
                int ky = k[1];

                if (kx != -1 && ky != -1) {

                    if (radius > 0 && !isVisible(maze, ky, kx, radius)) {
                        continue;
                    }

                    double px = offX + kx * size;
                    double py = offY + ky * size;

                    double kSize = size * 0.6;
                    double offset = (size - kSize) / 2.0;

                    gc.fillOval(px + offset, py + offset, kSize, kSize);
                    gc.strokeOval(px + offset, py + offset, kSize, kSize);
                }
            }
        }
    }

    // méthode draw du joueur dans le maze 
    private void renderPlayer(GraphicsContext gc, AbstractMaze maze, int size, double offX, double offY) {
        gc.clearRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        double r = size * 0.4;
        double cx = offX + (maze.getPlayerX() + 0.5) * size;
        double cy = offY + (maze.getPlayerY() + 0.5) * size;
        gc.setFill(Color.CORNFLOWERBLUE);
        gc.fillOval(cx - r, cy - r, r * 2, r * 2);
    }

    private void adaptCellSize(AbstractMaze maze, Canvas canvas, boolean isLocalGlobal) {
        double w = canvas.getWidth();
        double h = canvas.getHeight();
        double cW = w / maze.getWidth();
        double cH = h / maze.getHeight();
        int s = (int) Math.min(cW, cH);
        if (s < 1) s = 1;

        if (isLocalGlobal) this.localGlobalCellSize = s;
        else this.cellSize = s;
    }

    // méthode concernant les modes Exploration et Bob. Test si une case est visible dans le champ de vision actuel du joueur
    private boolean isVisible(AbstractMaze maze, int row, int col, int radius) {
        if (radius <= 0) return true;

        boolean currentlyVisible =
                Math.abs(row - maze.getPlayerY()) <= radius &&
                Math.abs(col - maze.getPlayerX()) <= radius;

        // Mode BOB : on garde en mémoire les cases déjà vues
        if (mode == ViewMode.BOB &&
            bobDiscovered != null &&
            maze == bobMazeRef &&
            row >= 0 && row < bobDiscovered.length &&
            col >= 0 && col < bobDiscovered[0].length) {

            // si la case est dans le champ de vision actuel, on la marque comme découverte
            if (currentlyVisible) {
                bobDiscovered[row][col] = true;
            }

            // visible si actuellement dans le rayon OU déjà découverte
            return currentlyVisible || bobDiscovered[row][col];
        }

        // autres modes (EXPLORATION) : visibilité classique
        return currentlyVisible;
    }

    //  méthode de test de la validité des coordonnées
    private boolean isValidCoord(AbstractMaze maze, int r, int c) {
        return r >= 0 && r < maze.getHeight() && c >= 0 && c < maze.getWidth();
    }

    //  méthode concernant le mode local, avec le brouillard sur la mini-vue du joueur
    private void applyFog(GraphicsContext gc) {
        double center = (LOCAL_VISION_RADIUS * localCellSize) + (localCellSize / 2.0);
        RadialGradient fog = new RadialGradient(0, 0, center, center, localCellSize * 2.5, false, CycleMethod.NO_CYCLE,
                new Stop(0.0, Color.TRANSPARENT), new Stop(0.8, Color.color(0, 0, 0, 0.6)), new Stop(1.0, Color.BLACK));
        gc.setFill(fog);
        gc.fillRect(0, 0, canvasLocal.getWidth(), canvasLocal.getHeight());
    }

    // méthode d'initialisation des composants de la vue en mode local
    private void prepareLocalLayout() {
        bottomContainer = new BorderPane();
        bottomContainer.setPadding(new Insets(20));
        bottomContainer.setPrefHeight(250);
        bottomContainer.setBackground(new Background(new BackgroundFill(Color.rgb(245, 245, 245), CornerRadii.EMPTY, Insets.EMPTY)));

        infoPanel = new VBox(15);
        infoPanel.setAlignment(Pos.CENTER);
        infoPanel.setPrefWidth(300);
        infoPanel.getStyleClass().add("info-panel");

        timerLabel = new Label("Temps : 00:00");
        timerLabel.getStyleClass().add("info-text");

        movesLabel = new Label("Déplacements : 0");
        movesLabel.getStyleClass().add("info-text");

        infoPanel.getChildren().addAll(new Label("Informations"), timerLabel, movesLabel);
        bottomContainer.setRight(infoPanel);

        double localCanvasSize = (LOCAL_VISION_RADIUS * 2 + 1) * localCellSize;
        canvasLocal = new Canvas(localCanvasSize, localCanvasSize);
        bottomContainer.setLeft(canvasLocal);

        localTopContainer = new StackPane();
        localTopContainer.setPadding(new Insets(20));
        localTopContainer.setAlignment(Pos.CENTER);

        double topWidth = TypeView.GAME.getWidth();
        double topHeight = TypeView.GAME.getHeight() - 250;
        canvasGlobal = new Canvas(topWidth, topHeight);
        localTopContainer.getChildren().add(canvasGlobal);
    }


    private void setupLocalLayout() {
        root.setCenter(null);
        root.setTop(localTopContainer);
        root.setBottom(bottomContainer);
    }

    private void setupGlobalLayout() {
        root.setTop(null);
        root.setBottom(null);
        root.setCenter(globalCenterPane);
    }

    // getters/setters
    public Scene getScene() { return scene; }
    public void setMode(ViewMode mode) { this.mode = mode; }
    public ViewMode getMode() { return mode; }
    public Label getTimerLabel() { return timerLabel; }
    public Label getMovesLabel() { return movesLabel; }
}