package com.MazeApp.javafx.views;

import com.MazeApp.game.model.ViewMode; // N'oublie pas cet import !
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox; // Import ComboBox
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class KeyGameSettingsView implements View {

    private Scene scene;
    private VBox root;

    private Label title;

    private Slider sliderWidth;
    private Slider sliderHeight;
    private Slider sliderDistance;
    private Slider sliderKeys;

    // NOUVEAU : Le choix du mode de vue
    private ComboBox<ViewMode> viewModeComboBox;

    private Label lblWidthValue;
    private Label lblHeightValue;
    private Label lblDistanceValue;
    private Label lblKeysValue;

    private Button btnValidate;
    private Button btnCancel;

    public KeyGameSettingsView() {
        title = new Label("KeyGame");
        title.setTextFill(Color.WHITE);
        title.getStyleClass().add("label");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.getStyleClass().add("gridpane");

    
        grid.add(new Label("Largeur (5-50) :"), 0, 0);
        sliderWidth = new Slider(5, 50, 15);
        sliderWidth.setBlockIncrement(1);
        sliderWidth.setPrefWidth(200);
        lblWidthValue = new Label(String.valueOf((int) sliderWidth.getValue()));
        sliderWidth.valueProperty().addListener((obs, oldVal, newVal) -> {
            lblWidthValue.setText(String.format("%.0f", newVal));
        });
        grid.add(sliderWidth, 1, 0);
        grid.add(lblWidthValue, 2, 0);

      
        grid.add(new Label("Hauteur (5-50) :"), 0, 1);
        sliderHeight = new Slider(5, 50, 15);
        sliderHeight.setBlockIncrement(1);
        sliderHeight.setPrefWidth(200);
        lblHeightValue = new Label(String.valueOf((int) sliderHeight.getValue()));
        sliderHeight.valueProperty().addListener((obs, oldVal, newVal) -> {
            lblHeightValue.setText(String.format("%.0f", newVal));
        });
        grid.add(sliderHeight, 1, 1);
        grid.add(lblHeightValue, 2, 1);

      
        grid.add(new Label("Distance min :"), 0, 2);
        sliderDistance = new Slider(5, 50, 10);
        sliderDistance.setBlockIncrement(1);
        sliderDistance.setPrefWidth(200);
        lblDistanceValue = new Label(String.valueOf((int) sliderDistance.getValue()));
        sliderDistance.valueProperty().addListener((obs, oldVal, newVal) -> {
            lblDistanceValue.setText(String.format("%.0f", newVal));
        });
        grid.add(sliderDistance, 1, 2);
        grid.add(lblDistanceValue, 2, 2);

      
        grid.add(new Label("Clés (2-5) :"), 0, 3);
        sliderKeys = new Slider(2, 5, 3);
        sliderKeys.setBlockIncrement(1);
        sliderKeys.setMajorTickUnit(1);
        sliderKeys.setMinorTickCount(0);
        sliderKeys.setSnapToTicks(true);
        sliderKeys.setPrefWidth(200);
        lblKeysValue = new Label(String.valueOf((int) sliderKeys.getValue()));
        sliderKeys.valueProperty().addListener((obs, oldVal, newVal) -> {
            lblKeysValue.setText(String.format("%.0f", newVal));
        });
        grid.add(sliderKeys, 1, 3);
        grid.add(lblKeysValue, 2, 3);

        grid.add(new Label("Mode de vue :"), 0, 4);
        viewModeComboBox = new ComboBox<>();
        viewModeComboBox.getItems().setAll(ViewMode.values());
        viewModeComboBox.setValue(ViewMode.NORMAL); 
        viewModeComboBox.setPrefWidth(200);
        grid.add(viewModeComboBox, 1, 4);



        btnValidate = new Button("Lancer");
        btnValidate.setPrefWidth(150);
        btnValidate.setId("validationBtn");

        btnCancel = new Button("Retour");
        btnCancel.setPrefWidth(150);
        btnCancel.setId("cancelBtn");

        VBox boutons = new VBox(10, btnValidate, btnCancel);
        boutons.setAlignment(Pos.CENTER);

  
        root = new VBox(20, title, grid, boutons);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.setPrefSize(450, 700); 
        root.getStyleClass().add("vbox");
        root.getStyleClass().add("root");

        this.scene = new Scene(root, TypeView.PERFECTSETTINGS.getWidth(), TypeView.PERFECTSETTINGS.getHeight());
        this.scene.setFill(Color.DARKBLUE);
        scene.getStylesheets().add(getClass().getResource("/css/recursifsettings.css").toExternalForm());
    }

    @Override
    public Scene getScene() { return scene; }

    public Slider getSliderWidth() { return sliderWidth; }
    public Slider getSliderHeight() { return sliderHeight; }
    public Slider getSliderDistance() { return sliderDistance; }
    public Slider getSliderKeys() { return sliderKeys; }

    
    public ComboBox<ViewMode> getViewModeComboBox() { return viewModeComboBox; }

    public Button getCancelBtn() { return btnCancel; }
    public Button getValidationBtn() { return btnValidate; }
}