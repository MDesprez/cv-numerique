package com.MazeApp.javafx.views;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;



public class LoginView implements View {



    private Button returnButton; 
    private TextField usernameField;
    private PasswordField passwordField;

    private Button createAccountButton;
    private Button loginAccountButton;
    private Scene scene;
    private VBox root;

    private Label warnLabel;

    public LoginView() {
        Label title = new Label("Connexion");
        warnLabel = new Label("erreurlabel");
        warnLabel.setStyle("-fx-text-fill: red;");
        warnLabel.setVisible(false);
        Label usernameLabel = new Label("Nom :");
        usernameField = new TextField();
        usernameField.setPromptText("Entrez votre nom d'utilisateur");
        


 
        Label passwordLabel = new Label("Mot de passe :");
        passwordField = new PasswordField();
        passwordField.setPromptText("Entrez votre mot de passe");


        loginAccountButton = new Button("Se connecter");
        createAccountButton = new Button("Créer un compte");
        returnButton = new Button("Retour");
        HBox buttonBox = new HBox(loginAccountButton,createAccountButton,returnButton);
        buttonBox.getStyleClass().add("button-box");
        buttonBox.setAlignment(Pos.BASELINE_CENTER);
        returnButton.setAlignment(Pos.BASELINE_RIGHT);
 

        root = new VBox(title, warnLabel, usernameLabel, usernameField,
                passwordLabel, passwordField, buttonBox, returnButton);
        root.setAlignment(Pos.CENTER);
        

        scene = new Scene(root, TypeView.LOGIN.getWidth(), TypeView.LOGIN.getHeight());
        scene.getStylesheets().add(getClass().getResource("/css/login.css").toExternalForm());
    }

    
    public TextField getUsernameField() {
        return usernameField;
    }

    public PasswordField getPasswordField() {
        return passwordField;
    }

    public Button getLoginAccountButton() {
        return loginAccountButton;
    }

    public Button getCreateAccountButton() {
        return createAccountButton;
    }

    public Label getWarnLabel(){
        return warnLabel;
    }

    @Override
    public Scene getScene() {
        return scene;
    }

    

    public Button getReturnButton() {
        return returnButton;
    }

    public void setReturnButton(Button returnButton) {
        this.returnButton = returnButton;
    }
    
}
