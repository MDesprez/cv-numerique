package com.MazeApp.javafx.views;



import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

public class MainView implements View {
    private Scene scene;
    private VBox root;
    private Label currentPlayerLabel;
    private Button playButton;
    private Button saveButton;
    private Button loginButton;
    private Button progressionButton;
    private Button quitButton;
   
    private Label label;

    public MainView() {
        this.root = new VBox(10);
        Image logo = new Image(getClass().getResourceAsStream("/img/logo.png"));
        ImageView logoView = new ImageView(logo);
       

        this.currentPlayerLabel = new Label();
        
        playButton = new Button("Mode Libre");
        progressionButton = new Button("Mode Progression");
        loginButton = new Button("Profils");
        saveButton = new Button("Sauvegardes");
        quitButton = new Button("Quitter");
        
       
        root.getChildren().addAll(logoView, currentPlayerLabel, playButton, progressionButton, loginButton, saveButton, quitButton);
        root.setAlignment(Pos.CENTER);
        
        root.setSpacing(20);
        this.scene = new Scene(root, TypeView.MAIN.getWidth(), TypeView.MAIN.getHeight());
        scene.getStylesheets().add(getClass().getResource("/css/main.css").toExternalForm());
    }

    public Scene getScene() {return scene;}
    public Label getLabel() {return label;}
    public Label getCurrentPlayerLabel() {return currentPlayerLabel;}
    public Button getPlayButton() {return playButton;}

    public Button getProgressionButton() {return progressionButton;}

    public Button getSaveButton() {return saveButton;}
    public Button getLoginButton() {return loginButton;}
    public Button getQuitButton() {return quitButton;}
}
