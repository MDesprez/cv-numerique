package com.MazeApp.javafx.views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class PostGameView implements View {
    private Scene scene;
    private VBox root;
    private Label title;
    private Label minimalDistance;
    private Label stats;
    private Button returnBtn;

    public PostGameView() {
        title = new Label("VICTOIRE !");

        minimalDistance = new Label();
        stats = new Label();

        returnBtn = new Button("Retour au Menu");
        returnBtn.setPrefWidth(200);

        root = new VBox(20, title, minimalDistance, stats, returnBtn);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(50));
        root.setPrefSize(450, 480);

        this.scene = new Scene(root,TypeView.PERFECTSETTINGS.getWidth(), TypeView.PERFECTSETTINGS.getHeight());
        this.scene.setFill(Color.DARKBLUE);

        title.setId("title");
        minimalDistance.setId("distanceMinimale");
        stats.setId("stats");
        returnBtn.setId("btnRetour");

        this.scene.getStylesheets().add(getClass().getResource("/css/postgame.css").toExternalForm());
    }

    @Override
    public Scene getScene() {
        return scene;
    }

    public Button getReturnButton() {
        return returnBtn;
    }

    public Label getMinimalDistance() {
        return minimalDistance;
    }

    public Label getStats() {
        return stats;
    }
}