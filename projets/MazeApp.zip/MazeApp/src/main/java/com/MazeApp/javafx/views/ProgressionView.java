package com.MazeApp.javafx.views;

import com.MazeApp.game.model.Player;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

public class ProgressionView implements View {
    private Scene scene;
    private VBox root;
    private Label playerNameLabel;
    private HBox hBox;

    // Niveau 1
    private BorderPane levelOneCard;
    private VBox lvlOneContent;
    private Label numFirstSegment;
    private Label firstSegmentChallenge;
    private Label firstSegmentScore;

    // Niveau 2
    private BorderPane levelTwoCard;
    private VBox lvlTwoContent;
    private Label numSecondSegment;
    private Label secondSegmentChallenge;
    private Label secondSegmentScore;

    // Niveau 3
    private BorderPane levelThreeCard;
    private VBox lvlThreeContent;
    private Label numThirdSegment;
    private Label thirdSegmentChallenge;
    private Label thirdSegmentScore;

    // Niveau 4
    private BorderPane levelFourCard;
    private VBox lvlFourContent;
    private Label numFourSegment;
    private Label fourSegmentChallenge;
    private Label fourSegmentScore;

    // Niveau 5
    private BorderPane levelFiveCard;
    private VBox lvlFiveContent;
    private Label numFiveSegment;
    private Label fiveSegmentChallenge;
    private Label fiveSegmentScore;

    // Niveau 6
    private BorderPane levelSixCard;
    private VBox lvlSixContent;
    private Label numSixSegment;
    private Label sixSegmentChallenge;
    private Label sixSegmentScore;

    private Button retour;

    public ProgressionView() {
        this.root = new VBox(30);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(40));

        this.playerNameLabel = new Label();
        playerNameLabel.setId("playerNameLabel");

        this.hBox = new HBox(30);
        hBox.setAlignment(Pos.CENTER);

        // NIVEAU 1
        this.levelOneCard = createLevelCard();
        levelOneCard.setId("levelOneCard");
        this.lvlOneContent = new VBox(8);
        lvlOneContent.setAlignment(Pos.CENTER);

        this.numFirstSegment = new Label();
        numFirstSegment.setId("numFirstSegment");
        this.firstSegmentChallenge = new Label();
        firstSegmentChallenge.setId("firstSegmentChallenge");
        this.firstSegmentScore = new Label();
        firstSegmentScore.setId("firstSegmentScore");

        lvlOneContent.getChildren().addAll(numFirstSegment, firstSegmentChallenge, firstSegmentScore);
        levelOneCard.setCenter(lvlOneContent);

        // NIVEAU 2
        this.levelTwoCard = createLevelCard();
        levelTwoCard.setId("levelTwoCard");
        this.lvlTwoContent = new VBox(8);
        lvlTwoContent.setAlignment(Pos.CENTER);

        this.numSecondSegment = new Label();
        numSecondSegment.setId("numSecondSegment");
        this.secondSegmentChallenge = new Label();
        secondSegmentChallenge.setId("secondSegmentChallenge");
        this.secondSegmentScore = new Label();
        secondSegmentScore.setId("secondSegmentScore");

        lvlTwoContent.getChildren().addAll(numSecondSegment, secondSegmentChallenge, secondSegmentScore);
        levelTwoCard.setCenter(lvlTwoContent);

        // NIVEAU 3
        this.levelThreeCard = createLevelCard();
        levelThreeCard.setId("levelThreeCard");
        this.lvlThreeContent = new VBox(8);
        lvlThreeContent.setAlignment(Pos.CENTER);

        this.numThirdSegment = new Label();
        numThirdSegment.setId("numThirdSegment");
        this.thirdSegmentChallenge = new Label();
        thirdSegmentChallenge.setId("thirdSegmentChallenge");
        this.thirdSegmentScore = new Label();
        thirdSegmentScore.setId("thirdSegmentScore");


        lvlThreeContent.getChildren().addAll(numThirdSegment, thirdSegmentChallenge, thirdSegmentScore); 
        levelThreeCard.setCenter(lvlThreeContent);

        // à partir de là je dis plus third fourth fifth ect c'est plus rapide et homogène

        // NIVEAU 4
        this.levelFourCard = createLevelCard();
        levelFourCard.setId("levelFourCard");
        this.lvlFourContent = new VBox(8);
        lvlFourContent.setAlignment(Pos.CENTER);

        this.numFourSegment = new Label();
        numFourSegment.setId("numFourSegment");
        this.fourSegmentChallenge = new Label();
        fourSegmentChallenge.setId("fourSegmentChallenge");
        this.fourSegmentScore = new Label();
        fourSegmentScore.setId("fourSegmentScore");

        lvlFourContent.getChildren().addAll(numFourSegment, fourSegmentChallenge, fourSegmentScore);
        levelFourCard.setCenter(lvlFourContent);

        // NIVEAU 5
        this.levelFiveCard = createLevelCard();
        levelFiveCard.setId("levelFiveCard");
        this.lvlFiveContent = new VBox(8);
        lvlFiveContent.setAlignment(Pos.CENTER);

        this.numFiveSegment = new Label();
        numFiveSegment.setId("numFiveSegment"); 
        this.fiveSegmentChallenge = new Label();
        fiveSegmentChallenge.setId("fiveSegmentChallenge");
        this.fiveSegmentScore = new Label();
        fiveSegmentScore.setId("fiveSegmentScore");

        lvlFiveContent.getChildren().addAll(numFiveSegment, fiveSegmentChallenge, fiveSegmentScore);
        levelFiveCard.setCenter(lvlFiveContent);

        // NIVEAU 6
        this.levelSixCard = createLevelCard();
        levelSixCard.setId("levelSixCard");
        this.lvlSixContent = new VBox(8);
        lvlSixContent.setAlignment(Pos.CENTER);

        this.numSixSegment = new Label();
        numSixSegment.setId("numSixSegment");
        this.sixSegmentChallenge = new Label();
        sixSegmentChallenge.setId("sixSegmentChallenge");
        this.sixSegmentScore = new Label();
        sixSegmentScore.setId("sixSegmentScore");

        lvlSixContent.getChildren().addAll(numSixSegment, sixSegmentChallenge, sixSegmentScore);
        levelSixCard.setCenter(lvlSixContent);

        this.retour = new Button("Retour");
        hBox.getChildren().addAll(levelOneCard, levelTwoCard, levelThreeCard, levelFourCard, levelFiveCard, levelSixCard);
        root.getChildren().addAll(playerNameLabel, hBox, retour);

        this.scene = new Scene(root, TypeView.PROGRESSION.getWidth(), TypeView.PROGRESSION.getHeight());
        scene.getStylesheets().add(getClass().getResource("/css/progression.css").toExternalForm());
    } //TODO : CORRIGER LE CHEMIN IL NE LE TROUVE PAS 

    private BorderPane createLevelCard() {
        BorderPane card = new BorderPane();
        card.setPrefSize(120, 140);
        card.setMaxSize(120, 140);
        return card;
    }

    public void draw(Player player) {
        this.playerNameLabel.setText(player.getName());

        this.numFirstSegment.setText("1");
        this.firstSegmentChallenge.setText(player.getSegment().get(0).getMaxValide().toString());
        this.firstSegmentScore.setText(player.getSegmentScores().get(player.getSegment().get(0)) + "");

        this.numSecondSegment.setText("2");
        this.secondSegmentChallenge.setText(player.getSegment().get(1).getMaxValide().toString());
        this.secondSegmentScore.setText(player.getSegmentScores().get(player.getSegment().get(1)) + "");

        this.numThirdSegment.setText("3");
        this.thirdSegmentChallenge.setText(player.getSegment().get(2).getMaxValide().toString());
        this.thirdSegmentScore.setText(player.getSegmentScores().get(player.getSegment().get(2)) + "");

        this.numFourSegment.setText("4");
        this.fourSegmentChallenge.setText(player.getSegment().get(3).getMaxValide().toString());
        this.fourSegmentScore.setText(player.getSegmentScores().get(player.getSegment().get(3)) + "");

        this.numFiveSegment.setText("5"); 
        this.fiveSegmentChallenge.setText(player.getSegment().get(4).getMaxValide().toString());
        this.fiveSegmentScore.setText(player.getSegmentScores().get(player.getSegment().get(4)) + "");

        this.numSixSegment.setText("6"); 
        this.sixSegmentChallenge.setText(player.getSegment().get(5).getMaxValide().toString());
        this.sixSegmentScore.setText(player.getSegmentScores().get(player.getSegment().get(5)) + "");
    }



    @Override
    public Scene getScene() {
        return scene;
    }

    // Getters
    public Label getplayerNameLabel() { return playerNameLabel; }
    // niveau 1
    public BorderPane getLevelOneCard() { return levelOneCard; }
    public Label getnumFirstSegment() { return numFirstSegment; }
    public Label getfirstSegmentChallenge() { return firstSegmentChallenge; }
    public Label getfirstSegmentScore() { return firstSegmentScore; }
    public VBox getlvlOneContent() { return lvlOneContent;}

    // niveau 2
    public BorderPane getLevelTwoCard() { return levelTwoCard; }
    public Label getnumSecondSegment() { return numSecondSegment; }
    public Label getsecondSegmentChallenge() { return secondSegmentChallenge; }
    public Label getsecondSegmentScore() { return secondSegmentScore; }
    public VBox getlvlTwoContent() {return lvlTwoContent;}

    // niveau 3
    public BorderPane getLevelThreeCard() {return levelThreeCard;}
    public Label getthirdSegmentChallenge() {return thirdSegmentChallenge;}
    public Label getnumThirdSegment() {return numThirdSegment;}
    public Label getThirdSegmentScore() {return thirdSegmentScore;}
    public VBox getlvlThreeContent() {return lvlThreeContent;}

    // niveau 4
    public BorderPane getLevelFourCard() {return levelFourCard;}
    public Label getFourSegmentChallenge() {return fourSegmentChallenge;}
    public Label getnumFourSegment() {return numFourSegment;}
    public Label getFourSegmentScore() {return fourSegmentScore;}
    public VBox getlvlFourContent() {return lvlFourContent;}

    // niveau 5
    public BorderPane getLevelFiveCard() {return levelFiveCard;}
    public Label getFiveSegmentChallenge() {return fiveSegmentChallenge;}
    public Label getnumFiveSegment() {return numFiveSegment;}
    public Label getFiveSegmentScore() {return fiveSegmentScore;}
    public VBox getlvlFiveContent() {return lvlFiveContent;}

    // niveau 6
    public BorderPane getLevelSixCard() {return levelSixCard;}
    public Label getSixSegmentChallenge() {return sixSegmentChallenge;}
    public Label getnumSixSegment() {return numSixSegment;}
    public Label getSixSegmentScore() {return sixSegmentScore;}
    public VBox getlvlSixContent() {return lvlSixContent;}

    public Button getReturn() {return retour;}
}
