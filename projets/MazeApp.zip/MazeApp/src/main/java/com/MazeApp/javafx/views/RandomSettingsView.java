package com.MazeApp.javafx.views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class RandomSettingsView implements View {
    private Scene scene;
    private VBox root;

    private Label title;
    public TextField txtWidth;
    public TextField txtHeight;
    public Slider sliderPercentage;
    private Label lblPercentage;
    private Button btnValidate;
    private Button btnCancel;

    public RandomSettingsView() {
        title = new Label("Paramètres du labyrinthe aléatoire");
        title.setTextFill(Color.WHITE);
        title.getStyleClass().add("label");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.getStyleClass().add("gridpane");

        grid.add(new Label("Largeur (5-50) :"), 0, 0);
        txtWidth = new TextField("30");
        txtWidth.setPrefWidth(60);
        grid.add(txtWidth, 1, 0);
        txtWidth.getStyleClass().add("text-field");

        grid.add(new Label("Hauteur (5-50) :"), 0, 1);
        txtHeight = new TextField("30");
        txtHeight.setPrefWidth(60);
        grid.add(txtHeight, 1, 1);
        txtHeight.getStyleClass().add("text-field");

        grid.add(new Label("Murs (%) :"), 0, 2);
        sliderPercentage = new Slider(0.1, 0.5, 0.3);
        sliderPercentage.setPrefWidth(100);


        grid.add(sliderPercentage, 1, 2);
        sliderPercentage.setId("sliderPercentage");

        lblPercentage = new Label("30%");
        grid.add(lblPercentage, 2, 2);
        lblPercentage.setId("lblPercentage");

        btnValidate = new Button("Lancer");
        btnValidate.setPrefWidth(150);
        btnValidate.setId("validationBtn");

        btnCancel = new Button("Retour");
        btnCancel.setPrefWidth(150);
        btnCancel.setId("cancelBtn");

        VBox boutons = new VBox(10, btnValidate, btnCancel);
        boutons.setAlignment(Pos.CENTER);

        root = new VBox(20, title, grid, boutons);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.setPrefSize(450, 600);
        root.getStyleClass().add("vbox");
        root.getStyleClass().add("root");

        this.scene = new Scene(root, TypeView.RANDOMSETTINGS.getWidth(), TypeView.RANDOMSETTINGS.getHeight());
        this.scene.setFill(Color.DARKBLUE);

        scene.getStylesheets().add(getClass().getResource("/css/randomsettings.css").toExternalForm());

    }

    @Override
    public Scene getScene() { return scene; }
    public TextField getTxtWidth() { return txtWidth; }
    public TextField getTxtHeight() { return txtHeight; }
    public Slider getSliderPercentage() { return sliderPercentage; }
    public Button getCancelBtn() {return btnCancel;}
    public Button getValidationBtn() {return btnValidate;}
    public Label getLblPercentage() {return lblPercentage;}
}


