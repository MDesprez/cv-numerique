package com.MazeApp.javafx.views;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class RecursiveSettingsView implements View {

    private Scene scene;
    private VBox root;

    private Label title;
    private Slider sliderWidth;
    private Slider sliderHeight;
    private Slider sliderDistance;
    private Label lblWidthValue;
    private Label lblHeightValue;
    private Label lblDistanceValue;
    private Button btnValidate;
    private Button btnCancel;

    public RecursiveSettingsView() {
        title = new Label("Paramètre du labyrinthe récursif");
        title.setTextFill(Color.WHITE);
        title.getStyleClass().add("label");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setAlignment(Pos.CENTER);
        grid.getStyleClass().add("gridpane");

        // Width slider
        grid.add(new Label("Largeur (5-50) :"), 0, 0);
        sliderWidth = new Slider(5, 50, 30);
        sliderWidth.setBlockIncrement(1);
        sliderWidth.setPrefWidth(200);
        lblWidthValue = new Label(String.valueOf((int) sliderWidth.getValue()));
        sliderWidth.valueProperty().addListener((observable, oldValue, newValue) -> {
            lblWidthValue.setText(String.format("%.0f", newValue));
        });
        grid.add(sliderWidth, 1, 0);
        grid.add(lblWidthValue, 2, 0);

        // Height slider
        grid.add(new Label("Hauteur (5-50) :"), 0, 1);
        sliderHeight = new Slider(5, 50, 30);
        sliderHeight.setBlockIncrement(1);
        sliderHeight.setPrefWidth(200);
        lblHeightValue = new Label(String.valueOf((int) sliderHeight.getValue()));
        sliderHeight.valueProperty().addListener((observable, oldValue, newValue) -> {
            lblHeightValue.setText(String.format("%.0f", newValue));
        });
        grid.add(sliderHeight, 1, 1);
        grid.add(lblHeightValue, 2, 1);

        // Distance slider
        grid.add(new Label("Distance minimale entrée-sortie:"), 0, 2);
        sliderDistance = new Slider(5, 50, 10);
        sliderDistance.setBlockIncrement(1);
        sliderDistance.setPrefWidth(200);
        lblDistanceValue = new Label(String.valueOf((int) sliderDistance.getValue()));
        sliderDistance.valueProperty().addListener((observable, oldValue, newValue) -> {
            lblDistanceValue.setText(String.format("%.0f", newValue));
        });
        grid.add(sliderDistance, 1, 2);
        grid.add(lblDistanceValue, 2, 2);

        // Buttons
        btnValidate = new Button("Lancer");
        btnValidate.setPrefWidth(150);
        btnValidate.setId("validationBtn");

        btnCancel = new Button("Retour");
        btnCancel.setPrefWidth(150);
        btnCancel.setId("cancelBtn");

        VBox boutons = new VBox(10, btnValidate, btnCancel);
        boutons.setAlignment(Pos.CENTER);

        // Root layout
        root = new VBox(20, title, grid, boutons);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.setPrefSize(450, 600);
        root.getStyleClass().add("vbox");
        root.getStyleClass().add("root");

        this.scene = new Scene(root, TypeView.PERFECTSETTINGS.getWidth(), TypeView.PERFECTSETTINGS.getHeight());
        this.scene.setFill(Color.DARKBLUE);

        scene.getStylesheets().add(getClass().getResource("/css/recursifsettings.css").toExternalForm());
    }

    @Override
    public Scene getScene() {
        return scene;
    }

    public Label getLblDistance(){
        return lblDistanceValue;
    }

    public Slider getSliderWidth() {
        return sliderWidth;
    }

    public Slider getSliderHeight() {
        return sliderHeight;
    }

    public Slider getSliderDistance() {
        return sliderDistance;
    }

    public Button getCancelBtn() {
        return btnCancel;
    }

    public Button getValidationBtn() {
        return btnValidate;
    }
}
