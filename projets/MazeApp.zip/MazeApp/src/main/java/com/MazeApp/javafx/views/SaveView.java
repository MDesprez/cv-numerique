package com.MazeApp.javafx.views;
import com.MazeApp.game.SaveManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import com.MazeApp.game.model.Save;

public class SaveView implements View {

    private Scene scene;
    private VBox root;
    private Label title;
    
    private ListView<String> saveList;
    private Button saveButton;
    private Button loadButton;
    private Button returnButton;
    private Label message;
    private Button deleteButton;
 

    public SaveView() {
        root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        title = new Label("Sauvegardes");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");


        
        saveList = new ListView<>();
        saveList.setPrefHeight(150);

        saveButton = new Button("Sauvegarder");
        loadButton = new Button("Charger");
        returnButton = new Button("Retour");
        deleteButton = new Button("Supprimer");
        message = new Label();

        message.setStyle("-fx-font-size: 9px; -fx-text-fill: white;");

        HBox buttonBox = new HBox(10, saveButton, loadButton, deleteButton);
        buttonBox.setAlignment(Pos.CENTER);

        root.getChildren().addAll(title, saveList, buttonBox, message, returnButton);

        scene = new Scene(root, TypeView.SAVE.getWidth(), TypeView.SAVE.getHeight());
        scene.getStylesheets().add(getClass().getResource("/css/main.css").toExternalForm());
    }

    @Override
    public Scene getScene() {
        return scene;
    }

    public Button getReturnButton() {
        return returnButton;
    }

    public Button getSaveButton() {
        return saveButton;
    }

    public Button getLoadButton() {
        return loadButton;
    }

    public Button getDeleteButton() {
        return deleteButton;
    } 

    public Label getMessage() {
        return message;
    }

    public ListView<String> getSaveList() {
        return saveList;
    }

}
