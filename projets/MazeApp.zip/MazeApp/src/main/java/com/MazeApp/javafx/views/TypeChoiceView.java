package com.MazeApp.javafx.views;

import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class TypeChoiceView implements View {
    
    private Scene scene;
    private VBox root;
    private Label labelTitle;

    private Button randomButton;
    private Button perfectButton;
    private Button recursiveButton;
    private Button keyGameButton;
    private Button returnButton;

    public TypeChoiceView(){
        root = new VBox(10);
        root.setAlignment(Pos.CENTER);

        labelTitle = new Label("Choisir le type de Labyrinthe");
        randomButton = new Button("Aléatoire");
        perfectButton = new Button("Parfait");
        recursiveButton = new Button("Récursif");
        keyGameButton = new Button("KeyGame");
        returnButton = new Button("Retour");

        root.getChildren().addAll(labelTitle, randomButton, perfectButton, recursiveButton, keyGameButton ,returnButton);
        scene = new Scene(root, TypeView.TYPECHOICE.getWidth(),TypeView.TYPECHOICE.getHeight());

        scene.getStylesheets().add(getClass().getResource("/css/typeChoice.css").toExternalForm());

    }

    public Scene getScene() {
        return this.scene;
    }

    public Button getRandomButton(){
        return randomButton;
    }

    public Button getPerfectButton(){
        return perfectButton;
    }

    public Button getRecursiveButton(){
        return recursiveButton;
    }

    public Button getKeyGameButton() {return keyGameButton;}

    public Button getReturnButton(){
        return returnButton;
    }

}
