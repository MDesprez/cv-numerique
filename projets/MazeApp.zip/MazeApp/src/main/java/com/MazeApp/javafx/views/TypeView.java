package com.MazeApp.javafx.views;

public enum TypeView {
    GAME(1000,1000),
    GAMELOCAL(1000, 1000),
    MAIN(1000,1000),
    VICTORY(450, 480),
    LOGIN(1000,1000),
    SAVE(1000,1000),
    PROGRESSION(1000, 1000),
    DEFI(450, 480),
    TYPECHOICE(1000, 1000),
    RANDOMSETTINGS(1000, 1000),
    PERFECTSETTINGS(1000, 1000),
    RECURSIVESETTINGS(1000, 1000),
    KEYGAME(1000, 1000);

    private int width; 
    private int height; 

    private TypeView(int width,int height){
        this.width = width;
        this.height = height;
    }

    public int getWidth(){
        return this.width;
    }

    public int getHeight(){
        return this.height;
    }

}
