package com.MazeApp.javafx.views;

import javafx.scene.Scene;

public interface View {
    public Scene getScene();

}
