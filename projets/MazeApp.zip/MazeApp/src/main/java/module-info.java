module com.MazeApp {
    requires javafx.controls;
    requires jdk.compiler;
    requires java.desktop;
    requires javafx.graphics;
    exports com.MazeApp;
    exports com.MazeApp.game.model.mazes;
}