package com.MazeApp.game;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.MazeApp.game.model.mazes.MazeRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.MazeApp.game.model.Player;
import com.MazeApp.javafx.observateurs.GameManagerObserver;


public class TestGameManager {

    private GameManager gestionnaire;
    private Player joueur;
    private MazeRandom jeu;

    static class FauxObservateurObserver implements GameManagerObserver {
        boolean misAJour = false;
        @Override
        public void update(GameManager gm) {
            misAJour = true;
        }
    }

    static class NonObservateur {
        boolean estNotifie = false;
        public void draw(Object lab) {
            estNotifie = true;
        }
    }

    @BeforeEach
    void initialize() {
        gestionnaire = new GameManager();
        joueur = new Player("Malori", "666");

        jeu = new MazeRandom(20, 20, 0.2);

        gestionnaire.setCurrentPlayer(joueur);
        gestionnaire.setMaze(jeu);
    }

    @Test
    void test_non_observer_is_false_by_default() {
        NonObservateur n = new NonObservateur();
        assertFalse(n.estNotifie);
    }

    @Test
    void test_non_observer_draw_put_is_notified_true() {
        NonObservateur n = new NonObservateur();
        n.draw(null);
        assertTrue(n.estNotifie);
    }

    @Test
    void test_non_observer_does_not_implement_observer_interface() {
        for (Class<?> iface : NonObservateur.class.getInterfaces()) {
            assertNotEquals("GameManagerObserver", iface.getSimpleName());
        }
    }

    @Test
    void test_add_and_notify_observer() {
        FauxObservateurObserver obs = new FauxObservateurObserver();
        gestionnaire.add(obs);
        assertTrue(gestionnaire.getObservers().contains(obs));

        gestionnaire.notifyObservers();
        assertTrue(obs.misAJour);
    }

    @Test
    void test_deleting_and_cleaning_observers() {
        FauxObservateurObserver obs1 = new FauxObservateurObserver();
        gestionnaire.add(obs1);
        gestionnaire.remove(obs1);
        assertFalse(gestionnaire.getObservers().contains(obs1));

        gestionnaire.add(obs1);
        gestionnaire.removeAllObservaters();
        assertTrue(gestionnaire.getObservers().isEmpty());
    }
}