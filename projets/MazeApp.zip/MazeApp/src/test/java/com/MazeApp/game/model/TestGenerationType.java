package com.MazeApp.game.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class TestGenerationType {
    
    @Test
    void test_generation_type(){
        TypeGeneration[] gen = TypeGeneration.values();
        assertEquals(3, gen.length);
        assertEquals(TypeGeneration.RANDOM, TypeGeneration.valueOf("RANDOM"));
        assertEquals(TypeGeneration.PERFECT, TypeGeneration.valueOf("PERFECT"));
        assertEquals(TypeGeneration.EMPTY, TypeGeneration.valueOf("EMPTY"));
    }

}
