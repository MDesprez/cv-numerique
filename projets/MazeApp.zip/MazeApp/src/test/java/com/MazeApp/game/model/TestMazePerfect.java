package com.MazeApp.game.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.MazeApp.game.model.mazes.MazePerfect;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestMazePerfect {

    private MazePerfect maze;
    private final int width = 15;
    private final int height = 15;

    @BeforeEach
    void setup() {
        maze = new MazePerfect(width, height);
    }

    @Test
    void test_generation_basics() {
        assertNotNull(maze, "Le labyrinthe ne doit pas être null");
        assertEquals(width, maze.getWidth());
        assertEquals(height, maze.getHeight());

        assertNotNull(maze.getEntry(), "L'entrée doit être définie");
        assertNotNull(maze.getExit(), "La sortie doit être définie");

        assertFalse(maze.getEntryX() == maze.getExitX() && maze.getEntryY() == maze.getExitY(),
                "L'entrée et la sortie doivent être distinctes");
    }

    @Test
    void test_is_valid_and_solvable() {
        assertTrue(maze.isValid(), "Le labyrinthe généré doit être valide");
        assertTrue(maze.getMinimalDistance() > 0, "La distance minimale doit être positive");
    }

    @Test
    void test_walls_exist() {
        assertTrue(maze.isWall(-1, 0, 0, 0), "Les coordonnées hors limites doivent être considérées comme des murs");
    }

    @Test
    void test_min_distance_constructor() {
        int minDistance = 20;
        MazePerfect longMaze = new MazePerfect(width, height, minDistance);

        assertTrue(longMaze.isValid(), "Le labyrinthe 'long' doit être valide");
        assertTrue(longMaze.getMinimalDistance() >= minDistance,
                "La distance minimale (" + longMaze.getMinimalDistance() + ") doit être >= " + minDistance);
    }

    @Test
    void test_reset_player() {
        maze.setPlayerX(5);
        maze.setPlayerY(5);
        maze.resetPlayer();

        assertEquals(maze.getEntryX(), maze.getPlayerX(), "Le joueur doit revenir à l'entrée X");
        assertEquals(maze.getEntryY(), maze.getPlayerY(), "Le joueur doit revenir à l'entrée Y");
    }
}