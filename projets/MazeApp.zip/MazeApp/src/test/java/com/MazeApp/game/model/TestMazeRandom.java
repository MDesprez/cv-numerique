package com.MazeApp.game.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.MazeApp.game.model.mazes.MazeRandom;
import org.junit.jupiter.api.Test;

public class TestMazeRandom {

    private MazeRandom lab = new MazeRandom(10, 10, 0.2);

    private boolean above(int x, int y, int largeur){
        return y == 0 && x >= 1 && x <= largeur -2;
    }
    private boolean below(int x, int y, int largeur){
        return y == largeur - 1 && x >= 1 && x <= largeur - 2;
    }
    private boolean toLeft(int x, int y, int largeur){
        return x == 0 && y >= 1 && y <= largeur - 2;
    }
    private boolean toRight(int x, int y, int largeur){
        return x == largeur - 1 && y >= 1 && y <= largeur - 2;
    }
    private boolean onTheEdge(int x, int y){
        return (x == 0 || x == 9) && (y == 0 || y == 9);
    }

    @Test
    void test_generate_entrance(){
        int [] entry = lab.getEntry();
        assertNotNull(entry, "L'entrée est bien définie");
        int x = entry[0];
        int y = entry[1];

        boolean isOnEdge = above(x, y, lab.getWidth()) || below(x, y, lab.getWidth()) ||
                toRight(x, y, lab.getWidth()) || toLeft(x, y, lab.getWidth());

        assertTrue(isOnEdge, "L'entrée se situe bien sur un des bords du labyrinthe");
        assertFalse(onTheEdge(x, y), "L'entrée n'est pas présente dans un coin");
    }

    @Test
    void test_generate_exit(){
        int [] exit = lab.getExit();
        assertNotNull(exit, "La sortie est bien définie");
        int x = exit[0];
        int y = exit[1];

        boolean isOnEdge = above(x, y, lab.getWidth()) || below(x, y, lab.getWidth()) ||
                toRight(x, y, lab.getWidth()) || toLeft(x, y, lab.getWidth());

        assertTrue(isOnEdge, "La sortie se situe bien sur un des bords du labyrinthe");
    }

    @Test
    void test_is_valid(){
        assertTrue(lab.isValid(), "Le labyrinthe a une entrée et une sortie liées par un chemin accessible.");
    }

    @Test
    void test_minimal_distance_calculation(){
        int distance = lab.getMinimalDistance();
        assertTrue(distance > 0, "La distance minimale doit être supérieure a 0");
    }

    @Test
    void move_player(){
        int xBeforeD = lab.getPlayerX();
        int yBeforeD = lab.getPlayerY();
        lab.movePlayer(Direction.RIGHT);
        int xAfterD = lab.getPlayerX();
        int yAfterD = lab.getPlayerY();
        assertTrue(((xAfterD == xBeforeD + 1 && yAfterD == yBeforeD) || (xAfterD == xBeforeD && yAfterD == yBeforeD)));

        int xBeforeB = lab.getPlayerX();
        int yBeforeB = lab.getPlayerY();
        lab.movePlayer(Direction.DOWN);
        int xAfterB = lab.getPlayerX();
        int yAfterB = lab.getPlayerY();
        assertTrue(((xAfterB == xBeforeB && yAfterB - 1 == yBeforeB) || (xAfterB == xBeforeB && yAfterB == yBeforeB))); // Correction logic y

        int xBeforeG = lab.getPlayerX();
        int yBeforeG = lab.getPlayerY();
        lab.movePlayer(Direction.LEFT);
        int xAfterG = lab.getPlayerX();
        int yAfterG = lab.getPlayerY();
        assertTrue((xAfterG == xBeforeG - 1 && yAfterG == yBeforeG) || (xAfterG == xBeforeG && yAfterG == yBeforeG));

        int xBeforeH = lab.getPlayerX();
        int yBeforeH = lab.getPlayerY();
        lab.movePlayer(Direction.UP);
        int xAfterH = lab.getPlayerX();
        int yAfterH = lab.getPlayerY();
        assertTrue((xAfterH == xBeforeH && yAfterH == yBeforeH - 1) || (xAfterH == xBeforeH && yAfterH == yBeforeH));
    }

    @Test
    void test_exit_reached(){
        lab.setPlayerX(lab.getExitX());
        lab.setPlayerY(lab.getExitY());
        assertTrue(lab.isExitReached());

        lab.setPlayerX(lab.getEntryX());
        lab.setPlayerY(lab.getEntryY());
        assertFalse(lab.isExitReached());
    }

    @Test
    void test_get_entry_exit_player(){
        assertEquals(2, lab.getEntry().length);
        assertEquals(2, lab.getExit().length);
        assertEquals(2, lab.getPlayer().length);
    }
}