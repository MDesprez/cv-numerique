package com.MazeApp.game.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.MazeApp.game.model.mazes.MazeRecursiveDivision;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestMazeRecursiveDivision {

    private MazeRecursiveDivision maze;
    private final int width = 20;
    private final int height = 20;

    @BeforeEach
    void setup() {
        maze = new MazeRecursiveDivision(width, height);
    }

    @Test
    void test_generation_structure() {
        assertNotNull(maze);
        assertEquals(width, maze.getWidth());
        assertEquals(height, maze.getHeight());
    }

    @Test
    void test_connectivity() {
        assertTrue(maze.isValid(), "Le labyrinthe généré par division récursive doit être résoluble");
        assertTrue(maze.getMinimalDistance() > 0, "Il doit y avoir une distance calculable");
    }

    @Test
    void test_min_distance_constraint() {
        int targetMinDist = 30;
        MazeRecursiveDivision hardMaze = new MazeRecursiveDivision(width, height, targetMinDist);

        assertTrue(hardMaze.isValid());
        assertTrue(hardMaze.getMinimalDistance() >= targetMinDist,
                "La distance min (" + hardMaze.getMinimalDistance() + ") doit respecter la consigne (" + targetMinDist + ")");
    }

    @Test
    void test_thin_walls_logic() {
        boolean result = maze.isWall(0, 0, 0, 1);
        assertNotNull(result);
    }

    @Test
    void test_small_maze() {
        MazeRecursiveDivision smallMaze = new MazeRecursiveDivision(3, 3);
        assertTrue(smallMaze.isValid(), "Même un petit labyrinthe doit être valide");
    }
}