package com.MazeApp.game.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class TestPlayer {

    Player j = new Player("matheo", "superMotdeP@sse");

    @Test
    void test_player(){
        assertEquals("matheo", j.getName());
        assertEquals("superMotdeP@sse", j.getPassword());
        assertEquals(0, j.getMaxSegmentReached());
        assertNotNull(j.getSegment());
        assertNotNull(j.getSegmentScores());
        assertEquals(6, j.getSegment().size(), "6 étapes sont initialisées à la création");
    }


    @Test
    void test_valider_etape(){
        Segment s = j.getSegment().get(0);

        j.confirmSegment(s);

        Double score = j.getSegmentScores().get(s);
        assertNotNull(score, "une étape validée ne peut avoir un résultat null");
        assertTrue(score >= 0, "Une étape valide ne peut que avoir un score positif");
        assertTrue(s.getIsValid(), "Le segment doit être marqué comme valide");
    }

    @Test
    void test_string_to_string(){
        String toString = j.toString();
        assertTrue(toString.contains("MATHEO"));
        assertTrue(toString.contains("Etape max : 0"));
    }

    @Test
    void test_set(){
        j.setName("Leo");
        assertEquals("Leo", j.getName());
        j.setMaxSegmentReached(42);
        assertEquals(42, j.getMaxSegmentReached());
    }

    @Test
    void test_get(){
        assertEquals(0, j.getID());
        assertEquals("superMotdeP@sse", j.getPassword());
    }
}