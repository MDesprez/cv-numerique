package com.MazeApp.game.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestSave {

    private Player j;
    private Save s1;
    private static Path temp;

    @BeforeAll
    public static void pathComplete() throws IOException {
        temp = Files.createTempDirectory("testSave");
        System.setProperty("user.dir", temp.toString());
    }

    @BeforeEach
    public void setup(){
        j = new Player("pablo", "lpbQueen");
        s1 = new Save(j, 0);
    }

    @Test
    public void test_getters() {
        assertNotNull(s1.getPlayer(), "Le joueur doit avoir été initialisé");
        assertEquals("pablo", s1.getPlayer().getName());
        assertEquals(0, s1.getID());
        assertNotNull(Save.getPath(), "Le chemin de sauvegarde ne doit pas être null");
    }

    @Test
    public void test_to_string() {
        String result = s1.toString();
        assertTrue(result.toUpperCase().contains("PABLO"),
                "La méthode toString() doit contenir le nom du joueur");
    }
}