package com.MazeApp.game.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.MazeApp.game.model.mazes.AbstractMaze;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;

public class TestSegment {

    Segment e4 = new Segment(42, 10, 10);

    @Test
    void test_segment(){
        assertFalse(e4.getIsValid(), "Par défaut invalide");
        assertEquals(3, e4.getMazes().size(), "3 difficultés");
        assertTrue(e4.getMazes().containsKey(Challenge.MEDIUM));
    }

    @Test
    void test_set_valid(){
        e4.setValid(true);
        assertTrue(e4.getIsValid());
    }

    private void setMazeStats(AbstractMaze maze, int moves, int minimalDistance, boolean complete) throws Exception {
        Field fMoves = AbstractMaze.class.getDeclaredField("moves");
        fMoves.setAccessible(true);
        fMoves.setInt(maze, moves);

        Field fDist = AbstractMaze.class.getDeclaredField("minimalDistance");
        fDist.setAccessible(true);
        fDist.setInt(maze, minimalDistance);

        Field fComplete = AbstractMaze.class.getDeclaredField("complete");
        fComplete.setAccessible(true);
        fComplete.setBoolean(maze, complete);
    }

    @Test
    void test_easy_score_calculation() throws Exception {
        AbstractMaze lab = e4.getMazes().get(Challenge.EASY);
        setMazeStats(lab, 10, 10, true);

        double score = e4.calculateScore();
        assertEquals(50.0, score, "Score max EASY attendu pour partie parfaite");

        setMazeStats(lab, 1000, 10, true);
        assertEquals(0, e4.calculateScore());
    }

    @Test
    void test_medium_score_calculation() throws Exception {
        AbstractMaze lab = e4.getMazes().get(Challenge.MEDIUM);
        setMazeStats(lab, 20, 20, true);

        double score = e4.calculateScore();
        assertEquals(70.0, score, "Score max MEDIUM attendu");
    }

    @Test
    void test_hard_score_calculation() throws Exception {
        AbstractMaze lab = e4.getMazes().get(Challenge.HARD);
        setMazeStats(lab, 30, 30, true);

        double score = e4.calculateScore();
        assertEquals(100.0, score, "Score max HARD attendu");
    }

    @Test
    void test_score_not_valid() throws Exception {
        for(AbstractMaze lab : e4.getMazes().values()){
            setMazeStats(lab, 0, 10, false);
        }
        assertEquals(0, e4.calculateScore());
        assertEquals(Challenge.NONE, e4.getMaxValide());
    }

    @Test
    void test_get_numero(){
        assertEquals(42, e4.getNumber());
    }
}