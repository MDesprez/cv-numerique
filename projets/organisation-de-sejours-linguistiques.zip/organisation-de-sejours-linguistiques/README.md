# DATES DE RENDUS
===================

## MAI

**semaine 1 et 2 (du 21/04) et (du 28/04)**

- 02/05/25 à 19H00: rapport version 1 de graphe
- 05/05/2025 à 19h00: rapport de Dev Partie 1
- 05/05/25 : commits étiquetés **POO-v1**

**semaine 3 et 4 (du 5/05) et (du 12/05)** 

- 16/05/25 à 19h00: rapport complet en Graphes
- 19/05/25 : commits étiquetés **POO-v2 GRAPHE-v1**

**semaine 5 et 6 (du 19/05) et (du 26/05)**

- 26/05/25 (au plus tard un jours avant la séance suivante de SAÉ) : commits étiquetés **POO-v3 GRAPHE-v2 IHM-v1**

## JUIN

**semaine 7 et 8 (du 2/06) et (du 9/06)**

- semaine du 09/06/25: commits étiquetés **POO-v4 IHM-v2**

# TRAVAIL A FAIRE
====================

## Semaines 1  et 2

**POO**
-  classes de base
-  compatibilité entre adolescents (contraintes)
-  développement des classes de tests correspondantes, illustrant le bon fonctionnement des principales méthodes de ces classes

**Graphes**
- Version 1 du rapport

## Semaines 3 et 4

**POO**
- gestion de la validité des critères par un mécanisme d’exception
- développement des règles spécifiques de compatibilité pour certains pays

**Graphes**
- rapport complet (Version 1, Version 2 et Version 3)

## Semaines 5 et 6

**POO**
- import par fichier de format csv, répondant à la structure donnée
- export d’un résultat sous format csv
- gestion de l’historique par sérialisation binaire
- implémentation d’un jeu de données montant le bon fonctionnement du nouveau système
d’affectation

**IHM**
- maquettage et prototype basse fidélité

## Semaines 7 et 8

**POO**
- prétraitement des critères des adolescents sur demande
- prétraitement automatique des critères en cas d’existence d’un fichier de configuration à un
emplacement prédéfini

**IHM**
- prototype haute fidélité
- développement en JavaFX
