package ihm;

import java.io.IOException;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Accueil extends Application {

        public void start(Stage stage) throws IOException {
                ExchangeGestion.startDemo();
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = getClass().getResource("Accueil.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();
                AccueilController accueilController = loader.getController();
                accueilController.setLabelOnMenu();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.setTitle("Accueil");
                stage.setResizable(false);
                stage.show();
        }

        public static Scene newScene () throws IOException {
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = Accueil.class.getResource("Accueil.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();
                Scene scene = new Scene(root);
                AccueilController accueilController = loader.getController();
                accueilController.setLabelOnMenu();

                return scene;
        }

        public static void main(String[] args) {
                Application.launch(args);
        }

    
}
