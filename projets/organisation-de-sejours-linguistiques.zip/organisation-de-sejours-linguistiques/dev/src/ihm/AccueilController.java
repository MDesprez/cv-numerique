package ihm;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

public class AccueilController {
    @FXML
    Button profilButton;
    @FXML
    Button hostResearchButton;
    @FXML
    Button guestReserchButton;
    @FXML
    Button parameterButton;
    @FXML
    MenuButton connectionButton;
    @FXML
    MenuItem student1Item;
    @FXML
    MenuItem student2Item;

    private static String textMenu1 = ExchangeGestion.STUDENT1.getSurname()+" "+ExchangeGestion.STUDENT1.getName();
    private static String textMenu2 = ExchangeGestion.STUDENT2.getSurname()+" "+ExchangeGestion.STUDENT2.getName();

    public static void setTextMenu1(String s) {textMenu1=s;}
    public static void setTextMenu2(String s) {textMenu2=s;}


    public void accessProfilOnClick () {
        try {
            if (isAnyStudentConnected()) {
                Scene profilScene = Profil.newScene(ExchangeGestion.getStudent());
                Stage stage = (Stage) profilButton.getScene().getWindow();
                stage.setScene(profilScene);
            } else {
                ImpossibleNewWindow.newPopUp();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessHostResearchOnClick () {
        try {
            if (isAnyStudentConnected()) {
                Scene hostResearchScene = Recherche.newHostScene(ExchangeGestion.getStudent());
                Stage stage = (Stage) hostResearchButton.getScene().getWindow();
                stage.setScene(hostResearchScene); 
            } else {
                ImpossibleNewWindow.newPopUp();
            }       
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessGuestResearchOnClick() {
        try {
            if (isAnyStudentConnected()) {
                Scene guestResearchScene = Recherche.newGuestScene(ExchangeGestion.getStudent());
                Stage stage = (Stage) guestReserchButton.getScene().getWindow();   
                stage.setScene(guestResearchScene);     
            } else {
                ImpossibleNewWindow.newPopUp();
            } 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void student1Selected() {
        if (ExchangeGestion.STUDENT1 != null) {
            ExchangeGestion.setStudentConnected(ExchangeGestion.STUDENT1);
        }
    }

    public void student2Selected() {
        if (ExchangeGestion.STUDENT2 != null) {
            ExchangeGestion.setStudentConnected(ExchangeGestion.STUDENT2);
        }
    }

    public boolean isAnyStudentConnected() {
        return ExchangeGestion.getStudent() != null;
    }

    public void setLabelOnMenu() {
        student1Item.setText(textMenu1);
        student2Item.setText(textMenu2);
    }
}
