package ihm;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import poo.Student;

public class AffinityPage {
    public static Scene newScene(Student student, Student other) throws IOException {
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = AffinityPage.class.getResource("AffinityPage.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();
                Scene scene = new Scene(root);
                AffinityPageController controller = loader.getController();
                AffinityPageController.setOther(other);
                controller.setTextWithStudentInfos(student);
                controller.setTextWithOtherInfos(other);
                controller.setTAffinityInfos(student, other);

                return scene;
        }
}
