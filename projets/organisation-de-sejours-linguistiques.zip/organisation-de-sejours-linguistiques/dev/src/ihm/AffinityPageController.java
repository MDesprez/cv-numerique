package ihm;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import poo.Student;

public class AffinityPageController {
    
    private static Student other;

    @FXML
    Button matchButton;
    @FXML
    Button exiButton;
    @FXML
    Label studentNameLabel;
    @FXML
    Label otherNameLabel;
    @FXML
    ImageView countryStudentView;
    @FXML
    ImageView countryOtherView;
    @FXML
    Label studentAgeLabel;
    @FXML
    Label otherAgeLabel;
    @FXML
    Label studentGenderLabel;
    @FXML
    Label otherGenderLabel;
    @FXML
    Label studentHobbiesLabel;
    @FXML
    Label otherStudentHobbiesLabel;
    @FXML
    AnchorPane AlimentaryCritariesPane;
    @FXML
    ImageView alimentaryView;
    @FXML
    AnchorPane AllergyCritaryPane;
    @FXML
    ImageView allergyView;
    @FXML
    AnchorPane commonHobbiesPane;
    @FXML
    Label commonHobbiesLabel;
    @FXML
    AnchorPane genderPairPane;
    @FXML
    ImageView studentGenderPairView;
    @FXML
    ImageView otherGenderPairView;

    
    public static Student getOther() {return other;}
    public static void setOther(Student o){other = o;}

    public void setTextWithStudentInfos (Student student) {
        studentNameLabel.setText(student.getSurname() +" "+ student.getName());
        countryStudentView.setImage(new Image(ExchangeGestion.getCountryFlagFile(student.getHomeCountry()).toURI().toString()));;
        studentAgeLabel.setText((LocalDate.now().getYear()-student.getBirthDate().getYear())+" ans");
        studentGenderLabel.setText("Genre: "+student.getGender());
        studentHobbiesLabel.setText("Hobbies: "+student.getHobbies());
    }

    public void setTextWithOtherInfos (Student other) {
        otherNameLabel.setText(other.getSurname() +" "+ other.getName());
        countryOtherView.setImage(new Image(ExchangeGestion.getCountryFlagFile(other.getHomeCountry()).toURI().toString()));;
        otherAgeLabel.setText((LocalDate.now().getYear()-other.getBirthDate().getYear())+" ans");
        otherGenderLabel.setText("Genre: "+other.getGender());
        otherStudentHobbiesLabel.setText("Hobbies: "+other.getHobbies());
    }

    public void setTAffinityInfos (Student student, Student other) {
        int commonHobbies, genderPair, food;
        File validImageFile = new File (ExchangeGestion.src+"valid_icon.png");
        File falseImageFile =new File(ExchangeGestion.src+"false_icon.png");
        food=0;
        if (RechercheController.isGuestStage) {
            for (String foodConstraint: other.getGuestFood().split(",")) {
                for (String hostFood: student.getGuestFood().split(",")) {
                    if (foodConstraint.equalsIgnoreCase(hostFood)) {
                        food++;
                    }
                }
            }
            
            if (student.getHostHasAnimal().equalsIgnoreCase("yes") || other.getGuestAnimalAllergy().equalsIgnoreCase("yes")) {
                allergyView.setImage(new Image(falseImageFile.toURI().toString()));
                AllergyCritaryPane.setStyle("-fx-background-color:rgb(249, 131, 131); -fx-border-color: red; -fx-border-radius: 30");
            } else {
                allergyView.setImage(new Image(validImageFile.toURI().toString()));
                AllergyCritaryPane.setStyle("-fx-background-color: rgb(115, 191, 101); -fx-border-color: green; -fx-border-radius: 30");
            }

        } else {

            for (String foodConstraint: student.getGuestFood().split(",")) {
                for (String hostFood: other.getGuestFood().split(",")) {
                    if (foodConstraint.equalsIgnoreCase(hostFood)) {
                        food++;
                    }
                }
            }

            if (other.getHostHasAnimal().equalsIgnoreCase("yes") || student.getGuestAnimalAllergy().equalsIgnoreCase("yes")) {
                allergyView.setImage(new Image(falseImageFile.toURI().toString()));
                AllergyCritaryPane.setStyle("-fx-background-color:rgb(249, 131, 131); -fx-border-color: red; -fx-border-radius: 30; -fx-background-radius: 30");
            } else {
                allergyView.setImage(new Image(validImageFile.toURI().toString()));
                AllergyCritaryPane.setStyle("-fx-background-color:rgb(115, 191, 101); -fx-border-color: green; -fx-border-radius: 30; -fx-background-radius: 30");
            }
        }
        if (food < 2) {
            alimentaryView.setImage(new Image(falseImageFile.toURI().toString()));
            if (food==0) {
                AlimentaryCritariesPane.setStyle("-fx-background-color:rgb(249, 131, 131); -fx-border-color: red; -fx-border-radius: 30; -fx-background-radius: 30");
            } else {
                AlimentaryCritariesPane.setStyle("-fx-background-color:rgb(227, 143, 79); -fx-border-color: orange; -fx-border-radius: 30; -fx-background-radius: 30");
            }
        } else {
            alimentaryView.setImage(new Image(validImageFile.toURI().toString()));
            AlimentaryCritariesPane.setStyle("-fx-background-color: rgb(115, 191, 101); -fx-border-color: green; -fx-border-radius: 30; -fx-background-radius: 30");
        }
        commonHobbies = 0;
        for (String hobbieStudent : student.getHobbies().split(",")) {
            for (String hobbieOther : other.getHobbies().split(",")) {
                if (hobbieStudent.equalsIgnoreCase(hobbieOther)) {
                    commonHobbies ++;
                }
            }
        }
        commonHobbiesLabel.setText("Hobbies commun: "+commonHobbies);
        if(commonHobbies==0) {
            commonHobbiesPane.setStyle("-fx-background-color:rgb(249, 131, 131); -fx-border-color: red; -fx-border-radius: 30; -fx-background-radius: 30");
        } else if (commonHobbies == 1) {
             commonHobbiesPane.setStyle("-fx-background-color:rgb(227, 143, 79); -fx-border-color: orange; -fx-border-radius: 30; -fx-background-radius: 30");
        } else {
            commonHobbiesPane.setStyle("-fx-background-color: rgb(115, 191, 101); -fx-border-color: green; -fx-border-radius: 30; -fx-background-radius: 30");
        }


        genderPair = 0;
        if (student.getPairGender() == null || student.getPairGender().equals("") || student.getPairGender().equals(other.getGender())) {
            genderPair++;
            studentGenderPairView.setImage(new Image(validImageFile.toURI().toString()));
        } else {
            studentGenderPairView.setImage(new Image(falseImageFile.toURI().toString()));
        }
        if (other.getPairGender() == null || other.getPairGender().equals("") || other.getPairGender().equals(student.getGender())) {
            genderPair++;
            otherGenderPairView.setImage(new Image(validImageFile.toURI().toString()));
        } else {
            otherGenderPairView.setImage(new Image(falseImageFile.toURI().toString()));
        }
        if(genderPair==0) {
            genderPairPane.setStyle("-fx-background-color:rgb(249, 131, 131); -fx-border-color: red; -fx-border-radius: 30; -fx-background-radius: 30");
        } else if (genderPair == 1) {
             genderPairPane.setStyle("-fx-background-color:rgb(227, 143, 79); -fx-border-color: orange; -fx-border-radius: 30; -fx-background-radius: 30");
        } else {
            genderPairPane.setStyle("-fx-background-color: rgb(115, 191, 101); -fx-border-color: green; -fx-border-radius: 30; -fx-background-radius: 30");
        }
        
    }

    public void goToallResults () {
        try {
            Scene scene;
            if (RechercheController.isGuestStage) {
                scene = Recherche.newGuestScene(ExchangeGestion.getStudent());
            } else {
                scene = Recherche.newHostScene(ExchangeGestion.getStudent());
            }
            Stage stage = (Stage) matchButton.getScene().getWindow();
            stage.setScene(scene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void itsAMatch() {
        //faire apparaitre une popup
        if (ExchangeGestion.getStudent().equals(ExchangeGestion.STUDENT1)) {
            if (RechercheController.isGuestStage) {
                ExchangeGestion.setCurrentGuest1(other);
            } else {
                ExchangeGestion.setCurrentHost1(other);
            }
        } else {
            if (RechercheController.isGuestStage) {
                ExchangeGestion.setCurrentGuest2(other);
            } else {
                ExchangeGestion.setCurrentHost2(other);
            }
        }
        ExchangeGestion.setCurrentHostAndGuestChoices(ExchangeGestion.getStudent());
    }

}
