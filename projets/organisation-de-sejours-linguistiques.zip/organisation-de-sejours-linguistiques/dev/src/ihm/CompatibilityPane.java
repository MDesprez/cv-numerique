package ihm;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import poo.Student;

public class CompatibilityPane {

        public static Parent newParent (Student student, double affinityScore) throws IOException {
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = Accueil.class.getResource("CompatibilityPane.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();
                CompatibilityPaneController controller  = loader.getController();
                controller.compatibilityBar.setProgress(affinityScore);
                controller.studentNameLabel.setText(student.getSurname()+" "+student.getName());
                controller.studentAgeLabel.setText((LocalDate.now().getYear() - student.getBirthDate().getYear())+" ans");
                controller.countryImageView.setImage(new Image(ExchangeGestion.getCountryFlagFile(student.getHomeCountry()).toURI().toString()));
                controller.setStudent(student);
                return root;
        }
  
}
