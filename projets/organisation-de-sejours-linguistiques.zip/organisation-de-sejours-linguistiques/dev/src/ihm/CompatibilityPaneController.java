package ihm;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import poo.Student;

public class CompatibilityPaneController {
    
    private Student other;

    @FXML
    ImageView countryImageView;
    @FXML
    Label studentNameLabel;
    @FXML
    ProgressBar compatibilityBar;
    @FXML
    Label studentAgeLabel;
    @FXML
    AnchorPane backgroundPane;

    public  Student getStudent() {return other;}
    public  void setStudent(Student o){other = o;}

    public void setBackgroundPaneForImpossibleMatch() {
        backgroundPane.setBackground(new Background(new BackgroundFill(Color.RED, null, null)));
    }

    public void setBackgroundPaneForBestMatch() {
        backgroundPane.setBackground(new Background(new BackgroundFill(Color.GREEN, null, null)));
    }

    public void openAffinityResult() {
        try {
            Scene scene = AffinityPage.newScene(ExchangeGestion.getStudent(), other);
            Stage stage = (Stage) backgroundPane.getScene().getWindow();
            stage.setScene(scene); 
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void itsAMatch() {
        //faire apparaitre une popup
        if (ExchangeGestion.getStudent().equals(ExchangeGestion.STUDENT1)) {
            if (RechercheController.isGuestStage) {
                ExchangeGestion.setCurrentGuest1(other);
            } else {
                ExchangeGestion.setCurrentHost1(other);
            }
        } else {
            if (RechercheController.isGuestStage) {
                ExchangeGestion.setCurrentGuest2(other);
            } else {
                ExchangeGestion.setCurrentHost2(other);
            }
        }
        ExchangeGestion.setCurrentHostAndGuestChoices(ExchangeGestion.getStudent());
    }
}
