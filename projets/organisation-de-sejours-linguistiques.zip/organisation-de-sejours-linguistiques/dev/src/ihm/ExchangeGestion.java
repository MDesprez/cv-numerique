package ihm;

import java.io.File;
import java.util.List;

import poo.*;

public class ExchangeGestion {
    
    private static Exchange exchange;
    public static String src = System.getProperty("user.dir")+File.separator+"dev"+File.separator+"res"+File.separator+"ihm"+File.separator;
    public static Student STUDENT1 = CSVManager.createStudentFromCSV(CSVManager.src+CSVManager.studentInfoFile, 8);
    public static Student STUDENT2 = CSVManager.createStudentFromCSV(CSVManager.src+CSVManager.studentInfoFile, 5);
    
    private static Student actualStudent;

    private static Student defaultHost;
    private static Student defaultGuest;
    private static Student bestHost;
    private static Student bestGuest;
    private static Student currentHost1;
    private static Student currentGuest1;
    private static Student currentHost2 ;
    private static Student currentGuest2;
    private static Student currentHost;
    private static Student currentGuest;
    private static List<List<Student>> impossiblesPairs;

    private static boolean redhibitoiresCriteresSouhaites;
    private static double affiniteCriteres;
    private static String paysRecherche;

    
    public static Student getStudent() {return actualStudent;}
    public static boolean getRedhibitoiresCriteresSouhaites() {return redhibitoiresCriteresSouhaites;}
    public static double getAffiniteCriteres() {return affiniteCriteres;}
    public static String getPaysRecherche() { return paysRecherche;}
    public static Student getDefaultHost() {return defaultHost;}
    public static Student getDefaultGuest() {return defaultGuest;}
    public static Student getBestHost() {return bestHost;}
    public static Student getBestGuest() {return bestGuest;}
    public static Student getCurrentHost() {return currentHost;}
    public static Student getCurrentGuest() {return currentGuest;}
    public static List<List<Student>> getImpossiblePairs() {return impossiblesPairs;}
    public static Exchange getExchange() {return exchange;}

    public static void setStudent(Student student) {actualStudent = student;}
    public static void setRedhibitoiresCriteresSouhaites (boolean b) {redhibitoiresCriteresSouhaites = b;}
    public static void setAffiniteCriteres( double value) {affiniteCriteres = value;}
    public static void setPaysRecherche(String pays) {paysRecherche = pays;}

    public static void setCurrentHost1(Student currentHost1) {
        ExchangeGestion.currentHost1 = currentHost1;
    }
    public static void setCurrentGuest1(Student currentGuest1) {
        ExchangeGestion.currentGuest1 = currentGuest1;
    }
    public static void setCurrentHost2(Student currentHost2) {
        ExchangeGestion.currentHost2 = currentHost2;
    }
    public static void setCurrentGuest2(Student currentGuest2) {
        ExchangeGestion.currentGuest2 = currentGuest2;
    }
    public static void setExchangeByStudent (Student student) {

        if (!student.getHomeCountry().equals(exchange.getCountry1()) && !student.getHomeCountry().equals(exchange.getCountry2())) {
            exchange = new Exchange (exchange.getYear(), student.getHomeCountry(), exchange.getCountry2());
            List<Integer> ids = CSVManager.getIDsFromCsv(CSVManager.src+CSVManager.studentInfoFile);
            for (int id: ids) {
                Student s = CSVManager.createStudentFromCSV(CSVManager.src+CSVManager.studentInfoFile, id);
                exchange.addToHostAndGuest(s);
            }
            if (redhibitoiresCriteresSouhaites) {
                exchange.fillAffectationResults();
            } else {
                exchange.fillAffectationResultsWithoutRhedibitoryCritaries();
            }
            exchange.fillMeilleureAffectation();
        }

        defaultHost = exchange.getDefaultHost(actualStudent.getID());
        defaultGuest = exchange.getDefaultGuest(actualStudent.getID());
        bestHost= exchange.getBestChoiceOfHost(actualStudent.getID());
        bestGuest= exchange.getBestChoiceOfGuest(actualStudent.getID());
        impossiblesPairs = exchange.getImpossiblePairs(actualStudent.getID());

        if (student.getHomeCountry().equals(exchange.getCountry1())) {
            paysRecherche = exchange.getCountry2();
        } else {
            paysRecherche = exchange.getCountry1();
        }

    }

    public static void setCurrentHostAndGuestChoices(Student student) {
        if (student.equals(STUDENT1)) {
            currentHost = currentHost1;
            currentGuest = currentGuest1;
        } else {
            if (currentGuest2 == null) {
                currentGuest2 = defaultGuest;
            }
            currentGuest = currentGuest2;
            if (currentHost2 == null) {
                currentHost2 = defaultHost;
            }
            currentHost = currentHost2;
        }
    }

    public static void setStudentConnected (Student student) {
        setStudent(student);
        setExchangeByStudent(student);
        setCurrentHostAndGuestChoices(student);
    }

    public static void setExchangeByCountrySelected(String country) {
        if (!actualStudent.getHomeCountry().equals(country)) {
            exchange = new Exchange (exchange.getYear(), actualStudent.getHomeCountry(), country);
            List<Integer> ids = CSVManager.getIDsFromCsv(CSVManager.src+CSVManager.studentInfoFile);
            for (int id: ids) {
                Student s = CSVManager.createStudentFromCSV(CSVManager.src+CSVManager.studentInfoFile, id);
                exchange.addToHostAndGuest(s);
            }
            if (redhibitoiresCriteresSouhaites) {
                exchange.fillAffectationResults();
            } else {
                exchange.fillAffectationResultsWithoutRhedibitoryCritaries();
            }
            exchange.fillMeilleureAffectation();
            defaultHost = exchange.getDefaultHost(actualStudent.getID());
            defaultGuest = exchange.getDefaultGuest(actualStudent.getID());
            bestHost= exchange.getBestChoiceOfHost(actualStudent.getID());
            bestGuest= exchange.getBestChoiceOfGuest(actualStudent.getID());
            impossiblesPairs = exchange.getImpossiblePairs(actualStudent.getID());
            paysRecherche = country;
        }

    }

    public static File getCountryFlagFile(String country) {
        String path="";
        if (country.equals("FRANCE")) {
            path= src+"France.png";
        } else if (country.equals("SPAIN")) {
            path= src+"Espagne.png";
        } else if (country.equals("GERMANY")) {
            path= src+"Allemagne.png";
        } else {
            path= src+"Italie.png";
        }
        File file = new File(path);
        return file;
    }

    public static void startDemo() {

        exchange = new Exchange (2025,"FRANCE","GERMANY");
        List<Integer> ids = CSVManager.getIDsFromCsv(CSVManager.src+CSVManager.studentInfoFile);
        for (int id: ids) {
            Student s = CSVManager.createStudentFromCSV(CSVManager.src+CSVManager.studentInfoFile, id);
            exchange.addToHostAndGuest(s);
        }
        exchange.fillAffectationResults();
        exchange.fillMeilleureAffectation();
        actualStudent = STUDENT1;
        redhibitoiresCriteresSouhaites = true;
        affiniteCriteres = 50;
        paysRecherche = "FRANCE";
        defaultHost = exchange.getDefaultHost(actualStudent.getID());
        defaultGuest = exchange.getDefaultGuest(actualStudent.getID());
        bestHost= exchange.getBestChoiceOfHost(actualStudent.getID());
        bestGuest= exchange.getBestChoiceOfGuest(actualStudent.getID());
        currentHost1 = defaultHost;
        currentGuest1 = defaultGuest;
        currentHost2 = null;
        currentGuest2 = null;
        currentHost = defaultHost;
        currentGuest = defaultGuest;
        impossiblesPairs = exchange.getImpossiblePairs(actualStudent.getID());
    }

    public static double affinityScoreRatio (double value, double min, double max) {
        if (value >=42) {
            return 0;
        } else {
            return 1- ((value+3) / (10));
            //formule : (value-min)/(max-min)
        }
    }

    public static double getMinHostPairValue () {
        double minResult = 42;
        if (!exchange.affectationResults.isEmpty()) {
            for (List<Student> pair : exchange.affectationResults.keySet()) {
                if (pair.get(1).getID() == actualStudent.getID() && exchange.affectationResults.get(pair) < minResult) {
                    minResult = exchange.affectationResults.get(pair);
                }
            }
        }
        return minResult;    
    }

    public static double getMinGuestPairValue () {
        double minResult = 42;
        if (!exchange.affectationResults.isEmpty()) {
            for (List<Student> pair : exchange.affectationResults.keySet()) {
                if (pair.get(0).getID() == actualStudent.getID() && exchange.affectationResults.get(pair) < minResult) {
                    minResult = exchange.affectationResults.get(pair);
                }
            }
        }
        return minResult;    
    }

    public static double getMaxHostPairValue () {
        double maxResult = Double.MIN_VALUE;
        if (!exchange.affectationResults.isEmpty()) {
            for (List<Student> pair : exchange.affectationResults.keySet()) {
                if (pair.get(1).getID() == actualStudent.getID() && exchange.affectationResults.get(pair) > maxResult && exchange.affectationResults.get(pair)< 42) {
                    maxResult = exchange.affectationResults.get(pair);
                }
            }
        }
        return maxResult;
    }

    public static double getMaxGuestPairValue () {
        double maxResult = Double.MIN_VALUE;
        if (!exchange.affectationResults.isEmpty()) {
            for (List<Student> pair : exchange.affectationResults.keySet()) {
                if (pair.get(0).getID() == actualStudent.getID() && exchange.affectationResults.get(pair) > maxResult && exchange.affectationResults.get(pair)< 42) {
                    maxResult = exchange.affectationResults.get(pair);
                }
            }
        }
        return maxResult;
    }


}

    
