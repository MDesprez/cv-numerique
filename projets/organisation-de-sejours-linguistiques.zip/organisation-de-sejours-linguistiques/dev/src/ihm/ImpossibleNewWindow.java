package ihm;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ImpossibleNewWindow {
    public static void newPopUp () throws IOException {
            Stage stage = new Stage();
            FXMLLoader loader = new FXMLLoader();
            URL fxmlFileUrl = PopUpCriteres.class.getResource("ImpossibleNewWindow.fxml");

            if (fxmlFileUrl == null) {
                    System.out.println("Impossible de charger le fichier fxml");
                    System.exit(-1);
            }

            Parent root = loader.load(fxmlFileUrl.openStream());
            Scene scene = new Scene(root);
            stage.setScene(scene);
            //stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.showAndWait();
    }
}
