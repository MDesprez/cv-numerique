package ihm;

import javafx.fxml.FXML;
import javafx.scene.control.Slider;

public class MonController {

    @FXML
    private Slider monSlider;

    public void initialize() {
        monSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            double percent = newVal.doubleValue() / monSlider.getMax();
            String style = String.format(
                "-fx-background-color: linear-gradient(to right, #4B0082 0%%, #4B0082 %.0f%%, #E6CCF2 %.0f%%, #E6CCF2 100%%);",
                percent * 100, percent * 100
            );

            if (monSlider.lookup(".track") != null) {
                monSlider.lookup(".track").setStyle(style);
            }
        });
    }
}