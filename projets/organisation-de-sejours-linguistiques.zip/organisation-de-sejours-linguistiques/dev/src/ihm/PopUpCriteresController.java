package ihm;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Slider;
import javafx.stage.Stage;
import poo.Exchange;

public class PopUpCriteresController {
    
    @FXML
    Button saveButton;
    @FXML
    Button discardButton;
    @FXML
    Slider affinitySlider;
    @FXML
    CheckBox redhibitoirCheckBox;


    public void initialize() {
        affinitySlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            double percent = newVal.doubleValue() / affinitySlider.getMax();
            String style = String.format(
                "-fx-background-color: linear-gradient(to right, #4B0082 0%%, #4B0082 %.0f%%, #E6CCF2 %.0f%%, #E6CCF2 100%%);",
                percent * 100, percent * 100
            );

            if (affinitySlider.lookup(".track") != null) {
                affinitySlider.lookup(".track").setStyle(style);
            }
        });
    }

    public void onDiscardChanges() {
        Stage popup = (Stage) discardButton.getScene().getWindow();
        popup.close();
    }

    public void saveCritaries() {
        ExchangeGestion.setAffiniteCriteres(affinitySlider.getValue());
        ExchangeGestion.setRedhibitoiresCriteresSouhaites(redhibitoirCheckBox.isSelected());
        String countrySelected = "";
        Exchange e = ExchangeGestion.getExchange();
        if (e.getCountry1().equals(ExchangeGestion.getStudent().getHomeCountry())) {
            countrySelected = e.getCountry2();
        } else {
            countrySelected = e.getCountry1();
        }
        ExchangeGestion.setExchangeByCountrySelected(countrySelected);
        Stage popup = (Stage) saveButton.getScene().getWindow();
        popup.close();
    }


}
