package ihm;

import java.io.IOException;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PopUpPays extends Application {

        public void start(Stage stage) throws IOException {
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = getClass().getResource("PopUpPays.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();

                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
        }

        public static void newWindow () throws IOException {
                Stage stage = new Stage();
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = PopUpPays.class.getResource("PopUpPays.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();

                Scene scene = new Scene(root);
                stage.setTitle("Popup");
                stage.setScene(scene);
                stage.setResizable(false);
                stage.showAndWait();
        }

        public static void main(String[] args) {
                Application.launch(args);
        }


    
}