package ihm;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class PopUpPaysController {
    
    @FXML
    Button franceImageView;
    @FXML 
    Button spainImageView;
    @FXML
    Button germanyImageView;
    @FXML
    Button italyImageView;

    public void franceIsChoosen() {
       changeCountry("FRANCE");
    }

    public void germanyIsChoosen() {
        changeCountry("GERMANY");
    }

    public void spainIsChoosen() {
        changeCountry("SPAIN");
    }

    public void italyIsChoosen() {
        changeCountry("ITALY");
    }

    private void changeCountry(String country) {
        ExchangeGestion.setExchangeByCountrySelected(country);
        Stage popup = (Stage) franceImageView.getScene().getWindow();
        popup.close();

    }
}
