package ihm;

import java.io.IOException;
import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PopUpProfil{

        public static Stage stageFenetreCourante;

        public static void newWindow (Stage stageFenetre) throws IOException {
                stageFenetreCourante = stageFenetre;
                Stage stage = new Stage();
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = PopUpProfil.class.getResource("PopUpProfil.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();

                Scene scene = new Scene(root);
                stage.setWidth(504);
                stage.setHeight(266);
                stage.setTitle("Popup");
                stage.setScene(scene);
                stage.setResizable(false);
                stage.showAndWait();
        }
    
}
