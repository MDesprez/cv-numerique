package ihm;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class PopUpProfilController {

    @FXML
    Button suppressButton;
    @FXML
    Button discardButton;

    public void closePopUp() {
        Stage popup = (Stage) discardButton.getScene().getWindow();
        popup.close();
    }

    public void onDeleteProfil() throws IOException {
        if (ExchangeGestion.getStudent().equals(ExchangeGestion.STUDENT1)) {
            ExchangeGestion.getExchange().removeFromExchange(ExchangeGestion.STUDENT1);
            ExchangeGestion.STUDENT1 = null;
            AccueilController.setTextMenu1("ajouter un étudiant");
            if (ExchangeGestion.STUDENT2 != null) {
                ExchangeGestion.setStudentConnected(ExchangeGestion.STUDENT2);
            } else {
                ExchangeGestion.setStudent(null);
            }

        } else {
            ExchangeGestion.getExchange().removeFromExchange(ExchangeGestion.STUDENT2);
            ExchangeGestion.STUDENT2 = null;
            AccueilController.setTextMenu2("ajouter un étudiant");

            if (ExchangeGestion.STUDENT1 != null) {
                ExchangeGestion.setStudentConnected(ExchangeGestion.STUDENT1);
            } else {
                ExchangeGestion.setStudent(null);
            }

        }
        closePopUp();
        try{
           PopUpProfil.stageFenetreCourante.setScene(SuppressionProfil.newScene());
         
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }
    
}
