package ihm;

import java.io.IOException;
import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import poo.*;

public class Profil {

        public static Scene newScene(Student student) throws IOException {
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = Profil.class.getResource("Profil.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();
                Scene scene = new Scene(root);
                ProfilController controller = loader.getController();
                controller.setTextWithStudentInfos(student);
                controller.setPhotoProfil(student);
                controller.setCurrentChoices();
                return scene;
        }
}
