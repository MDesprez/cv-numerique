package ihm;

import java.io.IOException;
import java.time.LocalDate;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import poo.*;

public class ProfilController {
    @FXML
    Button hostResearchButton;
    @FXML
    Button guestResearchButton;
    @FXML
    Button supressProfilButton;
    @FXML
    Button changeProfilImageButton;
    @FXML
    Label studentName;
    @FXML
    Label ageLabel;
    @FXML
    Label countryLabel;
    @FXML
    Label hobbiesLabel;
    @FXML
    Label genderPairLabel;
    @FXML
    Label guestFoodLabel;
    @FXML
    Label guestAllergyLabel;
    @FXML
    Label hostFoodLabel;
    @FXML
    Label hostHasAnimalLabel;
    @FXML
    Label historicLabel;
    @FXML
    MenuButton menu;
    @FXML
    MenuItem intoAccueil;
    @FXML
    MenuItem intoProfil;
    @FXML
    MenuItem intoHost;
    @FXML
    MenuItem intoGuest;
    @FXML
    ImageView student1ImageView;
    @FXML
    ImageView student2ImageView;
    @FXML
    ImageView profilPhotoView;
    @FXML
    Label hostNameLabel;
    @FXML
    Label guestNameLabel;
    @FXML
    ImageView hostCountryImageView;
    @FXML
    ImageView guestCountryImageView;

    public void hostResearchOnClick() {
        try {
            Scene profilScene = Recherche.newHostScene(ExchangeGestion.getStudent());
            Stage stage = (Stage) hostResearchButton.getScene().getWindow();
            stage.setScene(profilScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void guestResearchOnClick() {
        try {
            Scene profilScene = Recherche.newGuestScene(ExchangeGestion.getStudent());
            Stage stage = (Stage) guestResearchButton.getScene().getWindow();
            stage.setScene(profilScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessAccueilOnMenu () {
        try {
            Scene accueilScene = Accueil.newScene();
            Stage stage = (Stage) menu.getScene().getWindow();
            stage.setScene(accueilScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessGuestOnMenu () {
        guestResearchOnClick();
    }

    public void accessHostOnMenu () {
        hostResearchOnClick();
        
    }

    public void suppressProfil () {
        try {
            Stage stage = (Stage) supressProfilButton.getScene().getWindow();
            PopUpProfil.newWindow(stage);
        } catch (IOException  e) {
            e.printStackTrace();
        }
        
    }

    public void setTextWithStudentInfos(Student student) {
            studentName.setText(student.getSurname()+" "+student.getName());
            ageLabel.setText("Age: "+ (LocalDate.now().getYear() - student.getBirthDate().getYear())+" ans");
            countryLabel.setText("Pays: "+ student.getHomeCountry());
            hobbiesLabel.setText("Hobbies: "+student.getHobbies());
            genderPairLabel.setText("Préfrérence de genre: "+ student.getPairGender());
            historicLabel.setText("Historique: "+student.getHistory());
            guestFoodLabel.setText(student.getGuestFood());
            guestAllergyLabel.setText(student.getGuestAnimalAllergy());
            hostFoodLabel.setText(student.getHostFood());
            hostHasAnimalLabel.setText(student.getHostHasAnimal());
    }

    public void setPhotoProfil(Student student) {
        profilPhotoView.setVisible(false);
        if (student.equals(ExchangeGestion.STUDENT1)) {
            student2ImageView.setVisible(false);
            student1ImageView.setVisible(true);
        } else {
            student1ImageView.setVisible(false);
            student2ImageView.setVisible(true);
        }
    }

    public void setCurrentChoices() { 
        if (ExchangeGestion.getCurrentGuest() == null) {
            guestNameLabel.setText("pas encore de visiteur attribué");
        } else {
            guestNameLabel.setText(ExchangeGestion.getCurrentGuest().getSurname()+" "+ExchangeGestion.getCurrentGuest().getName());
            guestCountryImageView.setImage(new Image(ExchangeGestion.getCountryFlagFile(ExchangeGestion.getCurrentGuest().getHomeCountry()).toURI().toString()));

        }
        if (ExchangeGestion.getCurrentHost() == null) {
            hostNameLabel.setText("pas encore d'hôte attribuée");

        } else {
            hostNameLabel.setText(ExchangeGestion.getCurrentHost().getSurname()+" "+ExchangeGestion.getCurrentHost().getName());
            hostCountryImageView.setImage(new Image(ExchangeGestion.getCountryFlagFile(ExchangeGestion.getCurrentHost().getHomeCountry()).toURI().toString()));
        }

    }
        
}
