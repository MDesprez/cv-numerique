package ihm;

import java.io.IOException;
import java.net.URL;
import java.util.List;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import poo.*;

public class Recherche {

        public static void showWindow () throws IOException{
                Stage stage = new Stage();
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = Profil.class.getResource("Recherche.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();

                Scene scene = new Scene(root);
                scene.getStylesheets().add(Recherche.class.getResource("style.css").toExternalForm());

                stage.setScene(scene);
                stage.setTitle("Recherche");
                stage.show();
        }
        
        private static Scene newScene(Student student, boolean isGuestStage) throws IOException {
                FXMLLoader loader = new FXMLLoader();
                URL fxmlFileUrl = Profil.class.getResource("Recherche.fxml");
                if (fxmlFileUrl == null) {
                        System.out.println("Impossible de charger le fichier fxml");
                        System.exit(-1);
                }
                loader.setLocation(fxmlFileUrl);
                Parent root = loader.load();

                Scene scene = new Scene(root);
                scene.getStylesheets().add(Recherche.class.getResource("style.css").toExternalForm());
                RechercheController controller = loader.getController();
                controller.setPhotoProfil(student);
                RechercheController.isGuestStage = isGuestStage;
                controller.affinitySlider.setValue(ExchangeGestion.getAffiniteCriteres());
                controller.redhibitoireCheckBox.setSelected(ExchangeGestion.getRedhibitoiresCriteresSouhaites());
                controller.paysChoisi.setImage(new Image(ExchangeGestion.getCountryFlagFile(ExchangeGestion.getPaysRecherche()).toURI().toString()));

                for (List<Student> pair : ExchangeGestion.getExchange().affectationResults.keySet()) {
                        if (isGuestStage) {
                                if (pair.get(0).getID() == student.getID()) {
                                        double affinityScore = ExchangeGestion.affinityScoreRatio(ExchangeGestion.getExchange().affectationResults.get(pair), ExchangeGestion.getMinGuestPairValue(), ExchangeGestion.getMaxGuestPairValue()) ;
                                        if (affinityScore>= ExchangeGestion.getAffiniteCriteres()/100) {
                                                Parent pane = CompatibilityPane.newParent(pair.get(1), affinityScore);
                                                controller.studentList.getChildren().add(pane);
                                        }
                                }
                        } else {
                                if (pair.get(1).getID() == student.getID()) {
                                        double affinityScore = ExchangeGestion.affinityScoreRatio(ExchangeGestion.getExchange().affectationResults.get(pair), ExchangeGestion.getMinHostPairValue(), ExchangeGestion.getMaxHostPairValue()) ;
                                        if (affinityScore>= ExchangeGestion.getAffiniteCriteres()/100) {
                                                Parent pane = CompatibilityPane.newParent(pair.get(0), affinityScore);
                                                controller.studentList.getChildren().add(pane);
                                        }
                                }
                        }
                }
                return scene;
        }

        public static Scene newHostScene (Student student) throws IOException {
                Scene scene = newScene(student,false);
                return scene;
        }

        public static Scene newGuestScene(Student student) throws IOException {
                Scene scene = newScene(student,true);
                return scene;
        }
}
