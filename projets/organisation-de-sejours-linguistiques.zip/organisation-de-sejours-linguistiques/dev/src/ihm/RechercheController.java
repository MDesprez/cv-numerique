package ihm;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import poo.*;

public class RechercheController {
    
    @FXML
    Button accueilButton;
    @FXML 
    Button modifCritariesButton;
    @FXML
    ImageView paysChoisi;
    @FXML
    Button changeCountryResearchButton;
    @FXML
    MenuButton menu;
    @FXML
    MenuItem intoAccueil;
    @FXML
    MenuItem intoProfil;
    @FXML
    MenuItem intoHost;
    @FXML
    MenuItem intoGuest;
    @FXML 
    Slider affinitySlider;
    @FXML 
    CheckBox redhibitoireCheckBox;
    @FXML
    ImageView student1ImageView;
    @FXML
    ImageView student2ImageView;
    @FXML
    VBox studentList;

    static boolean isGuestStage = false;

    public void initialize() {
        affinitySlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            double percent = newVal.doubleValue() / affinitySlider.getMax();
            String style = String.format(
                "-fx-background-color: linear-gradient(to right, #4B0082 0%%, #4B0082 %.0f%%, #E6CCF2 %.0f%%, #E6CCF2 100%%);",
                percent * 100, percent * 100
            );

            if (affinitySlider.lookup(".track") != null) {
                affinitySlider.lookup(".track").setStyle(style);
            }
        });
    }

    public void accessAccueilOnClick () {
        try {
            Scene profilScene = Accueil.newScene();
            Stage stage = (Stage) accueilButton.getScene().getWindow();
            stage.setScene(profilScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void openModifCritaryPopup() {
        try {
            PopUpCriteres.newWindow();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void changeCountryResearch () {
        try {
            PopUpPays.newWindow();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessAccueilOnMenu () {
        try {
            Scene accueilScene = Accueil.newScene();
            Stage stage = (Stage) menu.getScene().getWindow();
            stage.setScene(accueilScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessProfilOnMenu () {
        try {
            Scene accueilScene = Profil.newScene(ExchangeGestion.getStudent());
            Stage stage = (Stage) menu.getScene().getWindow();
            stage.setScene(accueilScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessGuestOnMenu () {
        try {
            Scene hostScene = Recherche.newGuestScene(ExchangeGestion.getStudent());
            Stage stage = (Stage) menu.getScene().getWindow();
            stage.setScene(hostScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void accessHostOnMenu () {
        try {
            Scene guestScene = Recherche.newHostScene(ExchangeGestion.getStudent());
            Stage stage = (Stage) menu.getScene().getWindow();
            stage.setScene(guestScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    public void setPhotoProfil(Student student) {
        if (student.equals(ExchangeGestion.STUDENT1)) {
            student2ImageView.setVisible(false);
            student1ImageView.setVisible(true);
        } else {
            student1ImageView.setVisible(false);
            student2ImageView.setVisible(true);
        }
    }

    public void franceIsChoosen() {
        if (!ExchangeGestion.getStudent().getHomeCountry().equals("FRANCE")) {
            ExchangeGestion.setPaysRecherche("FRANCE");
        }
    }

    public void germanyIsChoosen() {
        if (!ExchangeGestion.getStudent().getHomeCountry().equals("GERMANY")) {
            ExchangeGestion.setPaysRecherche("GERMANY");
        }
    }

    public void italyIsChoosen() {
        if (!ExchangeGestion.getStudent().getHomeCountry().equals("ITALY")) {
            ExchangeGestion.setPaysRecherche("ITALY");
        }
    }

    public void spainIsChoosen() {
        if (!ExchangeGestion.getStudent().getHomeCountry().equals("SPAIN")) {
            ExchangeGestion.setPaysRecherche("SPAIN");
        }
    }

    public void refresh() {
        if (isGuestStage) {
            try {
                Scene scene = Recherche.newGuestScene(ExchangeGestion.getStudent());
                Stage stage = (Stage) accueilButton.getScene().getWindow();
                stage.setScene(scene);

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                Scene scene = Recherche.newHostScene(ExchangeGestion.getStudent());
                Stage stage = (Stage) accueilButton.getScene().getWindow();
                stage.setScene(scene);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
