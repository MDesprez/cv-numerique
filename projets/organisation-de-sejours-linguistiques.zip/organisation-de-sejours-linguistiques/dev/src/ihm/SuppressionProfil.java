package ihm;

import java.io.IOException;
import java.net.URL;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class SuppressionProfil {
    
    public static Scene newScene() throws IOException {
            FXMLLoader loader = new FXMLLoader();
            URL fxmlFileUrl = Profil.class.getResource("SuppressionProfil.fxml");
            if (fxmlFileUrl == null) {
                    System.out.println("Impossible de charger le fichier fxml");
                    System.exit(-1);
            }
            loader.setLocation(fxmlFileUrl);
            Parent root = loader.load();
            Scene scene = new Scene(root);
            return scene;
    }
}
