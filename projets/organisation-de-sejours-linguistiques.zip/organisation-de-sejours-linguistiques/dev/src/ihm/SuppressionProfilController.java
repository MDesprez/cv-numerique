package ihm;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class SuppressionProfilController {
    
    @FXML
    Button retourAccueilButton;

    public void retourAccueil () {
        try {
            Scene profilScene = Accueil.newScene();
            Stage stage = (Stage) retourAccueilButton.getScene().getWindow();
            stage.setScene(profilScene);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
