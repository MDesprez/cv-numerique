package poo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class CSVManager {

    /**
     * chemin vers les ressources à partir de la position de l'utilisateur (au niveau de la racine du projet)
     */
    public static String src = System.getProperty("user.dir")+File.separator+"dev"+File.separator+"res"+File.separator+"poo"+File.separator; // user.dir donne le répertoire courant de l'arborescence de fichier
    public static String studentInfoFile = "students_infos.csv";
    public static String affectationWritingFile = "resultat_affectation.csv";

    /**
     * fonction qui récupère une information d'un étudiant en fontction de son id et du rang voulu
     * @param file fichier csv utilisé pour récupérer l'information
     * @param id identifiant de l'étudiant
     * @param range rang de la ligne du csv qui corespond à l'information que l'on veut récupérer
     * @return information de l'étudiant importée du fichier CSV
     */
    public static String getInfosFromCsv (String file, int id, int range) {
        try (Scanner scLine = new Scanner(new File(file))) { //on lit le fichier ligne par ligne 
            boolean idFound = false; //booléen permettant de savoir si on a attint la ligne avec les bonnes informations, basé sur l'ID
            String value = ""; //valeur qu'on renverra
            scLine.nextLine(); //on passe la première ligne qui est celle des noms des colonnes
            while (scLine.hasNextLine() && !idFound) { //tant qu'on n'a pas trouvé le bon ID, on continuerade lire le fichier
                Scanner scInfos = new Scanner (scLine.nextLine()).useDelimiter(";"); //nouveau scanner pour cette fois ci lire les infos de la ligne
                int idOfLine = scInfos.nextInt(); //id de la ligne
                if (id == idOfLine) { //si l'id correspond à l'id recherché
                    idFound = true; //on met à true la variable booléenne de recherche (cela arrêtera la poursuite du while et de la lecture des lignes)
                    if (range == 0) { //si l'information qu'on recherche est l'ID
                        scInfos.close();
                        value = ""+idOfLine;
                    } else { // si l'information qu'on recherche est autre que l'id
                        for (int i = 1; i< range; i++) { // on parcours "à vide" la ligne jusqu'à arriver à la donnée que l'on veut
                            scInfos.next();
                        }
                        value = scInfos.next(); //on prend la valeur que l'on recherche
                        scInfos.close();
                    }
                }
                scInfos.close();
            }
            return value; //renvoi de la valeur recherchée

        } catch (FileNotFoundException e) {
            System.out.println("Fichier introuvable");
            return null;
        }
    }

    /**
     * Fonction qui importe les valeurs correspondant aux critères d'un étudiant en fonction de son ID et qui les place dans une Map
     * @param file fichier dont on extrait les informations
     * @param ID identifiant de l'étudiant dont on veut les informations
     * @return Map qui associe les critères d'un étudiant à leurs valeurs correspondantes
     */
    public static Map<Critaries,String> csvToHashMapForCritaries (String file, int id) {
        Map<Critaries,String> caracteristics = new HashMap<Critaries,String>(); //création d'une Map pour ranger les valeurs associées aux critères d'une personne
        Critaries[] criteres = Critaries.values(); //ensemble des critères possibles 
        for (int i = 5; i < 13; i++) {
            caracteristics.put(criteres[i-5], getInfosFromCsv(file, id, i)); //remplissage de la Map avec la valeur du CSV associée au bon critère
        }
        return caracteristics;
    }

    /**
     * Récupère l'ensemble des identifiants d'un fichiers CSV 
     * @param file fichier CSV dont on extrait les informations
     * @return liste regroupant l'ensemble des identifiants 
     */
    public static List<Integer> getIDsFromCsv(String file) {
        //ou un set ?
        try (Scanner scLine = new Scanner(new File(file))) { //on lit le fichier ligne par ligne 
            List<Integer> ids = new ArrayList<Integer>(); //valeur qu'on renverra
            scLine.nextLine(); //on passe la première ligne qui est celle des noms des colonnes
            while (scLine.hasNextLine()) { 
                Scanner scInfos = new Scanner (scLine.nextLine()).useDelimiter(";"); //nouveau scanner pour cette fois ci lire les infos de la ligne
                ids.add(scInfos.nextInt()); //id de la ligne
                scInfos.close();
            }
            return ids;

        }catch (FileNotFoundException e) {
            System.out.println("Fichier introuvable");
            return new ArrayList<Integer>();
        }
    }


    /**
     * Crée une nouvelle instance de Student à partir d'un fichier CSV
     * @param file fichier CSV contenant les informations de l'étudiant
     * @param ID identifiant de l'étudiant
     * @return une instance de la classe Student 
     */
    public static Student createStudentFromCSV (String file, int id) {

        String[] date = getInfosFromCsv(file, id, 4).split("-");
        int year = Integer.parseInt(date[0]);
        int month = Integer.parseInt(date[1]);
        int day = Integer.parseInt(date[2]);
        return new Student (Integer.parseInt(getInfosFromCsv(file, id, 0)),getInfosFromCsv(file, id, 2),getInfosFromCsv(file, id, 1),getInfosFromCsv(file, id, 10),LocalDate.of(year, month, day),getInfosFromCsv(file, id, 3),csvToHashMapForCritaries(file, id));
    }

    /**
     * Réécrit le fichier CSV des étudiants
     * @param file fichier à réécrire
     * @param newList données à entrer
     */
    public static void writeNewStudentCSV (String file, List<Student> newList) {
        try (FileWriter fw = new FileWriter(file)) {
            fw.write("ID;FORENAME; NAME; COUNTRY; BIRTH_DATE; GUEST_ANIMAL_ALLERGY; HOST_HAS_ANIMAL; GUEST_FOOD_CONSTRAINT; HOST_FOOD; HOBBIES; GENDER; PAIR_GENDER; HISTORY\n");
            for (Student s : newList) {

                List<String> infosStudent = new ArrayList<>(); //mise dans une liste detoutes les informations correspondant à l'étudiant 
                infosStudent.add(""+s.getID());
                infosStudent.add(s.getSurname());
                infosStudent.add(s.getName());
                infosStudent.add(s.getHomeCountry());
                infosStudent.add(""+s.getBirthDate());
                infosStudent.add(s.getGuestAnimalAllergy());
                infosStudent.add(s.getHostHasAnimal());
                infosStudent.add(s.getGuestFood());
                infosStudent.add(s.getHostFood());
                infosStudent.add(s.getHobbies());
                infosStudent.add(s.getGender());
                infosStudent.add(s.getPairGender());
                infosStudent.add(s.getHistory());

                for (String info : infosStudent) { //parcours de l'ensemble des informations
                    if (info == null) { //si lavaleur est nulle, alors on laisse la valeur à vide dans le csv
                        fw.write("");
                    } else { // sinon on l'écrit tel quel
                        fw.write(info);
                    }
                    fw.write(";"); //séparateur du csv
                }
                fw.write("\n"); //retour à la ligne lorsque l'écriture d'un étudiant est terminée
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    /**
     * Ecrit l'ensemble des affectations d'un échange étudiant dans le fichier CSV correspondant
     * ATTENTION: il faut que les listes utilisées comme clés dans la Map soient toutes différentes
     * @param file fichier des affectations
     * @param mapOfAffectations Map des coupkes host/guests et leur valeur d'affinité correspondante
     */
    public static void writeAffectationResultOnCSV (String file, Map<List<Student>,Double> mapOfAffectations) {
        try (FileWriter fw = new FileWriter(file)) { //écriture dans le fichier des affectations
            fw.write("HOSTID;GUESTID;SCORE_AFFINITY\n"); //écriture de la première ligne, celle des nom des colonnes
            Set<List<Student>> coupleHostGuest = mapOfAffectations.keySet(); //Set de l'ensemble des clés de la map qui correspondent à l'ensemble des couples host/guest sous forme d'une liste à deux éléments
            for (List<Student> s : coupleHostGuest) { //parcours du Set sur les listes
                Student host = s.get(0); //extraction de l'hote
                Student guest = s.get(1); // extraction du visiteur
                fw.write(host.getID()+";"+guest.getID()+";"+mapOfAffectations.get(s)+";\n");
                //écriture sous la forme host;guest;affinityScore; 
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    //public static void addNewStudentOnCSV (String file, Student s) ; ajouter un etudiant a la fin du fichier CSV

    public static void main(String[] args) {
        // test d'écriture dans des fichiers tests
        Student s1 = createStudentFromCSV(src+studentInfoFile, 1);
        Student s2 = createStudentFromCSV(src+studentInfoFile, 2);
        Student s3 = createStudentFromCSV(src+studentInfoFile, 3);
        Student s4 = createStudentFromCSV(src+studentInfoFile, 4);
        List<Student> l1 = new ArrayList<Student>();
        l1.add(s1);
        l1.add(s2);
        l1.add(s3);
        l1.add(s4);
        writeNewStudentCSV(src+"test.csv", l1);
        Student s5 = createStudentFromCSV(src+"test.csv", 1);
        Student s6 = createStudentFromCSV(src+"test.csv", 2);
        Student s7 = createStudentFromCSV(src+"test.csv", 3);
        Student s8 = createStudentFromCSV(src+"test.csv", 4);
        List<Student> l2 = new ArrayList<Student>();
        l2.add(s5);
        l2.add(s6);
        l2.add(s7);
        l2.add(s8);
        writeNewStudentCSV(src+"test.csv", l2);

        List<Student> l3 = new ArrayList<Student>();
        List<Student> l4 = new ArrayList<Student>();
        List<Student> l5 = new ArrayList<Student>();

        l3.add(s1);
        l3.add(s2);
        Map<List<Student>,Double> m1 = new HashMap<>();
        m1.put(l3, 3.0);
        l4.add(s2);
        l4.add(s1);
        m1.put(l4, 3.0);
        l5.clear();
        l5.add(s1);
        l5.add(s4);
        m1.put(l5, 1.0);
        writeAffectationResultOnCSV(src+"affectationTest.csv", m1);

    }

}
