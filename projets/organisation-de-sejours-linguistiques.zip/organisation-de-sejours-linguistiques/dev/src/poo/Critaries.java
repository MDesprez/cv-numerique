package poo;

import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.io.File;


public enum Critaries {

    /*
     * Valeurs que peuvent prendre l'énumération
     */
    GUEST_ANIMAL_ALLERGY('B'), HOST_HAS_ANIMAL('B'), GUEST_FOOD('T'), HOST_FOOD('T'), HOBBIES('T'), GENDER('T'), PAIR_GENDER('T'), HISTORY('T');

    private final char TYPECHAR; // attribut de chaque contantes de l'énumération: elle correspond au véritable type de valeur de la constante (qui sera en String pr défaut sinon)
    // B pour booléen
    // T pour Text et donc String
    // D pour Date

    /**
     * Constructeur principal de l'enum
     * @param value
     */
    Critaries (char value) {
        this.TYPECHAR = value;
    }

    /*
     * Getter de TYPECHAR
     */
    public char getTYPECHAR() {
        return this.TYPECHAR;
    }

    /**
     * fonction retournant un tableau de chaine de caractères correpondant 
     * aux valeurs possibles non sensibles à la casse de chaque valeur de l'énumération
     * @param critary : Constante de l'énumération
     * @return un tableau de chaine de caractères
     */
    public static String[] returnTabCritary(Critaries critary) {
        if (critary == GUEST_ANIMAL_ALLERGY || critary == HOST_HAS_ANIMAL) {
            return new String[] {"yes", "no"};
        } else if (critary == GUEST_FOOD || critary == HOST_FOOD) {
            return new String[] {null,"", "nonuts", "vegetarian", "nonuts,vegetarian"};
        } else if (critary == HOBBIES) {
            return new String[] {}; // tu peux ajouter une vérification plus tard si tu veux
        } else if (critary == PAIR_GENDER || critary == GENDER) {
            return new String[] {null,"","other", "female", "male"};
        } else { //HISTORY
            return new String[] {null,"", "same", "other"};
        }
    }

    /**
     * fonction retournant un tableau de chaine de caractères correpondant 
     * aux valeurs possibles non sensibles à la casse de chaque valeur de l'énumération selon un fichier de préconfiguration
     * @param critary : Constante de l'énumération
     * @param file : nom du fichier de préconfiguration donnant les valeurs possibles pour le critère correspondant
     * @return un tableau de chaine de caractères
     */
    public static String[] returnTabCritaryBasedOnFileInfos(Critaries critary, String file) {
        try (Scanner scLine = new Scanner (new File (CSVManager.src + file))) {
            boolean isCorrectCritary = false;
            while (scLine.hasNextLine()&& !isCorrectCritary) {
                Scanner scWord = new Scanner (scLine.nextLine()).useDelimiter(",");
                if (scWord.next().equals(critary.name())) {
                    isCorrectCritary = true;
                    List<String> values = new ArrayList<>();
                    String [] listeValue= new String[values.size()];
                    while (scWord.hasNext()) {
                        values.add(scWord.next());
                    }
                    for (int i=0; i<listeValue.length; i++) {
                        listeValue[i] = values.get(i);
                    }
                    scWord.close();
                    return listeValue;
                }
                scWord.close();
            }
            return null;

        } catch (FileNotFoundException e) {
            return null;
        }
    }

    /**
     * vérifie si une valeur est bien valide en vérifiant si elle correspond à une valeur valide du tableau  
     * @param value  valeur à vérifier
     * @param validValues : tableau des valeurs possibles pour le critère
     * @return : true si le critère est valide et false sinon
     */
    public static boolean verifCritary (String value, String[] validValues){
        boolean valueIsValid = false;
        if (validValues.length == 0) {
            valueIsValid = true; // il s'agit des hobbies
        } else {
            int i = 0;
            while (i<validValues.length && !valueIsValid){
                if (value.equalsIgnoreCase(validValues[i])) {
                    valueIsValid = true;
                }
                i++;
            }
        }
        return valueIsValid;
    }
}