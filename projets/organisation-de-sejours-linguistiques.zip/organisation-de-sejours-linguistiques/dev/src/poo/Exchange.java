package poo;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Exchange implements Serializable{

    private static final int GOOD_AFFINITY = 1;
    private static final int PENALITY = 5;
    private static final int PROHIBITIVE_CONSTRAINT = 42;
    
    /**
     * tableau contenant l'ensemble des hôtes
     */
    public List<Student> hosts = new ArrayList<Student>();

    /**
     * tableau contenant l'ensemble des guests
     */
    public List<Student> guests = new ArrayList<Student>();

    /**
     * Map contenant le résultat des affectations : un couple host/individu et un score d'affinité
     */
    public Map <List<Student>,Double> affectationResults = new HashMap<>();
    public Map <List<Student>,Double> meilleurAppariement = new HashMap<>();

    private int year;
    private String country1;
    private String country2;

    public Exchange (int year, String country1, String country2) {
        this.year = year;
        this.country1 = country1;
        this.country2 = country2;
    }

    //getters

    public int getYear() {return this.year;}
    public String getCountry1() {return this.country1;}
    public String getCountry2() {return this.country2;}
    
    /**
     * recherche des éléments en commun dans deux tableaux de chaines de caractères
     * @param guest : tableau de chaine de caractères 
     * @param host : tableau de chaine de caractères
     * @return nombre d'éléments en commun dans les deux tableaux
     */
    private static int searchCommonTab (String[] guest, String[] host) {
        int commonString = 0;
        for (String g: guest) { //parcours entier du tableau guest
            for (String h: host) { //parcours entier du tableau host
                if (g.equalsIgnoreCase(h)) { // si les valeurs sont égales ( donc un hobbies en commun par exemple)
                    commonString ++; //on ajoute 1 au compteur de commun
                }
            }
        }
        return commonString;
    }

    /**
     * Calcule le score d'affinité entre deux étudiants (une paire (host-guest))
     * @param guest invité 
     * @param host hôte
     * @return score d'affinité entre deux personnes
     */
    public static double affinityScore1 (Student guest, Student host) {
        double affinity = 0;

        //birthdate
        if (guest.getMonthDifferences(host) < 18 && -18 < guest.getMonthDifferences(host)) { // test à améliorer
            affinity -= 1;
        }

        // pair gender
        if (guest.getPairGender() != null && !guest.getPairGender().equals("")) { // si il y a une préférence indiquée dans le formulaire du guest
            if (!guest.getPairGender().equals(host.getGender())) { //on vérifie si elle est égale au genre de l'hôte (ils ne peuvent choisir qu'une seule réponse de pairGender dans le formulaire; alors pas besoin de boucle)
                affinity += 2; // si ils sont différents, on ajoute un malus à la paire
            }
        } 
        if (host.getPairGender() != null && !host.getPairGender().equals("")) { //idem
            if (!host.getPairGender().equals(guest.getGender())) {
                affinity += 2;
            }
        }

        //hobbies
        String[] guestHobbies = guest.getHobbies().split(",");// on sépare les hobbies dans deux tableaux de texte
        String[] hostHobbies = host.getHobbies().split(",");
        int commonHobbies = searchCommonTab(guestHobbies, hostHobbies); //et on vérifie le nombre de hobbies qu'ils ont en commun
        affinity = affinity - commonHobbies; //on rajoute un bonus pour le nombre de honnies en commun

        return affinity;
    }

    /**Fonction appelée pour vérifier si l'historique peut empécher une paires de se réaliser et renvoie son résultat grace a une ENUM
     * @param guest invité
     * @param host hôte
     * @param historyPath chemin d'accées du fichier historique
     * @return HistoriqueStatus .
     */
    public static HistoriqueStatus historique_valide(Student guest, Student host){

        List<Exchange> history = HistoryManager.readTheHistoric();//On amméne le fichier avec toute les données de l'historique

        String hoteForGuest = null; //Création des variables qui nous permetrons de stocké les valeurs séléctionner par l'host et le visiteur sur l'historique des échanges
        String guestForHost = null;

        //Permet de parcourir toute les paires host-guest présente dans l'historique
        for(Exchange e : history){
            for(List<Student> pair : e.affectationResults.keySet()){
                Student hostHistory = pair.get(0);
                Student guestHistory = pair.get(1);
                
                //Si il y a une paire host vers guest on trouve sont appréciation
                if(hostHistory.getID() == host.getID() && guestHistory.getID() == guest.getID()){
                    hoteForGuest = host.getHistory();
                }

                //Si il y a une paire guest vers host on trouve sont appréciation
                if(hostHistory.getID() == guest.getID() && guestHistory.getID() == host.getID()){
                    guestForHost = guest.getHistory();
                }
            }
        }

        //Si une contrainte rédhibitoire est détécté !!
        if("other".equalsIgnoreCase(hoteForGuest) || "other".equalsIgnoreCase(guestForHost)){
            return HistoriqueStatus.REDHIBITOIRE;
        }

        //Si le bonus d'affinité a étais trouvé !!
        if("same".equalsIgnoreCase(hoteForGuest) || "same".equalsIgnoreCase(guestForHost)){
            return HistoriqueStatus.BONUS;
        }

        return HistoriqueStatus.NULL;
    }

    /**Méthode appelé afin de  parcourir les critères qui sont rédibitoires et verifie la compatibilité entre guest et host.
     * @param guest visiteur
     * @param host hôte
     * @return Nombre de critères rédhibitoire
     */
    public static int countRedhibitory(Student guest, Student host){
        int result = 0; //Nombre de critére rédhibitoire

        //1er test de critère rédhibitoire : les allergie aux animaux
        if("yes".equalsIgnoreCase(guest.getGuestAnimalAllergy()) && "yes".equalsIgnoreCase(host.getHostHasAnimal())){
            result++;
        }

        //2ème test de critère rédhibitoire : les Allergie lié a l'alimentation
        //Ici, la méthode parcourt chaque critére de guest puis vas regarder si host l'accepte, si il ne l'accepte pas chaque critére sont compté comme +1.
        //Normalement seul Nonuts et Vegetarian sont accepté pour le moment. 
        String guestFood = guest.getGuestFood();
        String hostFood = host.getHostFood();

        if(guestFood != null && !guestFood.equals("")){
            String[] regimeGuest = guestFood.split(",");//Range dans un tableau chaque regime que posséde le visiteur

            for(String rG : regimeGuest){
                boolean allergie = false;

                if(hostFood != null){
                    String[] regimeHost = hostFood.split(",");

                    for(String rH : regimeHost){
                        if(rH.trim().equalsIgnoreCase(rG.trim())){
                            allergie = true;
                            break; //Si le régime correspont avec l'hôte, inutile de faire la suite
                        }
                    }
                }

                //Si le régime du visiteur n'as pas étais trouvé dans celui de l'hôte, un critère rédhibitoire est rajouté
                if(!allergie){
                    result++;
                }
            }
        }
        return result;
    }

    
    /**Permet de calculer le score d'affinité obtenue entre 2 étudiants (hôte-guest)
     * @param guest invité
     * @param host hôte
     * @return score d'affinité entre les deux personnes
     */
    public static double affinityScore3(Student guest, Student host){

        double affinity = affinityScore1(guest, host); //Appel a la fonction score affinité 1 qui s'occupe des bonus et malus non lié aux critére rédhibitoire
        
        //Nous allons en premier lieu vérifier les contraintes rédhibitoires pour éviter de faire divers tests inutils, appel à la fonction historique_valide définie en fin de code
        //Creation d'une variable pour éviter de répéter la fonction historique_valide 

        HistoriqueStatus historique_status = historique_valide(guest, host);
        //Si le status désiré par l'un des deux étudiants est "other"
        if(historique_status == HistoriqueStatus.REDHIBITOIRE){
            return PROHIBITIVE_CONSTRAINT;
        }

        //Appel a la fonction countRedhibitory qui permet de savoir le nombre de critére rédhibitoire non éliminatoire
        int redhibitoryCpt = countRedhibitory(guest, host);

        //Si la paire a un niveau d'affinité très élevé et posséde plusieurs critére rédhibitoire, on l'a renvoie avec un score très élevé
        if(redhibitoryCpt >= 2 && affinity >= GOOD_AFFINITY + 1){
            return PROHIBITIVE_CONSTRAINT;
        }

        //Si la paire n'est pas mauvaise mais posséde un ou deux critére rédhibitoire, on lui ajoute une pénalité en fonction du nombre de critére rédhibitoire non respecté
        if((redhibitoryCpt == 1 || redhibitoryCpt == 2) && affinity <= GOOD_AFFINITY){
            affinity += PENALITY * redhibitoryCpt;
        }

        //Si l'un des deux étudiants a exprimé une préférence "same" dans l'historique, la paire bénificie d'un bonus d'apparaiment ! 
        if(historique_status == HistoriqueStatus.BONUS){
            affinity -= 2;
        }

        //Renvoie le score final entre guest et host
        return affinity;
        
    }

    /** Ajoute au groupe correcpondant l'étudiant si et seulement si il est valide et renvoie un booléen correspondant au succès de l'action
     * @param student : étudiant à ajouter
     * @param group : group dans lequel on souhaite ajouter l'étudiant
     * @return true si l'étudiant a été ajouté et false sinon
     */
    private static void addToGroup (Student student, List<Student> group) throws InvalidStudentException {
        if (student.isValidPerson()) {
            group.add(student);
        } else {
            throw new InvalidStudentException("Etudiant "+student.getID()+" invalide");
        }
    }

    /** Ajoute au hôtes et aux visiteurs l'étudiant si et seulement si il est valide et qu'il correspond à l'un des deuc pays de l'échange et renvoie un booléen correspondant au succès de l'action
     * @param student : étudiant à ajouter
     * @return true si l'étudiant a été ajouté et false sinon
     */
    public boolean addToHostAndGuest (Student student) {
        try{
            if (student.getHomeCountry().equalsIgnoreCase((this.country1) )|| student.getHomeCountry().equalsIgnoreCase(this.country2)) {
                addToGroup(student, this.hosts);
                addToGroup(student, this.guests);
            }
            
            return true;
        } catch (InvalidStudentException e) {
            System.out.println(e);
            return false;
        }
    }

    /**
     * Récupère un Etudiant si il existe dans la Map
     * @param ID idetifiant de l'étudiant
     * @return Etudiant si il existe
     */
    public Student getStudent (int id) {
        Student student = null;
        for (Student s : this.hosts) {
            if (s.getID() == id) {
                student = s;
            }
        }
        return student;
    }

    /**
     * Retire un étudiant du voyage si il y est déjà présent
     * @param student Etudiant
     * @return true si il a pu être retiré et false sinon
     */
    public boolean removeFromExchange (Student student) {
        boolean removed = this.hosts.remove(student) && this.guests.remove(student);
        if (removed) {
            this.fillAffectationResults();
            this.fillMeilleureAffectation();
        }
        return removed;
        
    }

    /**
     * Retire un étudiant du voyage si il y est déjà présent
     * @param idStudent identifiant de l'étudiant
     * @return true si il a pu être retiré et false sinon 
     */
    public boolean removeFromExchange (int idStudent) {
        Student student = this.getStudent(idStudent);
        if (student != null) {
            return this.removeFromExchange(student);
        } else {
            return false;
        }
    }
    
    @Override
    public String toString() {
        return "***Hosts***\n" + this.hosts.toString() + "\n\n***Guests***\n" + this.guests.toString();
    }

    /**
     * Remplis la Map d'affectation de l'échange en fonction des deux pays comcernés et des résultats de la fonction de score affinité
     */
    public void fillAffectationResults() {
        this.affectationResults.clear();
        for (Student host: this.hosts) {
            for (Student guest: this.guests) {
                if (!host.equals(guest) && !host.getHomeCountry().equals(guest.getHomeCountry())) {
                    List<Student> pair = new ArrayList<Student>();
                    pair.add(host);
                    pair.add(guest);
                    double affinity = affinityScore3(guest, host);
                    this.affectationResults.put(pair, affinity);
                }
            }
        }
    }

    /**
     * Remplis la Map d'affectation de l'échange en fonction des deux pays comcernés et des résultats de la fonction de score affinité
     */
    public void fillAffectationResultsWithoutRhedibitoryCritaries() {
        this.affectationResults.clear();
        for (Student host: this.hosts) {
            for (Student guest: this.guests) {
                if (!host.equals(guest) && !host.getHomeCountry().equals(guest.getHomeCountry())) {
                    List<Student> pair = new ArrayList<Student>();
                    pair.add(host);
                    pair.add(guest);
                    double affinity = affinityScore1(guest, host);
                    this.affectationResults.put(pair, affinity);
                }
            }
        }
    }

    /**
     * https://www.iro.umontreal.ca/~dift1575/ift1575_doc_hongrois.pdf : algorithme hongrois
     * @param allAffectations toutes les affectations possibles host/guests ainsi que leur score d'affinité en valeur
     * @param hosts liste des hôtes
     * @param guests liste des visiteurs
     * @return table associative ayant pout clé les paire host/guest et comme valeur leur score d'affinité calculé pour être des appariements optimaux
     */
    public static Map<List<Student>,Double> meilleureAffectation (Map<List<Student>,Double>  allAffectations, List<Student> hosts, List<Student> guests) {

        double[][] matrice = new double[hosts.size()][guests.size()];
        List<Integer[]> positions = new ArrayList<Integer[]> ();
        boolean[] positionLigne = new boolean[hosts.size()];
        boolean[] positionCol = new boolean[guests.size()];

        //1ere étape: on remplit la matrice des valeurs de la Map
        for (int i=0; i<hosts.size(); i++) {
            for (int j=0; j<guests.size(); j++) {
                if (i == j) {
                    matrice[i][j] = 1000; // on retire les appariements de même personne en host et guest avec une valeur très élevée
                } else {
                    List<Student> paire = new ArrayList<>();
                    paire.add(hosts.get(i));
                    paire.add(guests.get(j));
                    matrice[i][j] = allAffectations.getOrDefault(paire, 1000.0);
                    
                }
                
            }
        }
        //mise à niveau pour que toutes les valeurs soient positives dans le tableau: recherche du minimum
        double minTotal = matrice [0][0];
        for (int i=0; i<matrice.length; i++) {
            for (int j=0; j<matrice[i].length; j++) {
                if (matrice[i][j] < minTotal) {
                    minTotal = matrice[i][j];
                }
            }
        }

        //on ajoute le minTotal à l'ensemble du tableau pour avoir comme valeur minimale 0
        for (int i=0; i<matrice.length; i++) {
            for (int j=0; j<matrice[i].length; j++) {
                matrice[i][j] += Math.abs(minTotal);
            }
        }

            //étape 2 a): le retrait de la valeur minimale dans la matrice pour chaque rangée
            for (int i=0; i<matrice.length; i++) {
                double min = matrice[i][0];
                for (int j=0; j<matrice[i].length; j++) {
                    if (matrice[i][j] < min) {
                        min = matrice[i][j];
                    }
                }
                //étape 2 b): soustraire la valeur minimale sur chaque ligne
                for (int j=0; j<matrice[i].length; j++) {
                    matrice[i][j] -= min;
                    if (matrice[i][j] == 0) {
                        positions.add(new Integer[] {i,j}); //on note qu'il y a une valeur 0 à cet emplacement
                        positionLigne[i] = true;
                        positionCol[j] = true;
                    }
                }
            }
        //cas dans lequel toutes les colonnes et rangées n'ont pas de valeur 0

        int maxIterations = 1000;
        int iteration = 0;
        while ((containsFalseValue(positionLigne) || containsFalseValue (positionCol)) && iteration < maxIterations){
            iteration ++;
            List<Integer[]> positionsNonNulles = new ArrayList<Integer[]> ();
            for (int i = 0; i<positionLigne.length; i++) {
                for (int j = 0; j<positionCol.length; j++) {
                    if (!positionCol[j] && !positionLigne[i]) {
                        positionsNonNulles.add(new Integer[]{i,j});
                    }
                }
            }

            if (positionsNonNulles.isEmpty()){
                break;
            } 

            //recherche du minimum de ces croisements
            double minNonCouvert = matrice[positionsNonNulles.get(0)[0]][positionsNonNulles.get(0)[1]];
            for (int i=1; i<positionsNonNulles.size(); i++) {
                if (matrice[positionsNonNulles.get(i)[0]][positionsNonNulles.get(i)[1]] < minNonCouvert) {
                    minNonCouvert = matrice[positionsNonNulles.get(i)[0]][positionsNonNulles.get(i)[1]];
                }
            }

            List<Integer[]> nouveauxZeros = new ArrayList<>();

            //déduction du minimum non couverts dans les croisements
            for (int i=1; i<positionsNonNulles.size(); i++) {

                int ligne = positionsNonNulles.get(i)[0];
                int col = positionsNonNulles.get(i)[1];
                matrice[ligne][col] -= minNonCouvert;

                if (matrice[ligne][col] == 0) {
                    nouveauxZeros.add(new Integer[]{ligne, col});
                    positionLigne[ligne] = true;
                    positionCol[col] = true;
                }
            }
            positions.addAll(nouveauxZeros);
        }

         Map<List<Student>,Double> meilleureAffectation = new HashMap<>();
         List<Integer> guestsAAssocier = new ArrayList<>();
        List<Integer> hostAAssocier = new ArrayList<>();
        for (int i=0; i<guests.size();i++) {
            guestsAAssocier.add(i);
            hostAAssocier.add(i);
        }
         //on se débarasse des lignes ou il n'y a qu'un seul appariement possible (une seule valeur à nulle)
        for (int i = 0; i<matrice.length; i++) {
            int compteurdeZeros = 0;
            for (Integer[] position: positions) {
                if (position[0] == i) {
                    compteurdeZeros++;
                }
            }
            if (compteurdeZeros == 1) {
                for (Integer[] position: new ArrayList<>(positions)) {
                    if (position[0] == i && guestsAAssocier.contains(position[1])) {
                        List<Student> appariement = new ArrayList<>();
                        appariement.add(hosts.get(position[0]));
                        appariement.add(guests.get(position[1]));
                        meilleureAffectation.put(new ArrayList<>(appariement), allAffectations.get(appariement));
                        positionCol[position[1]] = false;
                        positionLigne[position[0]] = false;
                        positions.remove(position);
                        guestsAAssocier.remove(position[1]);
                        hostAAssocier.remove(position[0]);
                    }
                }

            }
        }

        //on s'occupe du reste  des 0
        for (int i = 0; i<matrice.length; i++) {
            for (Integer[] position: new ArrayList<>(positions)) {
                if (position[0] == i && positionLigne[i] == true && guestsAAssocier.contains(position[1])) {
                    List<Student> appariement = new ArrayList<>();
                    appariement.add(hosts.get(position[0]));
                    appariement.add(guests.get(position[1]));
                    meilleureAffectation.put(new ArrayList<>(appariement), allAffectations.get(appariement));
                    positionCol[position[1]] = false;
                    positionLigne[position[0]] = false;
                    positions.remove(position);
                    guestsAAssocier.remove(position[1]);
                    hostAAssocier.remove(position[0]);
                }
            }

        }
        for (Integer host: new ArrayList<>(hostAAssocier)){
            int mini = 42;
            for (Integer i=0;i<matrice[0].length; i++) {
                if (matrice[host][i]<mini && guestsAAssocier.contains(i)) {
                    positionCol[i] = false;
                    positionLigne[host] = false;
                    guestsAAssocier.remove(i);
                    hostAAssocier.remove(host);
                    List<Student> appariement = new ArrayList<>();
                    appariement.add(hosts.get(host));
                    appariement.add(guests.get(i));
                    meilleureAffectation.put(new ArrayList<>(appariement), allAffectations.get(appariement));
                }
            }
        }
        return meilleureAffectation;
        
    }

    /**
     * permet de vérifier si un tableau de booléen contient des valeurs à false
     * @param tab tableau de booléen
     * @return true si le tableau contient au moins un false et false sinon
     */
    private static boolean containsFalseValue(boolean[] tab) {
        boolean existFalse = false;
        for (boolean b : tab) {
            if (!b) {
                existFalse = true;
            }
        }
        return existFalse;
    }

    /**
     * remplis la tablea associative du meilleur appariement possible pour l'échange avec les valeurs de l'algorithme hongrois
     */
    public void fillMeilleureAffectation () {
        this.meilleurAppariement = Exchange.meilleureAffectation(this.affectationResults, this.hosts, this.guests);
    }

    /**
     * donne le meilleur guest possible pour l'étudiant choisi
     * @param IDStudent identifiant de l'étudiant dont on veut l'appariemenbt optimal
     * @param index 0 si on recherche un host et 1 si on recherche un guest
     * @return l'étudiant étant le meilleur choix possible pour notre étudiant passé en paramètre
     */
    private Student getBestChoiceOfCouple (int idStudent, int index) {
        double minResult = 42;
        Student student = null;
        if (!this.affectationResults.isEmpty()) {
            for (List<Student> pair : this.affectationResults.keySet()) {
                if (pair.get(1-index).getID() == idStudent && this.affectationResults.get(pair) < minResult) {
                    minResult = this.affectationResults.get(pair);
                    student = pair.get(index);
                }
            }
        }
        
        return student;
    }
    
    /**
     * donne le meilleur guest possible pour l'étudiant choisi
     * @param IDStudent identifiant de l'étudiant dont on veut l'appariement optimal
     * @return host le plus adapté l'étudiant passé en paramètre
     */
    public Student getBestChoiceOfGuest (int idStudent) {
        return getBestChoiceOfCouple(idStudent, 1);
    }

    /**
     * donne le meilleur hote possible pour un étudiant donné
     * @param IDStudent identifiant de l'étudiant dont on veut l'appariement optimal
     * @return gust le plus adapté à notre étudiant passé en paramètre 
     */
    public Student getBestChoiceOfHost (int idStudent) {
        return getBestChoiceOfCouple(idStudent, 0);
    }

    /**
     * donne l'appariement par défaut d'un étudiant calulé avec l'agorithme d'affectation optimal en tant que guest
     * @param idStudent étudiant dont on veut l'appariement par défaut
     * @return hôte par défaut
     */
    public Student getDefaultHost(int idStudent) {
        Student defaultHost = null;
        for (List<Student> pairs: this.meilleurAppariement.keySet()) {
            if (pairs.get(1).getID() == idStudent) {
                defaultHost =  pairs.get(0);
            }
        }
        return defaultHost;
    }

     /**
     * donne l'appariement par défaut d'un étudiant calulé avec l'agorithme d'affectation optimal en tant que hôte
     * @param idStudent étudiant dont on veut l'appariement par défaut
     * @return guest par défaut
     */
    public Student getDefaultGuest(int idStudent) {
        Student defaultGuest= null;
        for (List<Student> pairs: this.meilleurAppariement.keySet()) {
            if (pairs.get(0).getID() == idStudent) {
                defaultGuest = pairs.get(1);
            }
        }
        return defaultGuest;
    }

    /**
     * renvoie les paires impossibles pour un étudiant donné
     * @param idStudent étudiant dont on veut les paires impossibles
     * @return Liste des associations impossibles avec l'étudiant passé en paramètre
     */
    public List<List<Student>> getImpossiblePairs (int idStudent) {
        List<List<Student>> impossiblePairs = new ArrayList<>();
        for (List<Student> pairs: this.affectationResults.keySet()) {
            if (this.affectationResults.get(pairs) >= 42 && !pairs.get(0).equals(pairs.get(1))) {
                impossiblePairs.add(pairs);
            }
        }
        return impossiblePairs;
    }

    /**
     * permet de vérifier que cheque étudiant de l'échange ait des critères valides selon les critères d'un fichier de préconfiguration et dans le cas échéant le supprime de l'échange
     */
    public void autoVerifCriteres () {
        for (Student s: this.hosts) {
            if (!s.verifValidPerson("traitement_automatique.txt")) {
                this.removeFromExchange(s);
            }
        }
    }

}