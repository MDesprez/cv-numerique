package poo;

public enum HistoriqueStatus {REDHIBITOIRE, NULL, BONUS}
