package poo;

import java.io.BufferedInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class HistoryManager {
    
    /**
     * chemin vers les ressources à partir de la position de l'utilisateur (au niveau de la racine du projet)
     */
    public static String src = System.getProperty("user.dir")+File.separator+"dev"+File.separator+"res"+File.separator+"poo"+File.separator; // user.dir donne le répertoire courant de l'arborescence de fichier
    public static String historicFile = "historique.bin";

    public static void writeOnHistoric(Exchange exchange) {
        List<Exchange> exchanges = readTheHistoric(); // on lit tout le fichier
        exchanges.add(exchange); // on ajoute le nouvel échange

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(src + historicFile))) {
            for (Exchange ex : exchanges) {
                oos.writeObject(ex);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * lis l'historique des échanges et renvoie l'ensemble de ces derniers 
     * @return liste de l'ensemble des échanges archivés et désérialisés
     */
    public static List<Exchange> readTheHistoric () {
        List<Exchange> allExchanges = new ArrayList<>();
        try (FileInputStream istream = new FileInputStream(src+historicFile)){
            try (ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(istream))) {
                while (istream.available() > 0) {
                    try {
                        Exchange echange = (Exchange) ois.readObject();
                        allExchanges.add(echange);
                    } catch (EOFException eof) {
                        System.out.println("fin du fichier");
                        return allExchanges;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        
        } catch (IOException e) {
            System.err.println(e);
        }
        return allExchanges;
}
}
