package poo;

public class InvalidStudentException extends Exception {
    public InvalidStudentException () {super();}
    public InvalidStudentException(String m) {super(m);}
}
