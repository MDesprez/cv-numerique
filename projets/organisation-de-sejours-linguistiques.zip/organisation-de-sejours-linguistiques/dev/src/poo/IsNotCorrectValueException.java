package poo;

public class IsNotCorrectValueException extends Exception {
    public IsNotCorrectValueException () {super();}
    public IsNotCorrectValueException (String message) {super (message);}
    
}
