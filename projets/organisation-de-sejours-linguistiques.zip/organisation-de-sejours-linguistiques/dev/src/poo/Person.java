package poo;
import java.time.LocalDate;

public class Person {
    
    private String name; // nom
    private String surname; // prénom
    private String gender; // genre
    private LocalDate birthDate; // date de naissance
    private String homeCountry; // pays d'origine
    private final int ID;

    /**
     * Constructeur de la classe Person
     * @param id identifiant de l'étudiant
     * @param name nom de l'étudiant
     * @param surname prénom de l'étudiant
     * @param genre genre de l'étudiant
     * @param birthDate date de naissance de l'étudiant
     * @param homeCountry pays d'origine de l'étudiant
     */
    public Person (int id, String name, String surname, String genre, LocalDate birthDate, String homeCountry) {
        this.ID = id;
        this.name = name;
        this.surname = surname;
        this.gender = genre;
        this.birthDate = birthDate;
        this.homeCountry = homeCountry;
    }

    //getters
    public int getID() {return this.ID;}
    public String getName() {return this.name;}
    public String getSurname() {return this.surname;}
    public String getGenre() {return this.gender;}
    public LocalDate getBirthDate() {return this.birthDate;}
    public String getHomeCountry() {return this.homeCountry;}

    //setters
    public void setName(String name) {this.name = name;}
    public void setSurname(String surname) {this.surname = surname;}
    public void setGender(String genre) {this.gender = genre;}
    public void setBirthDate(LocalDate birthDate) {this.birthDate = birthDate;}
    public void setHomeCountry(String homeCountry) {this.homeCountry = homeCountry;}

    @Override
    public boolean equals (Object obj) {
        if (this == obj) {return true;}
        if (obj == null) {return false;}
        if (this.getClass() != obj.getClass()) {return false;}

        Person other = (Person) obj;

        if (this.ID != other.ID) {
            return false;
        }
        if (this.name == null) {
            if (other.name != null) {return false;}
        } else if (!this.name.equals(other.name)) {return false;}

        if (this.surname == null) {
            if (other.surname != null) {return false;}
        } else if (!this.surname.equals(other.surname)) {
            return false;
        }
        if (this.gender == null) {
            if (other.gender != null) {return false;}
        } else if (!this.gender.equals(other.gender)) {
            return false;
        }

        if (this.birthDate == null) {
            if (other.birthDate != null) {return false;}
        } else if (!this.birthDate.equals(other.birthDate)) {
            return false;
        }

        if (this.homeCountry == null) {
            if (other.homeCountry != null) {return false;}
        } else if (!this.homeCountry.equals(other.homeCountry)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return this.surname+" "+this.name+"( age :"+this.birthDate+", genre :"+this.gender+", home country : "+this.homeCountry+")";
    }

}