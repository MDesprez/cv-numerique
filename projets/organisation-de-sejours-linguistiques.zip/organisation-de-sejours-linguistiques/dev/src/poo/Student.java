package poo;
import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Student extends Person implements Serializable{
    
    /*
     * Attribut HashMap de la classe Student (un dictionnaire), comprenant des constantes de l'énumération critaries (ayant un nom et un type) et une valeur en String
     */
    private Map<Critaries,String> caracteristics = new HashMap<Critaries,String>();
    
    /**
     * Constructeur de la classe Student
     * @param name
     * @param surname
     * @param genre
     * @param birthDate
     * @param homeCountry
     * @param caracteristics
     */
    public Student(int id, String name, String surname, String genre, LocalDate birthDate, String homeCountry, Map<Critaries,String> caracteristics) {
        //Dans la classe Gestion qui gère les csv, on utilise une fonction qui met directement dans une hashmap les couples clés valeurs des critères en fonction de l'id de l'étudiant 
        super(id,name, surname, genre, birthDate, homeCountry);
        for (Critaries c: caracteristics.keySet()) {
            this.addValueOrNull(c, caracteristics.get(c));
        }
    }

    /*
     * Constructeur de la classe Student prenant en paramètre directement une instance de la classe Person 
     */
    public Student(Person person, Map<Critaries,String> caracteristics) {
        this(person.getID(), person.getName(), person.getSurname(), person.getGenre(), person.getBirthDate(), person.getHomeCountry(), caracteristics);
    }

    
    //getters
    
    public String getGuestAnimalAllergy() {return this.caracteristics.get(Critaries.GUEST_ANIMAL_ALLERGY);}
    public String getHostHasAnimal() {return this.caracteristics.get(Critaries.HOST_HAS_ANIMAL);}
    public String getGuestFood() {return this.caracteristics.get(Critaries.GUEST_FOOD);}
    public String getHostFood() {return this.caracteristics.get(Critaries.HOST_FOOD);}
    public String getHobbies() {return this.caracteristics.get(Critaries.HOBBIES);}
    public String getGender() {return this.caracteristics.get(Critaries.GENDER);}
    public String getPairGender() {return this.caracteristics.get(Critaries.PAIR_GENDER);}
    public String getHistory() {return this.caracteristics.get(Critaries.HISTORY);}

    
    //setters

    public void setGuestAnimalAllergy(String value) {this.caracteristics.put(Critaries.GUEST_ANIMAL_ALLERGY, value);}
    public void setHostHasAnimal(String value) {this.caracteristics.put(Critaries.HOST_HAS_ANIMAL, value);}
    public void setGuestFood(String value) {this.caracteristics.put(Critaries.GUEST_FOOD, value);}
    public void setHostFood(String value) {this.caracteristics.put(Critaries.HOST_FOOD, value);}
    public void setHobbies(String value) {this.caracteristics.put(Critaries.HOBBIES, value);}
    
    @Override
    public void setGender(String value) {
        this.caracteristics.put(Critaries.GENDER, value); //on modifie a valeur dans le dictionnaire (HashMap)
        this.setGender(value); //on modifie aussi la valeur de l'attribut de la classe Person
    }
    public void setPairGender(String value) {this.caracteristics.put(Critaries.PAIR_GENDER, value);}
    public void setHistory(String value) {this.caracteristics.put(Critaries.HISTORY, value);}

    /*
     * Méthode qui ajoute les valeurs des attributs de l'instance de la classe Student si et seulement si ce sont des crotères valides. Sinon ces attributs sont instanciés à null
     */
    private void addValueOrNull (Critaries critary, String value){
        try {
            this.add(critary, value);
        } 
        catch (IsNotCorrectValueException e) {
            System.err.println(e);
            this.caracteristics.put(critary, null);
        }
    }

    /**
     * ajoute si possible la valeur d'un critère à une instande de la classe Student si et seulement si ce critère est valide
     * sinon lève une esception
     * @param critary : attribut de l'instance auquel on veut mettre value comme valeur
     * @param value : valeur qui doit être valide
     * @throws IsNotCorrectValueException : renvoie une erreur si la valeur ne correspond pas à une valeur valide de critary
     */
    private void add (Critaries critary, String value) throws IsNotCorrectValueException {
        if (Critaries.verifCritary(value, Critaries.returnTabCritary (critary))) {
            this.caracteristics.put(critary, value);
        } else {
            throw new IsNotCorrectValueException("Valeur incorrecte mise à null");
        }
    }


    @Override
    /*
     * Méthode equals de la classe Student
     * return true si les objets sont égaux et false sinon
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj ==  null) {
            return false;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Student other = (Student) obj;
        if (caracteristics == null) {
            if (other.caracteristics != null) {
                return false;
            }
        } else if (!caracteristics.equals(other.caracteristics)) {
            return false;
        }
        return true;
    }

    @Override
    /*Méthode d'affichage des instances de la classe Student */
    public String toString () {
        return super.toString() + "\nGUEST_ANIMAL_ALLERGY :"+this.getGuestAnimalAllergy()+"\nHOST_HAS_ANIMAL :"+this.getHostHasAnimal()+"\nGUEST_FOOD: "+this.getGuestFood()+"\nHOST_FOOD :"+this.getHostFood()+"\nHOBBIES :"+this.getHobbies()+"\nGENDER :"+this.getGender()+"\nPAIR_GENDER :"+this.getPairGender()+"\nHISTORY :"+this.getHistory();
    }

    /*
     * Vérifie le nombre de mois de différences entre deux instances de la classe Student
     * return (int): nombre ne mois d'écarts
     */

    /**
     * Retourne le nombre de mois entre 2 dates
     * @param otherStudent
     * @return
     */
    public int getMonthDifferences(Student otherStudent){
        return (int) ChronoUnit.MONTHS.between(this.getBirthDate(), otherStudent.getBirthDate());
    }

    /** Méthode permettant de vérifier la validité d'un étudiant (il faut que ses valeurs sensées être booléennes le soient vraiment et une cohérence au niveau de la possession d'un animal et une allergie)
     * @return true si l'étudiant est valid et false sinon
     */
    public boolean isValidPerson() {
        return this.getGuestAnimalAllergy().equals(this.getHostHasAnimal()) && this.getGuestAnimalAllergy() != null && this.getHostHasAnimal() != null;
    }

    /**
     * vérifie la validité des contraintes de l'étudiant selon un fichier de préconfiguration
     * @param file nom du fichier de préconfiguration contenant l'ensemble des valeurs possibles pour chaque contrainte de l'étudiant (voir les contrantes de l'énumération Critaries)
     * @return true si les contraintes sont valides et false sinon
     */
    public boolean verifValidPerson (String file) {
        return Critaries.verifCritary(this.getHostHasAnimal(), Critaries.returnTabCritaryBasedOnFileInfos(Critaries.HOST_HAS_ANIMAL, file)) 
        && Critaries.verifCritary(this.getGuestAnimalAllergy(), Critaries.returnTabCritaryBasedOnFileInfos(Critaries.GUEST_ANIMAL_ALLERGY, file)) 
        && Critaries.verifCritary(this.getHostFood(), Critaries.returnTabCritaryBasedOnFileInfos(Critaries.HOST_FOOD, file)) 
        && Critaries.verifCritary(this.getGuestFood(), Critaries.returnTabCritaryBasedOnFileInfos(Critaries.GUEST_FOOD, file))
        && Critaries.verifCritary(this.getGender(), Critaries.returnTabCritaryBasedOnFileInfos(Critaries.GENDER, file)) 
        && Critaries.verifCritary(this.getPairGender(), Critaries.returnTabCritaryBasedOnFileInfos(Critaries.PAIR_GENDER, file));
    }
    
}
