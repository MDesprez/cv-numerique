package poo;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class CritariesTest {
    
}
