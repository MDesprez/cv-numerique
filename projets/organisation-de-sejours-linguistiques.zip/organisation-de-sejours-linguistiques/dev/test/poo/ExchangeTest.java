package poo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ExchangeTest {
    public Person p1,p2,p3,p4,p5,p6, p7,p8,p9;
    public Student s1,s2,s3,s4,s5,s6,s7,s8,s9,s10;
    public Exchange groupe1;

    @BeforeEach
    public void initialization() {
        p1 = new Person(1,"Tison", "Chloé", "female", LocalDate.of(2006, 9, 10), "FRANCE");
        p2 = new Person(2,"Ung", "Meï Li", "female", LocalDate.of(2006, 11, 17), "FRANCE");
        p3 = new Person(3,"Desprez", "Mathéo", "male", LocalDate.of(2004, 6, 22), "FRANCE");
        
        p4 = new Person(4,"Tison", "Marie", "female", LocalDate.of(2006, 9, 10), "GERMANY");
        p5 = new Person(5,"Ung", "Meï Li", "female", LocalDate.of(2006, 12, 14), "GERMANY");
        p6 = new Person(6,"Desprez", "Mathéo", "male", LocalDate.of(2004, 6, 22), "GERMANY");

        Map<Critaries,String> m1 = new HashMap<Critaries,String>();
        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "yes");
        m1.put(Critaries.GUEST_FOOD, "no");
        m1.put(Critaries.HOST_FOOD, "");
        m1.put(Critaries.HOBBIES, "");
        m1.put(Critaries.GENDER, "female");
        m1.put(Critaries.PAIR_GENDER, "");
        m1.put(Critaries.HISTORY, "");

        s1 = new Student(p1, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "yes");
        m1.put(Critaries.HOST_HAS_ANIMAL, "no");
        m1.put(Critaries.GUEST_FOOD, "");

        s2 = new Student(p2, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "no");
        m1.put(Critaries.GENDER, "male");
        
        s3 = new Student(p3, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "yes");
        m1.put(Critaries.GENDER, "female");
        
        s4 = new Student(p1, m1);
        s5 = new Student(p2, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.GENDER, "male");
        
        s6 = new Student(p3, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "yes");
        m1.put(Critaries.HOST_HAS_ANIMAL, "yes");
        m1.put(Critaries.GUEST_FOOD, "");
        m1.put(Critaries.HOST_FOOD, "");
        m1.put(Critaries.HOBBIES, "sport,dance,drawing");
        m1.put(Critaries.GENDER, "female");
        m1.put(Critaries.PAIR_GENDER, "female");
        m1.put(Critaries.HISTORY, "");
        
        s7 = new Student(p4, m1);

        m1.put(Critaries.PAIR_GENDER, "");

        s8 = new Student(p5, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "no");
        m1.put(Critaries.HOBBIES, "sport");
        m1.put(Critaries.PAIR_GENDER, "female");

        s9 = new Student(p4, m1);

        m1.put(Critaries.GENDER, "male");
        m1.put(Critaries.HOBBIES, "knitting");
        m1.put(Critaries.PAIR_GENDER, "male");

        s10 = new Student(p6, m1);

        groupe1 = new Exchange(2008,"FRANCE","GERMANY");
 
    }

    @Test
    /*
     * vérifie si les étudiants sont bien triés avant d'être ajoutés dans les tableaux guests et hosts
     */
    public void testAddToGuests() {
        assertFalse(groupe1.addToHostAndGuest(s1));
        assertFalse(groupe1.addToHostAndGuest(s2));
        assertFalse(groupe1.addToHostAndGuest(s4));
        assertFalse(groupe1.addToHostAndGuest(s5));

        assertTrue(groupe1.addToHostAndGuest(s3));
        assertTrue(groupe1.addToHostAndGuest(s6));
        assertTrue(groupe1.addToHostAndGuest(s7));
    }

    @Test
    /*
     * vérifie si seul les étudiants valides sont dans les tableaux host et guests
     */
    public void testAttributs() {
        groupe1.addToHostAndGuest(s1);
        groupe1.addToHostAndGuest(s2);
        groupe1.addToHostAndGuest(s3);
        groupe1.addToHostAndGuest(s6);
        groupe1.addToHostAndGuest(s7);
        ArrayList<Student> groupTest= new ArrayList<Student>();
        groupTest.add(s3);
        groupTest.add(s6);
        groupTest.add(s7);

        assertEquals(groupe1.hosts, groupTest);

        groupe1.addToHostAndGuest(s5);
        assertEquals(groupe1.guests, groupTest);
    }

    @Test
    /*
     * Test de la fonction affinityScore1
     */
    public void testaAffinityScore1() {
        assertEquals(-4, Exchange.affinityScore1(s7,s8));
        assertEquals(-2, Exchange.affinityScore1(s7,s9));
        assertEquals(4, Exchange.affinityScore1(s7,s10));
        assertEquals(-2, Exchange.affinityScore1(s8,s9));
        assertEquals(2, Exchange.affinityScore1(s8,s10));
        assertEquals(4, Exchange.affinityScore1(s9,s10));
    }

    @Test
    public void testMinimumCostChoosen() {
        // Hosts et guests
        List<Student> hosts = List.of(s7, s9);
        List<Student> guests = List.of(s1, s2);

        // Map des appariements avec coûts différents
        Map<List<Student>, Double> allAffectations = new HashMap<>();
        allAffectations.put(List.of(s7, s1), 5.0);
        allAffectations.put(List.of(s7, s2), 1.0);  // Coût minimal pour s7
        allAffectations.put(List.of(s9, s1), 2.0);  // Coût minimal pour s9
        allAffectations.put(List.of(s9, s2), 10.0);

        // Appel de la méthode
        Map<List<Student>, Double> result = Exchange.meilleureAffectation(allAffectations, hosts, guests);

        // On vérifie que la taille du résultat est bien 2 (un appariement par host)
        assertEquals(2, result.size());

        // Vérifie que pour s7, c’est bien l’appariement à s2 (coût 1.0) qui est choisi
        assertTrue(result.containsKey(List.of(s7, s2)));
        assertEquals(1.0, allAffectations.get(List.of(s7, s2)));

        // Vérifie que pour s9, c’est bien l’appariement à s1 (coût 2.0) qui est choisi
        assertTrue(result.containsKey(List.of(s9, s1)));
        assertEquals(2.0, allAffectations.get(List.of(s9, s1)));
}

}
