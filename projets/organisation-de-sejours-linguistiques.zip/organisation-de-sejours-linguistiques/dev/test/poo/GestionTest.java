package poo;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

public class GestionTest {

    /**
     * test de la fonction getInfosFromCsv avec le fichier students_infos.csv
     */
    @Test
    public void testgetInfosFromCSV() {
        assertEquals("1", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 0));
        assertEquals("Khargol", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 1));
        assertEquals("Maalik", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 2));
        assertEquals("GERMANY", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 3));
        assertEquals("2008-01-22", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 4));
        assertEquals("no", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 5));
        assertEquals("yes", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 6));
        assertEquals("nonuts", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 7));
        assertEquals("nonuts,vegetarian", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 8));
        assertEquals("culture,sports,reading", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 9));
        assertEquals("female", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 10));
        assertEquals("female", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 1, 11));

        assertEquals("2", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 0));
        assertEquals("Adonia", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 1));
        assertEquals("Digby", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 2));
        assertEquals("FRANCE", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 3));
        assertEquals("2007-02-15", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 4));
        assertEquals("yes", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 5));
        assertEquals("no", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 6));
        //test avec des valeurs nulles
        assertEquals("", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 7));
        assertEquals("", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 8));
        assertEquals("", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 9));
        assertEquals("other", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 10));
        assertEquals("female", CSVManager.getInfosFromCsv(CSVManager.src+"test.csv", 2, 11));
    }

    /**
     * test de la fonction getIDsFromCsv avec le fichier students_infos.csv
     */
    @Test
    public void getIDsFromCsv() {
        ArrayList<Integer> testListIds = new ArrayList<Integer>();
        testListIds.add(1);
        testListIds.add(2);
        testListIds.add(3);
        testListIds.add(4);
        assertEquals(testListIds, CSVManager.getIDsFromCsv(CSVManager.src+"test.csv"));
    }

    /**
     * test de la fonction qui crée la Map des critères en fonction de l'id de l'etudiant, avec le fichier students_infos.csv
     */
    @Test
    public void testCsvToHashMapForCritaries () {
        Map<Critaries,String> mapStudentTest1 = new HashMap<Critaries,String>();
        mapStudentTest1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        mapStudentTest1.put(Critaries.HOST_HAS_ANIMAL, "yes");
        mapStudentTest1.put(Critaries.GUEST_FOOD, "nonuts");
        mapStudentTest1.put(Critaries.HOST_FOOD, "nonuts,vegetarian");
        mapStudentTest1.put(Critaries.HOBBIES, "culture,sports,reading");
        mapStudentTest1.put(Critaries.GENDER, "female");
        mapStudentTest1.put(Critaries.PAIR_GENDER, "female");
        mapStudentTest1.put(Critaries.HISTORY, "");
        assertEquals(mapStudentTest1, CSVManager.csvToHashMapForCritaries(CSVManager.src+"test.csv", 1));
        
        //test avec des valeurs nulles
        Map<Critaries,String> mapStudentTest2 = new HashMap<Critaries,String>();
        mapStudentTest2.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        mapStudentTest2.put(Critaries.HOST_HAS_ANIMAL, "yes");
        mapStudentTest2.put(Critaries.GUEST_FOOD, "vegetarian");
        mapStudentTest2.put(Critaries.HOST_FOOD, "vegetarian");
        mapStudentTest2.put(Critaries.HOBBIES, "science,reading");
        mapStudentTest2.put(Critaries.GENDER, "female");
        //tst des valeurs nulles 
        mapStudentTest2.put(Critaries.PAIR_GENDER,"");
        mapStudentTest2.put(Critaries.HISTORY, "other");
        assertEquals(mapStudentTest2, CSVManager.csvToHashMapForCritaries(CSVManager.src+"test.csv", 3));

    }
    
    @Test
    public void testCreateStudentFromCSV () {

        Map<Critaries,String> m1 = new HashMap<Critaries,String>();
        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "yes");
        m1.put(Critaries.GUEST_FOOD, "nonuts");
        m1.put(Critaries.HOST_FOOD, "nonuts,vegetarian");
        m1.put(Critaries.HOBBIES, "culture,sports,reading");
        m1.put(Critaries.GENDER, "female");
        m1.put(Critaries.PAIR_GENDER, "female");
        m1.put(Critaries.HISTORY, "");
        Student s1 = new Student(1,"Maalik","Khargol","female",LocalDate.of(2008, 01, 22),"GERMANY",m1);
        assertTrue(s1.equals(CSVManager.createStudentFromCSV(CSVManager.src+"test.csv", 1)));
    }

}
