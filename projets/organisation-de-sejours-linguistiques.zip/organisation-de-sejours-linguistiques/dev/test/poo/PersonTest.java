package poo;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class PersonTest {

    public Person p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14;
    public Student s1,s2,s3;

    @BeforeEach
    public void initialization() {
        p1 = new Person(1,"Tison", "Chloé", "female", LocalDate.of(2006, 9, 10), "France");
        p2 = new Person(2,"Ung", "Meï Li", "female", LocalDate.of(2006, 11, 17), "Chine");
        p3 = new Person(3,"Desprez", "Mathéo", "male", LocalDate.of(2004, 6, 22), "Lune");
        
        p4 = new Person(4,"Tison", "Marie", "female", LocalDate.of(2006, 9, 10), "France");
        p5 = new Person(5,"Ung", "Meï Li", "female", LocalDate.of(2006, 12, 14), "Chine");
        p6 = new Person(6,"Desprez", "Mathéo", "male", LocalDate.of(2004, 6, 22), "Mars");

        Map<Critaries,String> m1 = new HashMap<Critaries,String>();
        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "no");
        m1.put(Critaries.GUEST_FOOD, "no");
        m1.put(Critaries.HOST_FOOD, "");
        m1.put(Critaries.HOBBIES, "");
        m1.put(Critaries.GENDER, "female");
        m1.put(Critaries.PAIR_GENDER, "");
        m1.put(Critaries.HISTORY, "");

        s1 = new Student(p1, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "");
        m1.put(Critaries.HOST_HAS_ANIMAL, "");
        m1.put(Critaries.GUEST_FOOD, "");
        m1.put(Critaries.HOST_FOOD, "");
        m1.put(Critaries.HOBBIES, "");
        m1.put(Critaries.PAIR_GENDER, "");
        m1.put(Critaries.HISTORY, "");

        s2 = new Student(p2, m1);

        m1.put(Critaries.GENDER, "male");
        s3 = new Student(p3, m1);

        p7 = p1;
        p8 = p2;
        p9 = p3;
        
        p10 = new Person(7,"Tison", "Marie", "female", LocalDate.of(2006, 9, 10), "France");
        p11 = new Person(8,"Ung", "Meï Li", "female", LocalDate.of(2006, 12, 14), "Chine");
        p12 = new Person(9,"Desprez", "Mathéo", "male", LocalDate.of(2004, 6, 22), "Mars");

        p13 = new Person(10,"", "Mathéo", "male", LocalDate.of(2004, 6, 22), "Mars");
        p14 = new Person(11,"", "Mathéo", "male", LocalDate.of(2004, 6, 22), "Mars");


    }

    @Test
    public void testEquals_differentPerson() {
        assertFalse(p1.equals(p2));
        assertFalse(p1.equals(p3));
        assertFalse(p2.equals(p3));

        assertFalse(p1.equals(p4));
        assertFalse(p1.equals(p5));
        assertFalse(p2.equals(p6));
        
        assertFalse(p1.equals(s1));
        assertFalse(p2.equals(s2));
        assertFalse(p3.equals(s3));

        assertFalse(p13.equals(p14));

        assertFalse(p1.equals(p10));
        assertFalse(p1.equals(p11));
        assertFalse(p1.equals(p12));

    }

    @Test
    public void testEquals_samePerson() {
        assertTrue(p1.equals(p7));
        assertTrue(p2.equals(p8));
        assertTrue(p3.equals(p9));
    }
    
}
