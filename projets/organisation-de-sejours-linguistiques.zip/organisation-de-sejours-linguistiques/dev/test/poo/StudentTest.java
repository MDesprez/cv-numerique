package poo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class StudentTest {
    
    public Person Meili, Matheo, Chloe, Maxime;
    public Student p1, p2, p3, p4, MeiliV2;

    @BeforeEach
    void initialization(){
        Meili = new Person(1,"Ung", "Meï Li", "female", LocalDate.of(2006, 11, 17), "Chine");
        Map<Critaries,String> m1 = new HashMap<Critaries,String>();
        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "no");
        m1.put(Critaries.GUEST_FOOD, "no");
        m1.put(Critaries.HOST_FOOD, "vegetarian");
        m1.put(Critaries.HOBBIES, "draw");
        m1.put(Critaries.GENDER, "female");
        m1.put(Critaries.PAIR_GENDER, "other");
        m1.put(Critaries.HISTORY, "same");
        p1 = new Student(Meili, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "yes");
        MeiliV2 = new Student(2,"Ung", "MeiLi", "female", LocalDate.of(2006, 11, 17), "Chine", m1);
        
        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "no");
        m1.put(Critaries.GUEST_FOOD, "");
        m1.put(Critaries.HOST_FOOD, "nonuts");
        m1.put(Critaries.HOBBIES, "");
        m1.put(Critaries.GENDER, "male");
        m1.put(Critaries.PAIR_GENDER, "other");
        m1.put(Critaries.HISTORY, "other");
        Matheo = new Person(3,"Desprez", "Mathéo", "male", LocalDate.of(2004, 6, 22), "Lune");
        p2 = new Student(Matheo, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "");
        m1.put(Critaries.HOST_HAS_ANIMAL, "");
        m1.put(Critaries.GUEST_FOOD, "");
        m1.put(Critaries.HOST_FOOD, "");
        m1.put(Critaries.HOBBIES, "");
        m1.put(Critaries.GENDER, "female");
        m1.put(Critaries.PAIR_GENDER, "");
        m1.put(Critaries.HISTORY, "");
        Chloe = new Person(4,"Tison", "Chloe", "female", LocalDate.of(2004, 9, 10), "Chez Enzo");
        p3 = new Student(Chloe, m1);

        m1.put(Critaries.GUEST_ANIMAL_ALLERGY, "no");
        m1.put(Critaries.HOST_HAS_ANIMAL, "no");
        m1.put(Critaries.GUEST_FOOD, "");
        m1.put(Critaries.HOST_FOOD, "nonuts");
        m1.put(Critaries.HOBBIES, "");
        m1.put(Critaries.GENDER, "male");
        m1.put(Critaries.PAIR_GENDER, "other");
        m1.put(Critaries.HISTORY, "other");
        Maxime = new Person(5,"Desprez", "Mathéo", "male", LocalDate.of(2004, 6, 22), "Lune");
        p4 = new Student(Matheo, m1);
    }

    @Test
    public void testStudent(){

        /**Test du constructeur Student avec comme spécificité : Person person*/
        assertEquals(1, p1.getID());
        assertEquals("Ung", p1.getName());
        assertEquals("Meï Li", p1.getSurname());
        assertEquals("female", p1.getGender());
        assertEquals(LocalDate.of(2006, 11, 17), p1.getBirthDate());
        assertEquals("Chine", p1.getHomeCountry());
        assertEquals("no", p1.getGuestAnimalAllergy());
        assertEquals("no", p1.getHostHasAnimal());
        assertEquals("draw", p1.getHobbies());
        assertEquals("other", p1.getPairGender());
        assertEquals("same", p1.getHistory());

        /**Test du constructeur Student uniquement a partir de Student */
        assertEquals(2, MeiliV2.getID());
        assertEquals("Ung", MeiliV2.getName());
        assertEquals("MeiLi", MeiliV2.getSurname());
        assertEquals("female", MeiliV2.getGender());
        assertEquals(LocalDate.of(2006, 11, 17), MeiliV2.getBirthDate());
        assertEquals("Chine", MeiliV2.getHomeCountry());
        assertEquals("yes", MeiliV2.getGuestAnimalAllergy());
        assertEquals("no", MeiliV2.getHostHasAnimal());
        assertEquals("vegetarian", MeiliV2.getHostFood());
        assertEquals("draw", MeiliV2.getHobbies());
        assertEquals("other", MeiliV2.getPairGender());
        assertEquals("same", MeiliV2.getHistory());
    }

    @Test
    public void testGetMonthDifferences_Equals(){
        assertEquals(LocalDate.of(2004, 6, 22), Matheo.getBirthDate());
    }

    @Test
    public void testGetMonthDifferences_Positif(){
        assertEquals(28, p2.getMonthDifferences(p1));
    }

    @Test
    public void testGetMonthDifferences_Negatif(){
        assertEquals(-28, p1.getMonthDifferences(p2));
    }

    @Test
    public void testEquals(){
        assertEquals(true, p2.equals(p4));
        assertEquals(false, p1.equals(p2));
        assertEquals(false, p1.equals(p3));
    }

    @Test
    public void testSetters() {

        p1.setHobbies("Reading");
        p1.setPairGender("female");
        p1.setHistory("other");

        assertEquals("Reading", p1.getHobbies());
        assertEquals("female", p1.getPairGender());
        assertEquals("other", p1.getHistory());
        
    }
}
