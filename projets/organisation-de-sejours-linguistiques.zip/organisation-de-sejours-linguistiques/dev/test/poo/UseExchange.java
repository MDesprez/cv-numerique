package poo;

import java.util.List;

public class UseExchange {
    
    /**
     * programme simulant le remplissage automatique d'un échange étudiant
     * @param args
     */
    public static void main(String[] args) {
        Exchange e1 = new Exchange(2021, "FRANCE", "GERMANY");
        List<Integer> ids = CSVManager.getIDsFromCsv(CSVManager.src+CSVManager.studentInfoFile);
        for (int id: ids) {
            Student s = CSVManager.createStudentFromCSV(CSVManager.src+CSVManager.studentInfoFile, id);
            e1.addToHostAndGuest(s);
        }
        e1.fillAffectationResults();
        e1.fillMeilleureAffectation();
        System.out.println(e1.meilleurAppariement);
        CSVManager.writeAffectationResultOnCSV(CSVManager.src+CSVManager.affectationWritingFile, e1.affectationResults);
    }
}
