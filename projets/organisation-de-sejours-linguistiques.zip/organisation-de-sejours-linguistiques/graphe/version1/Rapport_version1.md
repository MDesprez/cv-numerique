---
title: SAE S2.02 -- Rapport graphes
subtitle: Équipe C1
author: Chloé Tison, Mathéo Desprez, Mei-li Ung
date: 2025
---

# Version 1

## Choix pour la modélisation

| NUMBER | NAME | FORENAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE |
| ------ | ---- | -------- | ------- | ------ | ----------- | ---------- |
| H1 | Vigneron | Loïse | knitting, reading, video-games | female | | 15/05/2006 |
| V1 | Tison | Chloé | music, reading, video-games | female | | 31/10/2006 |
| H2 | Mangin | Maxence | knitting, video-games | male | male | 05/01/2005 |
| V2 | Ung | Mei-Li | programming, drawing | female | female | 17/11/2006 |
| H3 | Viloda-Rivière | Manon | reading, sport | female | female | 29/04/2004 |
| V3 | Vigneron | Loïse | knitting, reading, video-games | female | | 15/05/2006 |
| H4 | Ung | Mei-Li | programming, drawing | female | female | 17/11/2006 |
| V4 | Tison | Chloé | music, reading, video-games | female | female | 31/10/2006 |
| H5 | Mangin | Maxence | knitting, video-games | male | male | 05/12/2005 |
| V5 | Desprez | Mathéo | video-games | male |  | 22/01/2004 |

### Forte affinité

| NUMBER | NAME | FORENAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE |
| ------ | ---- | -------- | ------- | ------ | ----------- | ---------- |
| H1 | Vigneron | Loïse | knitting, reading, video-games | female | | 15/05/2006 |
| V1 | Tison | Chloé | music, reading, video-games | female | | 31/10/2006 |

Cette paire **(H1,V1)** présente une forte affinité. En effet, ils ont :

- un bonus d'affinité sur l'âge, car ils ont moins d'un an d'écart
- deux passe temps en commun
- leurs deux préférences de genres satisfaites.

### Faible affinité

| NUMBER | NAME | FORENAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE |
| ------ | ---- | -------- | ------- | ------ | ----------- | ---------- |
| H2 | Mangin | Maxence | knitting, video-games | male | male | 05/01/2005 |
| V2 | Ung | Mei-Li | programming, drawing | female | female | 17/11/2006 |

Cette paire **(H2,V2)** présente une faible affinité car :

- ils n'ont pas de bonus d'affinité vis-à-vis de l'âge (ils ont plus d'un an et demi d'écart)
- aucun hobbies en commun
- leurs préférences de genre ne sont pas satisfaites
En somme, ils n'ont rien en commun.

### Arbitrage entre les critères d'affinité

| NUMBER | NAME | FORENAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE |
| ------ | ---- | -------- | ------- | ------ | ----------- | ---------- |
| H3 | Viloda-Rivière | Manon | reading, sport | female | female | 29/04/2004 |
| V3 | Vigneron | Loïse | knitting, reading, video-games | female | | 15/05/2006 |
| H4 | Ung | Mei-Li | programming, drawing | female | female | 17/11/2006 |
| V4 | Tison | Chloé | music, reading, video-games | female | female | 31/10/2006 |
| H5 | Mangin | Maxence | knitting, video-games | male | male | 05/12/2005 |
| V5 | Desprez | Mathéo | video-games | male |  | 22/01/2004 |

La paire **(H3,V3)** présente une affinité moyenne car :

- Il n'y a pas de bonus vis-à-vis de la différence d'âge, supérieure à un an et demi.
- ils ont un hobbie en commun
- leur préférence de genre sont tous les deux satisfaits

La paire **(H4,V4)** présente une affinité moyenne car :

- elle possède le bonus lié à la différence d'âge
- les deux préférences de genre sont satisfaites
- Il n'y a aucune affinité liée aux hobbies

La paire **(H5,V5)** présente une affinité moyenne car :

- il n'y a pas de bonus de différence d'âge
- il y a un hobbie en commun
- les préférences de genres qui sont respectée

## Exemple complet

| LETTER | NAME | FORENAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE |
| ------ | ---- | -------- | ------- | ------ | ----------- | ---------- |
| A | Hinata | Shoyo | sport, video-games | male | female/male | 21/06/2005 |
| B | Kageyama | Tobio | sport, reading | male | male | 22/12/2005 |
| C | Tsukishima | Kei | reading, music | male | female | 27/09/2005 |
| D | Tadashi | Yamaguchi | knitting, drawing | male | female/male | 10/11/2005 |

| LETTER | NAME | FORENAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE |
| ------ | ---- | -------- | ------- | ------ | ----------- | ---------- |
| W | Wakatoshi | Ushijima | sport, reading | male | female/male | 22/12/2004 |
| X | Satori | Tendou | sport, video-games | male | male | 21/06/2004 |
| Y | Yachi | Hitoka | knitting, drawing | female | female/male | 10/11/2006 |
| Z | Kiyoko | Shimizu | music, reading | female | female/male | 27/09/2004 |

D'après nos deux tableaux, on peut déterminer que **D et Y** sont compatible entre eux.
- En effet D a comme hobbies le crochet et le dessin, et est un homme qui préfère être avec les hommes et les femmes
- Y a comme hobbies le crochet et le dessin et est une femme qui préfère les hommes et les femmes
- Ils ont également 1 an d'écart.

On peut donc dire qu'ils sont compatibles.


D'après nos deux tableaux, on peut déterminer que **A et X** sont compatible entre eux. 

- En effet A a comme hobbies le sport et les jeux-vidéos et est un homme qui préfère être avec les hommes et les femmes 
- X a comme hobbies le sport et les jeux-vidéos et est un homme qui préfère les hommes
- Ils ont également 1 an d'écart.

On peut donc dire qu'ils sont compatibles.


D'après nos deux tableaux, on peut déterminer que **B et W** sont compatible entre eux. 

- En effet B a comme hobbies le sport et lire et est un homme qui préfère être avec les hommes
- W a comme hobbies le sport et lire et est un homme qui préfère les hommes et les femmes
- Ils ont également 1 an d'écart.

On peut donc dire qu'ils sont compatibles.


D'après nos deux tableaux, on peut déterminer que **C et Z** sont compatible entre eux.

- En effet C a comme hobbies lire et la musique et est un homme qui préfère être avec les femmes
- Z a comme hobbies lire et la musique et est une femme qui préfère les hommes et les femmes
- Ils ont également 1 an d'écart.

On peut donc dire qu'ils sont compatibles.

## Score d'affinité

```
double score_affinité_1(hôte, visiteur) 
  
  affinité = 0 //Création de la valeur qui sera retournée en fin de fonction pour représenter l'affinité entre chaque couple hôte/visiteur.

  -- 1er test -- Age
    Si la date de naissance entre l'hôte et le visiteur est supérieure à 18 mois
      Alors retrait de points d'affinité correspondant au bonus de différence d'âge.
      Valeur du bonus à "affinité" de -1

  -- 2ème test -- Genre
    Si Les genres demandés par le visiteur ne correspond pas au genre de l'hôte
      Alors ajout de malus correspondant à la non-validation des genres
      Valeur du malus à "affinité" de +2

    Si les genres demandés par l'hôte ne correspondent pas au genre du visiteur
      Alors ajout de malus correspondant à la non-validation des genres
      Valeur du malus à "affinité" de +2

  -- 3ème test -- Hobbies
    Rangement de chaque hobbies dans 2 tableaux différents
    hobbiesCommun = 0 //création de la variable nécessaire pour savoir le nombre total d'hobbies en commun
    Un tableau hôte va être parcouru pour comparer avec un tableau visiteur
    Si un hobbie hôte est similaire à un hobbie visiteur
      Alors hobbiesCommun++
    Puis réduire le score de N hobbies en commun au score d'affinité 
    Donc affinité = affinité - hobbiesCommun

  Enfin, retourner le score d'affinité
```

## Retour sur l'exemple

_*matrice d’adjacence du graphe biparti complet utilisant la fonction **score_affinité_1** :*_
$$
\begin{array} {c|cccc}
    & A & B & C & D \\
\hline
    W & -2 & -3 & 0 & -1 \\
    X & -3 & -1 & 1 & -1 \\
    Y & -1 & 1 & -1 & -3 \\
    Z & -1 & 0 & -3 & -1 \\
\end{array}
$$


En utilisant la fonction de calcul calcul-affectation.jar et la matrice d'adjacence nouvellement créée, on obtient le résultat ci-contre:

![Calcul de l'appariement de poids minimal du graphe](./appariement_poids_minimal.png)

On constate alors qu'on retrouve bel est bien l'appariement donné au-dessus.

# Version 2

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | HOST_HAS_ANIMAL | HOST_FOOD |
| ---- | ------- | ------ | ----------- | ---------- | --------------- | --------- |
| A1 | sport, video-games | male | female/male | 21/06/2005 | yes |  |
| A2 | sport, reading | female | male | 22/12/2005 | no | nonuts |
| B1 | reading, music | male | female | 27/09/2005 | no | vegetarian |
| B2 | knitting, drawing | female | female/male | 10/11/2005 | no | nonuts,vegetarian |
| C1 | music, video-games | female | female | 31/12/2005 | no | nonuts |
| C2 | sport | female | male/female | 01/09/2005 | yes |  |
| D1 | reading, video-games | male | female | 15/10/2005 | yes | vegetarian |
| D2 | knitting, drawing | female | female/male | 08/06/2005 | yes |  |

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | GUEST_ANIMAL_ALLERGY | GUEST_FOOD_CONSTRAINT |
| ---- | ------- | ------ | ----------- | ---------- | -------------------- | --------------------- |
| W1 | music, video-games | female | female | 31/12/2006 | no | nonuts |
| W2 | sport, music | female | male | 08/06/2003 | no | nonuts |
| X1 | sport, video-games | female | female/male | 21/06/2006 | yes |  |
| X2 | knitting | male | male | 22/12/2003 | yes | vegetarian |
| Y1 | reading, video-games | female | male | 15/10/2006 | yes |  |
| Y2 | sport, reading | male | male | 10/11/2003 | yes |  |
| Z1 | reading, music | female | male | 27/09/2006 | yes | nonuts, vegetarian |
| Z2 | music, drawing | female | male/female | 01/09/2003 | no | nonuts,vegetarian |


## Exemple avec appariement total

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | HOST_HAS_ANIMAL | HOST_FOOD |
| ---- | ------- | ------ | ----------- | ---------- | --------------- | --------- |
| A1 | sport, video-games | male | female/male | 21/06/2005 | yes |  |
| B1 | reading, music | male | female | 27/09/2005 | no | vegetarian |
| C1 | music, video-games | female | female | 31/12/2005 | no | nonuts |
| D1 | reading, video-games | male | female | 15/10/2005 | yes | vegetarian |

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | GUEST_ANIMAL_ALLERGY | GUEST_FOOD_CONSTRAINT |
| ---- | ------- | ------ | ----------- | ---------- | -------------------- | --------------------- |
| W1 | music, video-games | female | female | 31/12/2006 | no | nonuts |
| X1 | sport, video-games | female | female/male | 21/06/2006 | yes |  |
| Y1 | reading, video-games | female | male | 15/10/2006 | yes |  |
| Z1 | reading, music | female | male | 27/09/2006 | yes | nonuts, vegetarian |

- ***A1 et X1 :***

D'après nos deux tableaux, on peut déterminer que **A1 et X1** sont les plus compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet A1 a comme hobbies les jeux-vidéos et le sport, et est un homme qui préfère être avec les hommes et les femmes
- X1 a comme hobbies les jeux-vidéos et la sport, et est une femme qui préfère les hommes et les femmes
- Ils ont également 1 an d'écart
- A1 détient un ou des animaux et X1 a une allergie aux animaux
- Aucunes des deux personnes detient un régime particulier.

On peut donc dire qu'ils sont les plus compatibles.

- ***B1 et Z1 :***

D'après nos deux tableaux, on peut déterminer que **B1 et Z1** sont les plus compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet B1 a comme hobbies lire et la musique, et est un homme qui préfère être avec les femmes
- Z1 a comme hobbies lire et la musique, et est une femme qui préfère les hommes
- Ils ont également 1 an d'écart
- B1 ne détient aucun animaux et Z1 a une allegie aux animaux
- B1 détient de la nourriture végétarienne et Z1 ne mange pas de la nourriture a base de noix et végétarienne.

On peut donc dire qu'ils sont les plus compatibles.

- ***C1 et W1 :***

D'après nos deux tableaux, on peut déterminer que **C1 et W1** sont les plus compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet C1 a comme hobbies les jeux-vidéos et la musique, et est une femme qui préfère être avec les femmes
- W1 a comme hobbies les jeux-vidéos et la musique, et est une femme qui préfère les femmes
- Ils ont également 1 an d'écart
- C1 ne détient aucun animaux et W1 n'a aucune allergie aux animaux
- C1 détient de la nourriture à base de noix et W1 ne mange pas de la nourriture à base de noix.

On peut donc dire qu'ils sont les plus compatibles.

- ***D1 et Y1 :***

D'après nos deux tableaux, on peut déterminer que **D1 et Y1** sont les plus compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet D1 a comme hobbies les jeux-vidéos et lire, et est un homme qui préfère être avec les femmes
- Y1 a comme hobbies les jeux-vidéos et lire, et est une femme qui préfère les hommes
- Ils ont également 1 an d'écart
- D1 détient un ou des animaux et Y1 a une allergie aux animaux
- D1 détient de la nourriture végétarienne et Y1 ne détient aucun régime particulier.

On peut donc dire qu'ils sont les plus compatibles.


## Exemple sans appariement total

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | HOST_HAS_ANIMAL | HOST_FOOD |
| ---- | ------- | ------ | ----------- | ---------- | --------------- | --------- |
| A2 | sport, reading | female | male | 22/12/2005 | no | nonuts |
| B2 | knitting, drawing | female | female/male | 10/11/2005 | no | nonuts,vegetarian |
| C2 | sport | female | male/female | 01/09/2005 | yes |  |
| D2 | knitting, drawing | female | female/male | 08/06/2005 | yes |  |

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | GUEST_ANIMAL_ALLERGY | GUEST_FOOD_CONSTRAINT |
| ---- | ------- | ------ | ----------- | ---------- | -------------------- | --------------------- |
| W2 | sport, music | female | male | 08/06/2003 | no | nonuts |
| X2 | knitting | male | male | 22/12/2003 | yes | vegetarian |
| Y2 | sport, reading | male | male | 10/11/2003 | yes |  |
| Z2 | music, drawing | female | male/female | 01/09/2003 | no | nonuts,vegetarian |

Avec cette exemple, le plus grand nombre de paires que nous pouvons créer est de 0. Il est impossible de creer des pairs entre-eux.

- ***A2 et Z2 :***

D'après nos deux tableaux, on peut déterminer que **A2 et Z2** sont les moins compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet A2 a comme hobbies le sport, et est une femme qui préfère être avec les hommes
- Z2 a comme hobbies la musique et dessiner, et est une femme qui préfère les hommes et les femmes
- Ils ont également 2 an et 3 mois d'écart
- A2 ne détient aucun animaux et Z2 n'a aucune allergie aux animaux
- A2 détient de la nourriture à base de noix et Z2 ne mange pas de la nourriture à base de noix ni végétarienne.

On peut donc dire qu'ils sont les moins compatibles.

- ***B2 et W2 :***

D'après nos deux tableaux, on peut déterminer que **B2 et W2** sont les moins compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet B2 a comme hobbies le crochet et dessiner, et est une femme qui préfère être avec les hommes et les femmes
- W2 a comme hobbies le sport et la musique, et est une femme qui préfère les hommes
- Ils ont également 2 an et 5 mois d'écart
- B2 ne détient aucun animaux et W2 n'a aucune allegie aux animaux
- B2 détient de la nourriture à base de noix et végétarienne, et W2 ne mange pas de la nourriture a base de noix.

On peut donc dire qu'ils sont les moins compatibles.

- ***C2 et X2 :***

D'après nos deux tableaux, on peut déterminer que **C2 et X2** sont les moins compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet C2 a comme hobbies le sport et lire, et est une femme qui préfère être avec les hommes et les femmes
- X2 a comme hobbies le crochet, et est un homme qui préfère les hommes
- Ils ont également 2 an et 3 mois d'écart
- C2 détient un ou des animaux et X2 a une allergie aux animaux
- C2 ne détient aucun régime particulier et X2 ne mange pas de la nourriture végétarienne.

On peut donc dire qu'ils sont les moins compatibles.

- ***D2 et Y2 :***

D'après nos deux tableaux, on peut déterminer que **D2 et Y2** sont les moins compatibles entre eux, tout en se basant sur le système de contraintes rédhibitoires.
- En effet D2 a comme hobbies le crochet et dessiner, et est une femme qui préfère être avec les hommes et les femmes
- Y2 a comme hobbies le sport et lire, et est un homme qui préfère les hommes
- Ils ont également 2 an et 5 mois d'écart
- D2 détient un ou des animaux et Y2 a une allergie aux animaux
- Aucune des deux personnes détient un régime particulier.

On peut donc dire qu'ils sont les moins compatibles.

## Score d'affinité

```
double score_affinité_2(hôte, visiteur) 

  affinité = score_affinité_1(h, v) // Appel de la fonction qui prend en paramètre hôte et visiteur

  Si existeRedibitoire // Fonction crée en dehors de score_affinité_2

    Retourner 42

  -- Fonction existeRedibitoire --
  Boucle qui parcours les critères qui sont rédibitoires
  et verifie la compatibilité entre les deux
  Si un critère rédibitoire est détécté entre les 2
    Alors la fonction return true
  Sinon elle renvoie false
  -----------------------------------

  Enfin, retourner le score d'affinité
```

## Retour sur l'exemple

$$
\begin{array} {c|cccc}
    & A1 & B1 & C1 & D1 \\
\hline
    W1 & 42 & 42 & -2 & 42 \\
    X1 & 42 & 0 & -1 & 42 \\
    Y1 & 42 & -1 & 1 & 42 \\
    Z1 & 42 & 42 & 42 & 42 \\
\end{array}
$$
<center> matrice d’adjacence du graphe biparti complet utilisant la fonction score_affinité_2 avec les données suivantes : {A1, B1, C1, D1} (hôtes) et {W1, X1, Y1, Z1} (visiteurs)</center>

#### Appariement de poids minimal de la matrice 1
Dans cette matrice uniquement 2 colonnes, C1 et B1, sont éligible à une potentiel liaison. Il n'existe donc pas de couple parfait si l'on se base uniquement sur un critère rédhibitoire car il est trop punitif.
Voici tout de même le poids minimal de la matrice : W1-C1; X1-B1; Y1-A1; Z1-D1.
Ensemble ils font un score de -2 + 0 + 42 + 42 soit un total de **82**.

$$
\begin{array} {c|cccc}
    & A2 & B2 & C2 & D2 \\
\hline
    W2 & 4 & 3 & 5 & 5 \\
    X2 & 42 & 42 & 42 & 42 \\
    Y2 & 42 & 42 & 42 & 42 \\
    Z2 & 2 & 0 & 1 & 1 \\
\end{array}
$$
<center> matrice d’adjacence du graphe biparti complet utilisant la fonction score_affinité_2 avec les données suivantes : {A2, B2, C2, D2} (hôtes) et {W2, X2, Y2, Z2} (visiteurs)</center>

#### Appariement de poids minimal de la matrice 1
Dans cette matrice uniquement 2 colonnes ne sont pas affectées par la contrainte rédhibitoire (W2 et Z2)
Les meilleures liaison possiblees sont donc : A2-W2; B2-Z2; C2-X2; D2-Y2.
Ensemble ils font un score de 4 + 0 + 42 + 42 soit un total de **88**.

## Robustesse de la modélisation (question difficile)

La fonction score_affinité pénalise fortement les contraintes rédhibitoire dès que cela est nécessaire. Pour autant, cela n'est pas suffisant pour tout les types de graphes.
Dans ces cas extrêmes, nous serons obligés d'appareiller des étudiants malgré leurs incompatibilités.
Il faudrait donc, pour répondre entiérement au problèmes, exclure totalement les liaisons concernées.

# Version 3

## Équilibrage entre affinité / incompatibilité

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | HOST_HAS_ANIMAL | HOST_FOOD |
| ---- | ------- | ------ | ----------- | ---------- | --------------- | --------- |
| H1 | sport, reading | female | male | 22/12/2005 | no | nonuts |
| H2 | knitting, drawing | female | female/male | 10/11/2005 | no | nonuts,vegetarian |
| H3 | sport, music | male | male/female | 01/09/2005 | yes |  |
| H4 | music, knitting | female | female/male | 08/06/2005 | yes |  |

| NAME | HOBBIES | GENDER | PAIR_GENDER | BIRTH_DATE | GUEST_ANIMAL_ALLERGY | GUEST_FOOD_CONSTRAINT |
| ---- | ------- | ------ | ----------- | ---------- | -------------------- | --------------------- |
| V1 | sport, reading | male | female | 22/12/2004 | yes | nonuts |
| V2 | knitting, drawing | male | female | 10/11/2004 | yes |  |
| V3 | sport, music | female | male | 01/09/2004 | yes | vegetarian |
| V4 | music, knitting | female | male/female | 08/06/2004 | no | nonuts,vegetarian |

***H1 & V1 :***

Cet hôte et ce visiteur ne peuvent pas être comptatibles à cause des contraintes rédhibitoires, mais grâce à l'affinité qu'ils ont au niveau des activités, du genre de préférences et de leur date de naissance on peut faire un équilibre face à leur incompatibilité au niveau de la nourriture,
- En effet H1 a comme hobbies le sport et lire, et est une femme qui préfère être avec les hommes
- V1 a comme hobbies le sport et lire, et est un homme qui préfère les femmes
- Ils ont également 1 an d'écart
- H1 ne détient aucun animaux et V1 a une allergie aux animaux
- H1 détient de la nourriture à base de noix et V1 ne mange pas de la nourriture à base de noix.

Grâce à leur affinité qui fait un équilibrage, on peut donc dire qu'ils sont compatibles.

***H2 & V2 :***

Cet hôte et ce visiteur peuvent être comptatibles malgré les contraintes rédhibitoires,
- En effet H2 a comme hobbies le crochet et dessiner, et est une femme qui préfère être avec les hommes et les femmes
- V2 a comme hobbies le crochet et dessiner, et est un homme qui préfère les femmes
- Ils ont également 1 an d'écart
- H2 ne détient aucun animaux et V2 a une allergie aux animaux
- H2 détient de la nourriture végétarienne à base de noix et V2 ne détient aucun régime alimentaire.

On peut donc dire qu'ils sont comptatibles.

***H3 & V3 :***

Cet hôte et ce visiteur ne peuvent pas être comptatibles à cause des contraintes rédhibitoires, mais grâce à l'affinité qu'ils ont au niveau des activités, du genre de préférence et de leur date de naissance on peut faire un équilibre face à leur incompatibilité au niveau des animaux,
- En effet H3 a comme hobbies le sport et la musique, et est un homme qui préfère être avec les hommes et les femmes
- V3 a comme hobbies le sport et la musique, et est une femme qui préfère les hommes
- Ils ont également 1 an d'écart
- H3 détient un ou des animaux et V3 a une allergie aux animaux
- H3 ne détient aucun régime alimentaire et V3 ne mange pas de la nourriture végétarienne.

Grâce à leur affinité qui fait un équilibrage, on peut donc dire qu'ils sont comptatibles.

***H4 & V4 :***

Cet hôte et ce visiteur peuvent être comptatibles malgré les contraintes rédhibitoires,
- En effet H4 a comme hobbies la musique et le crochet, et est une femme qui préfère être avec les hommes et les femmes
- V4 a comme hobbies la musique et le crochet, et est une femme qui préfère les hommes et les femmes
- Ils ont également 1 an d'écart
- H4 détient un ou des animaux et V4 n'a aucune allergie aux animaux
- H4 ne détient aucun régime alimentaire et V4 ne mange pas de la nourriture végétarienne et à base de noix.

On peut donc dire qu'ils sont comptatibles.

## Score d'affinité

```
double score_affinité_3(hôte, visiteur) 

  //Création de constante
  BON_AFFINITE = 1
  PENALITE = 5
  CONTRAINTE_RÉDIBITOIRE = 42

  affinité = score_affinité_1(h, v) // Appel de la fonction qui prend en paramètre hôte et visiteur

  //Nous allons en premier lieu vérifier les contraintes rédhibitoires pour éviter de faire divers tests inutils, appel à la fonction historique_valide définie en fin de code

//Creation d'une variable pour éviter de répéter la fonction historique_valide
historique_check = historique_valide(hôte, visiteur)

Si historique_check == false
  Alors retourner CONTRAINTE_REDHIBITOIRE //inutile de faire la suite

// Fonction réalisée dans la version 2 mais modifiée afin de répondre aux 
problème de la version 3
------- Fonction existeRedhibitoire (int)-----------
nbCritereRedibitoire = 0 // nom de la variable qui sera retournée en fin de méthode
Boucle qui parcours les critères qui sont rédhibitoire
et vérifie la compatibilité entre les deux
Si un critère redhibitoire est détécté entre les 2
  Alors nbCritereRedibitoire++ // Afin de savoir le nombre de critère redhibitoire

return nbCritereRedibitoire // Afin de récupérer la valeur dans le code
-----------------------------------

  Si existeRedhibitoire >= 2
  Et que affinité >= BON_AFFINITE + 1
  // Ce qui signifie que la paire n'as vraiment rien pour être liée

    Alors on retourne un score très élevé afin de détécter que 
    la relation entre les deux n'est pas possible
    retourner CONTRAINTE_REDHIBITOIRE

  //prend donc en compte lorsque existeRedhibitoire = 0 puisqu'il ne modifie rien à affinité

//Appel de historique_check pour rajouter un bonus d'affinité en fin de code
Si historique_check == true
  Alors affinité = affinité - 2

Renvoie le score d'affinité entre les deux

//Fonction appelée une fois au début pour vérifier l'historique et donc en dehors de cette fonction
---------Historique_valide-------------
//La fonction récupère hote, visiteur ainsi que le score d'affinité actuel

//On va initialiser les deux liaisons afin de les définir par la suite

h_vers_v = null
v_vers_h = null

//On parcours l'historique de l'hôte afin de savoir si il a déjà eu une liaison avec le visiteur et que souhaite-t'il avoir maintenant (on suppose que pour chaque binôme il a une appréciation enregistrée).
Le tableau est donc le suivant :
[[visiteur][appréciation]]
.....

Pour chaque (visiteur, appréciation) de hôte
  Si visiteur == visiteur actuel
    h_vers_v = appréciation // qui peut donc être : same, other ou null
    Quitter la boucle
  Fin de Si
Fin de pour

//On parcours l'historique du visiteur afin de savoir si il a déjà eu une liaison avec l'hôte et que souhaite-t'il avoir maintenant (on suppose que pour chaque binôme il a une appréciation enregistrée).
Le tableau est donc le suivant :
[[hôte][appréciation]]
.....

Pour chaque (hôte, appréciation) de visiteur
  Si hôte == hôte actuel
    v_vers_h = appréciation // qui peut donc être : same, other ou null
    Quitter la boucle
  Fin de Si
Fin de pour

//Passons maintenant à l'analyse des réponses
//Liaison problématique
Si h_vers_v == "other" OU que v_vers_h == "other"
  Alors retourner false

//Liaison correcte
Retourner true
-------------Fin-de-Historique_valide--------------

```

## Retour sur l'exemple

//**Attention :** Ici l'historique n'a pu être pris en compte, faute de données sur les correspondances précédentes. Nous ne pouvons donc pas répondre à ce critère.
S’il avait été disponible, un bonus de -2 aurait été appliqué en cas d'expérience positive, tandis qu’une contrainte rédhibitoire liée à l’historique aurait eu un score de 42 (Ce qui explique principalement leur absence)

Voici une trace d'execution pour la comptabilité des données :
```
Correspondance V1-H1 : 
score_affinité_1 : 
  Age : 1 ans d'écart : pas de malus
  genre : correspond au recherche hôte et visiteur : pas de malus
  Hobbie commun : 2 : affinité -2
Historique : Aucune info donc on n'y touche pas 
Critère rédhibitoire : 
  H1 n'a pas d'animaux et V1 est allergique : aucun problème
  H1 et V1 ont nonuts comme régime : aucun problème
  Le score est donc de -2
```

$$
\begin{array} {c|cccc}
    & H1 & H2 & H3 & H4 \\
\hline
    V1 & -2 & 0 & 1 & 0 \\
    V2 & 0 & -2 & 2 & -1 \\
    V3 & 3 & 2 & -2 & 1 \\
    V4 & 3 & -1 & -1 & -2 \\
\end{array}
$$
<center> matrice d’adjacence du graphe biparti complet utilisant la fonction score_affinité_3 avec les données suivantes : {H1, H2, H3, H4} (hôtes) et {V1, V2, v3, v4} (visiteurs)</center>

#### Conclusion

Avec score_affinité_3 et notamment sur cette matrice nous obtenons des scores globalement proche, puisque c'est ce qui était attendu pour cette fonction.
Bien évidemment si il y avait eu une contrainte rédhibitoire, une affinité aurait eu la valeur 42 mais la base H1 H2... V1 V2... était correcte pour l'ensemble des paires.
La fonction permet donc de bien faire la distinction entre les paires souhaitable et les paires impossibles sans créer d'écarts inutiles.

