
# SAE S2.01 -- Compte Rendu IHM
### Equipe C1
#### Tison Chloé, Ung Mei-Li, Desprez Mathéo
### 2025

-------------

## Captures d'écran de l'application finale


***Page d'accueil :***

![Accueil](./IMG_Application/Capture%20d’écran%20du%202025-06-12%2021-04-08.png)


***Page du profil :***

![Profil](./IMG_Application/Capture%20d’écran%20du%202025-06-12%2021-07-19.png)


***Page de recherche des hôtes et des visiteurs :***

![Recherche hosts/guests](./IMG_Application/Capture%20d’écran%20du%202025-06-12%2021-07-59.png)


***Page d'affinité :***

![Page affinité](./IMG_Application/Capture%20d’écran%20du%202025-06-12%2021-08-51.png)

-------------

## Lien vers nos mockups Figma

***Mockups Figma :***
[Lien Figma](https://www.figma.com/design/5VFggbJ2ekjv7MiCGkXR7K/IHM-prototype?node-id=0-1&p=f&t=Yt078QdEsqSviTWB-0)

-------------

## Justification de nos choix sur le projet

L'interface de notre projet a été pensée pour faciliter la prise en marche pour l'utilisateur des différentes fonctionnalités, sans le surcharger d'informations. Les différents menus présents sur la page de profil, et de recherches permettent de se rendre n'importe où ailleurs dans l'application. Divers boutons de retour (comme sur la page de profil vers la page d'accueil ou sur la page de description précise d'une paire vers le choix global des paires) permet aussi le déplacement vers les pages, de façon logique et comme une manière de revenir en arrière dans son parcours de l'application.

De plus, les boutons sont simples et intuitifs. Ce qu'ils font est clairement indiqué dessus, et ceux qui font des actions similaires sont placées côte à côte. De plus l'application demande bien vérification en cas de mauvaises manipulations de l'interface. Par exemple, lors d'une suppression de profil, une popup de confirmation du choix apparaît. Il en va de même lorsque l'utilisateur n'a sélectionné aucun profil de connexion et souhaite accéder à son profil, ou lorqu'il souhaite rechercher des hôtes ou des visiteurs de son pays d'origine (ce qui est impossible dans un échange international). 

Enfin, on a pensé le visuel pour qu'il soit attractif et que cela soit plaisant de se balader sur le site, avec les différentes couleurs et les images. L'utilisateur a des repères visuels qui guident ses choix et qui donne des informations instinctives (comme l'utilisation d'un slider pour le choix de la précision d'affinité, une barre de progression pour connaître à quel point des paires sont compatibles, le choix des couleurs des boutons match ou retour, ou encore le rouge pour des incompatibilités de critères, le orange pour des compatibilités moyennes, et le vert pour des compatibilités totales sur ce critère)

-------------

## Distribution des tâches entre les membres

Pour que chaque membre puisse participer à la réalisation de ce projet, une répartition des tâches a été effectuée. 
En effet, certains membres s'en sortent mieux en JavaFX que d'autres, ce qui est le cas de Mathéo et de Mei-Li. Ils ont donc principalement fait tout ce qui concerne le code et la mise en œuvre de l'application. 
En revanche Chloé, ayant des difficultés avec JavafX a dû se concentrer sur autre chose. Comme par exemple créer des personnes pour qu'on puisse faire des exemples avec notre application.
Et pour finir des tâches ont été faite simultanément par tous les membres du groupe, comme les mockups sur Figma, ou encore le compte rendu présent ici.
Chacun a apporté ses idées et ses compétences lors de la réalisation de se projet, la communication a donc été un point fort et nous sommes heureux du rendu de notre projet. 

-------------

## Autres informations

# Excuter la JAR du projet

ligne de code pour exécuter depuis la racine de l'arborescence:
```
java --module-path rendu\ ihm/lib/javafx-sdk-21.0.7/lib --add-modules javafx.controls,javafx.fxml -jar rendu\ ihm/lib/app.jar
```
-------------

## Lien vers la vidéo de présentation de notre projet

[Lien vers la vidéo](https://gitlab.univ-lille.fr/sae2.01-2.02/2025/C1/-/blob/master/Video_IHM/Sae2.01-2.02_Video-Projet-With-Sound_Desprez_Ung_T.mp4?ref_type=heads)

Il vous suffit simplement de télécharger la vidéo pour y accéder. Bon visionage. :D 