# Prototypage basse fidélité du développement de l'application 

## Lien HTML vers les mockups

https://www.figma.com/design/5VFggbJ2ekjv7MiCGkXR7K/IHM-prototype?node-id=0-1&t=rPhdw58VDzbMcm2M-1

## Réalisé par :
- Desprez Mathéo: matheo.desprez.etu@univ-lille.fr
- Tison Chloé: chloe.tison2.etu@univ-lille.fr
- Ung Mei Li: mei-li.ung.etu@univ-lille.fr