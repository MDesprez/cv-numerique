class Monde {
    String nom;
    Pokemon[] ennemis;
    //int difficulté;
    //String type;
}