class Pokemon {
    String nom;
    String[] couleurNom;
    int experience;
    int experienceMax;
    int vie;
    int vieMax;
    String[] attaques;
    int[] puissanceAttaques;
    boolean ko = false;
    Pokemon evolution;
    // String type;
    // int tauxCapture
}